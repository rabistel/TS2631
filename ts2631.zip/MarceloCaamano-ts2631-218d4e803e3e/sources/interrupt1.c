/*
 * interrupt1.c
 *
 *  Created on: 2 ago. 2018
 *      Author: Marcelo.Caamaño
 */
#include "fsl_wwdt.h"
#include "fsl_ctimer.h"
#include "fsl_rtc.h"
#include "CPU_def.h"

int s_ticker_inited = 0;
//extern volatile int i;
//extern __Timing Timing;



void ctimer_callback_1s(uint32_t flags);
void ctimer_callback_60s(uint32_t flags){};
void rtc_8msec_handler(uint32_t flags);
void ctimer_callback_1ms(uint32_t flags);

/* Array of function pointers for callback for each channel */
ctimer_callback_t ctimer_callback_table[] = {
		rtc_8msec_handler, NULL, NULL, NULL, NULL, NULL, NULL, NULL};
		//ctimer_callback_1s, ctimer_callback_60s, NULL, NULL, NULL, NULL, NULL, NULL};
ctimer_callback_t ctimer2_callback_table[] = {
		ctimer_callback_1ms, NULL, NULL, NULL, NULL, NULL, NULL, NULL};



/*
 * funcion de atencion a interrupcion
 * Timer de 1 segundo //NO SE USA POR AHORA!!!!
 * */
void ctimer_callback_1s(uint32_t flags)
{
	  static volatile int i=0;
	  i++;
	 // CTIMER1->IR = 1; //clear interrupt
	 #ifdef DEBUG
	  printf("\n%d",i);
	 #endif

}

/*
 * funcion de atencion a interrupcion
 * Timer de 60 segundos
 *
void ctimer_callback_60s(uint32_t flags)
{
	  static volatile int i=0;
	  i++;
	 // CTIMER1->IR = 1; //clear interrupt
	  printf("\n--M--%d",i);

}*/

/*
 * Inicializo timer 1 para generar interrupcion cada 8 milisegundos
 * Inicializo timer 2 para generar interrupcion cada 1 milisegundo
 * */
void s_ticker_init(void) {
    ctimer_config_t config;

    if (s_ticker_inited) {
        return;
    }

    s_ticker_inited = 1;

    uint32_t pclk = CLOCK_GetFreq(kCLOCK_BusClk);
    uint32_t prescale = pclk / 1000000; // default to 1MHz (1 us ticks)

    CTIMER_GetDefaultConfig(&config);
    config.prescale = prescale - 1;
    CTIMER_Init(CTIMER1, &config);
    CTIMER_Reset(CTIMER1);

    ctimer_match_config_t matchConfig;//, matchConfig1;
    matchConfig.enableCounterReset = true;
    matchConfig.enableCounterStop = false;
    matchConfig.matchValue = 8000u;//1000000u; //para que interrumpa cada 8 mseg
    matchConfig.outControl = kCTIMER_Output_NoAction;
    matchConfig.outPinInitState = false;
    matchConfig.enableInterrupt = true;
/*
    matchConfig1.enableCounterReset = true;
	matchConfig1.enableCounterStop = false;
	matchConfig1.matchValue = 60000000u; //para que interrumpa cada 60 segundo
	matchConfig1.outControl = kCTIMER_Output_NoAction;
	matchConfig1.outPinInitState = false;
	matchConfig1.enableInterrupt = true;
*/

    CTIMER_RegisterCallBack(CTIMER1, &ctimer_callback_table[0], kCTIMER_MultipleCallback); //en cada interrupt va a llamar a rtc_8msec_handler


    CTIMER_SetupMatch(CTIMER1, kCTIMER_Match_0, &matchConfig);
    //CTIMER_SetupMatch(CTIMER1, kCTIMER_Match_1, &matchConfig1);
    //CTIMER_EnableInterrupts(CTIMER1,CTIMER_MCR_MR0I_MASK);
    CTIMER_StartTimer(CTIMER1);


    /*inicializo timer 2 cada 1ms*/

    CTIMER_GetDefaultConfig(&config);
       config.prescale = prescale - 1;
       CTIMER_Init(CTIMER2, &config);
       CTIMER_Reset(CTIMER2);

       ctimer_match_config_t matchConfig1;//, matchConfig1;
       matchConfig1.enableCounterReset = true;
       matchConfig1.enableCounterStop = false;
       matchConfig1.matchValue = 1000u;//1000000u; //para que interrumpa cada 1 mseg
       matchConfig1.outControl = kCTIMER_Output_NoAction;
       matchConfig1.outPinInitState = false;
       matchConfig1.enableInterrupt = true;

       CTIMER_RegisterCallBack(CTIMER2, &ctimer2_callback_table[0],kCTIMER_MultipleCallback); //MAC2021 kCTIMER_SingleCallback); //en cada interrupt va a llamar a rtc_8msec_handler

       CTIMER_SetupMatch(CTIMER2, kCTIMER_Match_0, &matchConfig1);
       CTIMER_StartTimer(CTIMER2);


}

static volatile uint8_t wdt_update_count;
/*interrupcion del WatchDog*/
void WDT_BOD_IRQHandler(){
	//no hago nada
	uint32_t wdtStatus = WWDT_GetStatusFlags(WWDT);

	  //  APP_LED_TOGGLE;
	LED_R_TOGGLE;

	    /* The chip will reset before this happens */
	    if (wdtStatus & kWWDT_TimeoutFlag)
	    {
	        /* A watchdog feed didn't occur prior to window timeout */
	        /* Stop WDT */
	        WWDT_Disable(WWDT);
	        WWDT_ClearStatusFlags(WWDT, kWWDT_TimeoutFlag);
	        /* Needs restart */
	        WWDT_Enable(WWDT);
	    }

	    /* Handle warning interrupt
	    if (wdtStatus & kWWDT_WarningFlag)
	    {
	        if (wdt_update_count < 5)
	        {
	            while (WWDT->TV >= WWDT->WARNINT)
	            {
	            }
	            // Feed only for the first 5 warnings then allow for a WDT reset to occur
	            WWDT_Refresh(WWDT);
	            wdt_update_count++;
	        }
	        while (WWDT->TV < WWDT->WARNINT)
	        {
	        }
	        // A watchdog feed didn't occur prior to warning timeout
	        WWDT_ClearStatusFlags(WWDT, kWWDT_WarningFlag);
	    }
	    */
    /* Add for ARM errata 838869, affects Cortex-M4, Cortex-M4F Store immediate overlapping
      exception return operation might vector to incorrect interrupt */
#if defined __CORTEX_M && (__CORTEX_M == 4U)
    __DSB();
#endif
}


/*
 * interrumpe una vez cada segundo, incremento el contador de segundos*/
void RTC_IRQHandler(void)
{
	  static volatile int i=0;
      /* This is increment counter interrupt*/
	  	//  i++;
		/* Send debug information */
		//printf("\n%d",i);
	  //static rtc_datetime_t dateG;
	    if (RTC_GetStatusFlags(RTC) & kRTC_AlarmFlag)
	    {
	    	i=RTC->COUNT;
	        //printf("%d\n",i);

	        RTC_GetDatetime(RTC, &dateG);

	        RTC->MATCH = i + 1;
	        /* Clear alarm flag */
	        RTC_ClearStatusFlags(RTC, kRTC_AlarmFlag);

	        Timing.Seconds++;
			Timing.Bits.Pps=1;
			FlagsAD.MeterAll=1;
			if (Timing.Seconds>59){     //59
						  Timing.Seconds=0;
						  Timing.Bits.Ppm=1;
						  };

			//del Interrupt1.c (SOFT_CPU)
			 if(ticTimer) ticTimer--;

			//TODO  manejar OLA y cangilon en rtc_8msec_handler

			// SoftWD++;  // Cuenta segundos desde el ultimo Reset
		   /* print default time */ //TODO borrar esto, solo para prueba
			 LED_G_TOGGLE;
		 /*  printf("Current datetime: %04d-%02d-%02d %02d:%02d:%02d\r\n",
				  date.year,
				  date.month,
				  date.day,
				  date.hour,
				  date.minute,
				  date.second);
			 *  //printf("m");
			 *
			 */
	    }
	    /* Add for ARM errata 838869, affects Cortex-M4, Cortex-M4F Store immediate overlapping
	      exception return operation might vector to incorrect interrupt */
	#if defined __CORTEX_M && (__CORTEX_M == 4U)
	    __DSB();
	#endif

}


void s_ticker_init_RTC(void){

	rtc_datetime_t date;
    /* Enable the RTC 32K Oscillator */
    SYSCON->RTCOSCCTRL |= SYSCON_RTCOSCCTRL_EN_MASK;

    /* Init RTC */
	RTC_Init(RTC);
	#ifdef DEBUG
		printf("\nRTC init\r\n");
	#endif

	/* Set a start date time and start RT */
	date.year = 2014U;
	date.month = 12U;
	date.day = 25U;
	date.hour = 19U;
	date.minute = 0;
	date.second = 0;

	/* RTC time counter has to be stopped before setting the date & time in the TSR register */
	RTC_StopTimer(RTC);

	/* Set RTC time to default */
	RTC_SetDatetime(RTC, &date);

	/* Enable RTC alarm interrupt */
	RTC_EnableInterrupts(RTC, kRTC_AlarmInterruptEnable);


	/* Enable at the NVIC */
	EnableIRQ(RTC_IRQn);

	/* Start the RTC time counter */
	RTC_StartTimer(RTC);
	RTC->MATCH = RTC->COUNT + 1;

}


/*  Handler de Timer 1, Periodo=8 ms
    Cada 125 veces cuenta 1 seg:  OlaTag=25 * Tag=5
    CANGILON  (PIO5_5 : pin145)= Switch N.A. = Normal en "0"
    CANGILON_N(PIO0_1 : pin207) = Switch N.C. = Normal en "1"

    El pulso en CANGILON tiene que durar mas de 50 y menos de 1400mS
    El flag NoVal se pone en cero cuando se registra un dato dentro de ...CalPluviometrico
*/
//era rtc_1sec_handler(void) en IO
void rtc_8msec_handler(uint32_t flags)
{
    // Proceso del cangilon por sample

	if (CangDeb==0)   // Estado de Reset, puede contar un nuevo pulso
    {   // Flanco en la ED3
        if (CANGILON) CangDeb=186;  // Detecto un pulso -> inhibido uno nuevo por 1.5 segundos
    }
    else
    {
        CangDeb--;
        if (CangDeb==0)
        {
             if(CANGILON) // La SD3 se quedo en "1"
             {    CangDeb=100;
                  Pluviometro.Flags.NoVal=1;
             }
             else
             {
                  if(Pluviometro.Flags.Red_Dif) // La SD4 quedo en "0"
                      if(!CANGILON_N) Pluviometro.Flags.NoVal=1;
             }
        }
    }
    if (CangDeb==180) // 50mS despues del flanco en SD3 evalua redundancia
    {
        if (CANGILON) // Aun dura el pulso
        {
            if(Pluviometro.Flags.Red_Dif)
                if(CANGILON_N)  Pluviometro.Flags.NoVal=1; // Mira Redundancia
            // Acumula cangilon si esta todo OK
            if((!Pluviometro.Flags.Red_Dif) || (!Pluviometro.Flags.NoVal))  InstAD.Cangilones++;
        }
     }

    // Timing.OlaTag => 0..24: 200 ms
    Timing.OlaTag++;
    if(Timing.OlaTag>24)
    {
        Timing.OlaTag = 0;
        Timing.Tag++;
        if(OlaActiva)  FlagsAD.MeterOla=1;


     }
      //esto está en RTC_IRQHandler
	  //if(++tics >= 62)    // son 62.5 en realidad (para tmr a 16ms)
      // if(++tics >= 125)    // tmr a 8ms >> 1segundo
	  //{
	  //	tics = 0;
	  //	//ticSegundo = 1;
	  //	if(ticTimer) ticTimer--;
	  //	//SoftWD++;
      //}
    //  __ICNTRL_bit.t0pnd=0;

    // Esta linea deberia estar habilitada para que funcione el WD
    //TODO if(SoftWD<30) __WDSVR = 0xd8;

    /* Add for ARM errata 838869, affects Cortex-M4, Cortex-M4F Store immediate overlapping
      exception return operation might vector to incorrect interrupt */
//#if defined __CORTEX_M && (__CORTEX_M == 4U)
//    __DSB();
//#endif
}


void ctimer_callback_1ms(uint32_t flags){
	//uint32_t delay;
	if(delay)delay--;
}


/*
void USART_RTU_IRQHandler(void)
{
    uint8_t Temp;
    uint8_t *PtrBuf;

    // If new data arrived.
    if ((kUSART_RxFifoNotEmptyFlag | kUSART_RxError) & USART_GetStatusFlags(USART_RTU))
    {
        Temp = USART_ReadByte(USART_RTU);
        //printf("%02X", Temp); //muestra en Hex
        //If ring buffer is not full, add data to ring buffer.
		switch (BufUart.BufState){
			case HeaderAst: if (Temp=='*'){     // 0x2A
								BufUart.Ast=Temp;
								BufUart.BufState=HeaderAA;
								}
							else BufUart.BufState=HeaderAst;
							break;

			case HeaderAA:  if (Temp==0xaa){    // 0xAA
								BufUart.HdrAA=Temp;
								BufUart.BufState=ID_RTU_lo;
								}
							else BufUart.BufState=HeaderAst;
							break;

			case ID_RTU_lo: if ((Temp==Com.RtuID_lo)||(Temp==0xff)){
								BufUart.RTU_lo=Temp;
								BufUart.BufState=ID_RTU_hi;
								}
							else BufUart.BufState=HeaderAst;
							break;

			case ID_RTU_hi:  if ((Temp==Com.RtuID_hi)||((Temp==0xff)&&(BufUart.RTU_lo==0xff))){
								BufUart.RTU_hi=Temp;
								BufUart.BufState=Command;
								}
							else BufUart.BufState=HeaderAst;
							break;

			case Command:   BufUart.Commands=Temp;
							BufUart.BufState=Data00;
							break;

			case Data00:    BufUart.Rx.Saving.Data00=Temp;
							BufUart.BufState=Data01;
							break;

			case Data01:    BufUart.Rx.Saving.Data01=Temp;
							BufUart.BufState=Data02;
							break;

			case Data02:    BufUart.Rx.Saving.Data02=Temp;
							BufUart.BufState=Data03;
							break;

			case Data03:    BufUart.Rx.Saving.Data03=Temp;
							BufUart.BufState=Data04;
							break;

			case Data04:    BufUart.Rx.Saving.Data04=Temp;
							BufUart.BufState=Data05;
							break;

			case Data05:    BufUart.Rx.Saving.Data05=Temp;
							BufUart.BufState=Data06;
							break;

			case Data06:    BufUart.Rx.Saving.Data06=Temp;
							BufUart.BufState=CheckSum;
							break;

			case CheckSum:  BufUart.CheckSum=Temp;  // Recibo el checksum del Header
							Temp=0;   // Calcula checksum
							for (PtrBuf=&BufUart.Ast; PtrBuf<&BufUart.CheckSum; PtrBuf++)  Temp=Temp+*PtrBuf;
							if (Temp!=*PtrBuf)BufUart.BufState=HeaderAst; // Error de Checksum del Header
							else{
								if ((BufUart.Commands==_WrPage)||(BufUart.Commands==_WrPack)){  // Comandos con datos adicionales
									BufUart.BufState++;
									BufUart.PtrRx=&DataCom.BufData[0];
									}
								else{   // Comandos sin datos adicionales
									//__ENUI_bit.eri=0; // frena la entrada de bytes
									//DisableIRQ(USART_RTU_IRQn);
									Status.UartFull=1;// avisa que buffer full
									Status.WithData=0;// indica que no entró con página de datos.
									};
								};
							break;

			 case Datas:    if (BufUart.PtrRx < &DataCom.CheckSum){ // Recibo 64 bytes de datos
								*BufUart.PtrRx=Temp;
								BufUart.PtrRx++;
								}
							else{     // Recibo el checksum de los 64 datos
								*BufUart.PtrRx=Temp;
								Temp=0;
								for (BufUart.PtrRx=&DataCom.BufData[0]; BufUart.PtrRx<&DataCom.CheckSum; BufUart.PtrRx++)
									Temp=Temp+*BufUart.PtrRx;
								if ((uint8_t)(Temp+BufUart.CheckSum+BufUart.CheckSum)!=*BufUart.PtrRx)BufUart.BufState=HeaderAst;
								else{                   // Buffer full ok
									//__ENUI_bit.eri=0;   // frena la entrada de bytes, deshabilita Ints
									//DisableIRQ(USART_RTU_IRQn);
									Status.UartFull=1;  // avisa que buffer full
									Status.WithData=1;  // indica que entró con página de datos.
									};
								};
			};


    }
    // Add for ARM errata 838869, affects Cortex-M4, Cortex-M4F Store immediate overlapping
    //  exception return operation might vector to incorrect interrupt
#if defined __CORTEX_M && (__CORTEX_M == 4U)
    __DSB();
#endif
}
*/



void intProcUSB(uint8_t Temp){

 //uint8_t Temp;
    uint8_t *PtrBuf;

 /* If ring buffer is not full, add data to ring buffer. */
		BufUart.TimeOutRx=2;
		switch (BufUart.BufState){
			case HeaderAst: if (Temp=='*'){     // 0x2A
								BufUart.Ast=Temp;
								BufUart.BufState=HeaderAA;
								}
							else BufUart.BufState=HeaderAst;
							break;

			case HeaderAA:  if (Temp==0xaa){    // 0xAA
								BufUart.HdrAA=Temp;
								BufUart.BufState=ID_RTU_lo;
								}
							else BufUart.BufState=HeaderAst;
							break;

			case ID_RTU_lo: if ((Temp==Com.RtuID_lo)||(Temp==0xff)){
								BufUart.RTU_lo=Temp;
								BufUart.BufState=ID_RTU_hi;
								}
							else BufUart.BufState=HeaderAst;
							break;

			case ID_RTU_hi:  if ((Temp==Com.RtuID_hi)||((Temp==0xff)&&(BufUart.RTU_lo==0xff))){
								BufUart.RTU_hi=Temp;
								BufUart.BufState=Command;
								}
							else BufUart.BufState=HeaderAst;
							break;

			case Command:   BufUart.Commands=Temp;
							BufUart.BufState=Data00;
							break;

			case Data00:    BufUart.Rx.Saving.Data00=Temp;
							BufUart.BufState=Data01;
							break;

			case Data01:    BufUart.Rx.Saving.Data01=Temp;
							BufUart.BufState=Data02;
							break;

			case Data02:    BufUart.Rx.Saving.Data02=Temp;
							BufUart.BufState=Data03;
							break;

			case Data03:    BufUart.Rx.Saving.Data03=Temp;
							BufUart.BufState=Data04;
							break;

			case Data04:    BufUart.Rx.Saving.Data04=Temp;
							BufUart.BufState=Data05;
							break;

			case Data05:    BufUart.Rx.Saving.Data05=Temp;
							BufUart.BufState=Data06;
							break;

			case Data06:    BufUart.Rx.Saving.Data06=Temp;
							BufUart.BufState=CheckSum;
							break;

			case CheckSum:  BufUart.CheckSum=Temp;  // Recibo el checksum del Header
							Temp=0;   // Calcula checksum
							for (PtrBuf=&BufUart.Ast; PtrBuf<&BufUart.CheckSum; PtrBuf++)
								   Temp=Temp+*PtrBuf;
							if (Temp!=*PtrBuf)BufUart.BufState=HeaderAst; // Error de Checksum del Header
							else{
								if ((BufUart.Commands==_WrPage)||(BufUart.Commands==_WrPack)){  // Comandos con datos adicionales
									BufUart.BufState++;
									BufUart.PtrRx=&DataCom.BufData[0];
									}
								else{   // Comandos sin datos adicionales
									//__ENUI_bit.eri=0; // frena la entrada de bytes
									//DisableIRQ(USART_RTU_IRQn); //aunque no es UART, freno la uart
									//USART_EnableRxDMA(USART_RTU,false);

									Status.UartFull=1;// avisa que buffer full
									Status.WithData=0;// indica que no entró con página de datos.
									};
								};
							break;

			 case Datas:    if (BufUart.PtrRx < &DataCom.CheckSum){ // Recibo 64 bytes de datos
								*BufUart.PtrRx=Temp;
								BufUart.PtrRx++;
								}
							else{     // Recibo el checksum de los 64 datos
								*BufUart.PtrRx=Temp;
								Temp=0;
								for (BufUart.PtrRx=&DataCom.BufData[0]; BufUart.PtrRx<&DataCom.CheckSum; BufUart.PtrRx++)
									Temp=Temp+*BufUart.PtrRx;
								if ((uint8_t)(Temp+BufUart.CheckSum+BufUart.CheckSum)!=*BufUart.PtrRx)BufUart.BufState=HeaderAst;

								else{                   // Buffer full ok
									//__ENUI_bit.eri=0;   // frena la entrada de bytes, deshabilita Ints
									//DisableIRQ(USART_RTU_IRQn);//aunque no es UART, freno la uart
									//USART_EnableRxDMA(USART_RTU,false);
									Status.UartFull=1;  // avisa que buffer full
									Status.WithData=1;  // indica que entró con página de datos.
									};
								};
			 	 	 	 	 	break;
			// default:
			// 	 	 	 	BufUart.BufState=HeaderAst; // Error de Checksum del Header
			// 				USART_TransferAbortReceiveDMA(USART_RTU, &g_uartDmaHandle);

			};

}

void intProcUART(uint8_t Temp){

 //uint8_t Temp;
    uint8_t *PtrBuf;

 /* If ring buffer is not full, add data to ring buffer. */
		BufUart.TimeOutRx=2;
		switch (BufUart.BufState){
			case HeaderAst: if (Temp=='*'){     // 0x2A
								BufUart.Ast=Temp;
								BufUart.BufState=HeaderAA;
								}
							else BufUart.BufState=HeaderAst;
							break;

			case HeaderAA:  if (Temp==0xaa){    // 0xAA
								BufUart.HdrAA=Temp;
								BufUart.BufState=ID_RTU_lo;
								}
							else BufUart.BufState=HeaderAst;
							break;

			case ID_RTU_lo: if ((Temp==Com.RtuID_lo)||(Temp==0xff)){
								BufUart.RTU_lo=Temp;
								BufUart.BufState=ID_RTU_hi;
								}
							else BufUart.BufState=HeaderAst;
							break;

			case ID_RTU_hi:  if ((Temp==Com.RtuID_hi)||((Temp==0xff)&&(BufUart.RTU_lo==0xff))){
								BufUart.RTU_hi=Temp;
								BufUart.BufState=Command;
								}
							else BufUart.BufState=HeaderAst;
							break;

			case Command:   BufUart.Commands=Temp;
							BufUart.BufState=Data00;
							break;

			case Data00:    BufUart.Rx.Saving.Data00=Temp;
							BufUart.BufState=Data01;
							break;

			case Data01:    BufUart.Rx.Saving.Data01=Temp;
							BufUart.BufState=Data02;
							break;

			case Data02:    BufUart.Rx.Saving.Data02=Temp;
							BufUart.BufState=Data03;
							break;

			case Data03:    BufUart.Rx.Saving.Data03=Temp;
							BufUart.BufState=Data04;
							break;

			case Data04:    BufUart.Rx.Saving.Data04=Temp;
							BufUart.BufState=Data05;
							break;

			case Data05:    BufUart.Rx.Saving.Data05=Temp;
							BufUart.BufState=Data06;
							break;

			case Data06:    BufUart.Rx.Saving.Data06=Temp;
							BufUart.BufState=CheckSum;
							break;

			case CheckSum:  BufUart.CheckSum=Temp;  // Recibo el checksum del Header
							Temp=0;   // Calcula checksum
							for (PtrBuf=&BufUart.Ast; PtrBuf<&BufUart.CheckSum; PtrBuf++)
								   Temp=Temp+*PtrBuf;
							if (Temp!=*PtrBuf)BufUart.BufState=HeaderAst; // Error de Checksum del Header
							else{
								if ((BufUart.Commands==_WrPage)||(BufUart.Commands==_WrPack)){  // Comandos con datos adicionales
									BufUart.BufState++;
									BufUart.PtrRx=&DataCom.BufData[0];
									}
								else{   // Comandos sin datos adicionales
									//__ENUI_bit.eri=0; // frena la entrada de bytes
									//DisableIRQ(USART_RTU_IRQn); //aunque no es UART, freno la uart
									//USART_EnableRxDMA(USART_RTU,false);

									Status.UartFull=1;// avisa que buffer full
									Status.WithData=0;// indica que no entró con página de datos.
									};
								};
							break;

			 case Datas:    if (BufUart.PtrRx < &DataCom.CheckSum){ // Recibo 64 bytes de datos
								*BufUart.PtrRx=Temp;
								BufUart.PtrRx++;
								}
							else{     // Recibo el checksum de los 64 datos
								*BufUart.PtrRx=Temp;
								Temp=0;
								for (BufUart.PtrRx=&DataCom.BufData[0]; BufUart.PtrRx<&DataCom.CheckSum; BufUart.PtrRx++)
									Temp=Temp+*BufUart.PtrRx;
								if ((uint8_t)(Temp+BufUart.CheckSum+BufUart.CheckSum)!=*BufUart.PtrRx)BufUart.BufState=HeaderAst;

								else{                   // Buffer full ok
									//__ENUI_bit.eri=0;   // frena la entrada de bytes, deshabilita Ints
									//DisableIRQ(USART_RTU_IRQn);//aunque no es UART, freno la uart
									//USART_EnableRxDMA(USART_RTU,false);
									Status.UartFull=1;  // avisa que buffer full
									Status.WithData=1;  // indica que entró con página de datos.
									};
								};
			 	 	 	 	 	break;
			// default:
			// 	 	 	 	BufUart.BufState=HeaderAst; // Error de Checksum del Header
			// 				USART_TransferAbortReceiveDMA(USART_RTU, &g_uartDmaHandle);

			};

}
