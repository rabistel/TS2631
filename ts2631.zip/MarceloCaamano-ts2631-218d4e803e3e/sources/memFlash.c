/*
 * memFlash.c
 *
 *  Created on: 15 ago. 2018
 *      Author: Marcelo.Caamaño
 */

/********************************************************************
 * TODO ver todo esto
 Driver para manejo de las Memorias FLASH Serial
 funciones mem...()

 Format: Vector en Flash de programa, tiene 2 campos u. char
 Format[pila].Start: Pagina Inicial de la pila
 Format[pila].Long:  Paginas Asignadas a la pila

 La lectura de Datos se hace directamente desde las paginas de Flash

 Las escrituras se realizan mediante el Buffer 1
    Se carga la pagina de Flash en el Buffer
    Se modifica el Buffer agregando el nuevo dato
    Se graba el Buffer en la pagina de Flash

 Todas las pilas tienen una primera pagina en la cual se guarda el estado de la pila
    Pagina Inicial: 2 bytes  (referida a la pagina de inicio de la pila)
    Pagina Final: 2 bytes
    Pagina PtrPast: 2 bytes
    Offset PtrPast: 1 byte
 El offset de cada Pagina de cada pila se encuentra en el byte 256 de la pag
 Cuando leemos, lo hacemos hasta llegar al byte de offset, luego saltamos a la pag siguiente
 La funcion memRdCfgFlash() carga todos estos valores en la estructura cfgReg !!!

 La circularidad de las pilas se implementa en dias: cuando la pagina de inicio comienza a desplazarse
 se puede llegar a perder un registro Time ...

 Hay 2 bancos de datos: una mem Interna y un Cartucho removible. Operan con redundancia
 Los datos se escriben en ambas memorias en simultaneo. Se leen selectivamente
 Los punteros de eventos y datos pendientes de Tx operan con la memoria interna exclusivamente

  EA1..EA16:  Paginas 0..15
  PLUVI:      Pagina 16
  Pila Tx:    Pagina 17
  Eventos:    Pagina 18
********************************************************************/
//#include "fsl_nor_flash.h"
#include "fsl_common.h"
//#include "fsl_spifi_nor_flash.h"
#include "fsl_clock.h"
#include "fsl_spifi.h"
#include "CPU_def.h"


union{
	uint16_t tr16_t [4];
	uint8_t tr8_t [8];
} __attribute__ ((packed))  tempReg;

#define EXAMPLE_SPIFI SPIFI0
#define PAGE_SIZE_ (256U)
#define PAGE_SIZE (512U)
//#define PAGE_TECMES_SIZE (PAGE_SIZE*2)
#define SECTOR_SIZE (4096U)
#define PAG_POR_SECTOR  (SECTOR_SIZE/PAGE_SIZE)
#define EXAMPLE_SPI_BAUDRATE (6000000)
#define COMMAND_NUM (6)
#define READ (0)
#define PROGRAM_PAGE (1)
#define GET_STATUS (2)
#define ERASE_SECTOR (3)
#define WRITE_ENABLE (4)
#define WRITE_REGISTER (5)

#define FLASH_S25FL


#if defined FLASH_S25FL
#define QUAD_MODE_VAL 0x02
spifi_command_t command[COMMAND_NUM] = {
    {PAGE_SIZE, false, kSPIFI_DataInput, 1, kSPIFI_CommandDataQuad, kSPIFI_CommandOpcodeAddrThreeBytes, 0x6B}, //READ
    {PAGE_SIZE_, false, kSPIFI_DataOutput, 0, kSPIFI_CommandDataQuad, kSPIFI_CommandOpcodeAddrThreeBytes, 0x32}, //PROGRAM
    {1, false, kSPIFI_DataInput, 0, kSPIFI_CommandAllSerial, kSPIFI_CommandOpcodeOnly, 0x05},
    {0, false, kSPIFI_DataOutput, 0, kSPIFI_CommandAllSerial, kSPIFI_CommandOpcodeAddrThreeBytes, 0x20},
    {0, false, kSPIFI_DataOutput, 0, kSPIFI_CommandAllSerial, kSPIFI_CommandOpcodeOnly, 0x06},
    {2, false, kSPIFI_DataOutput, 0, kSPIFI_CommandAllSerial, kSPIFI_CommandOpcodeOnly, 0x01}}; //WRITE STATUS and CONFIG 1 REGISTER
	//{1, false, kSPIFI_DataOutput, 0, kSPIFI_CommandAllSerial, kSPIFI_CommandOpcodeAddrThreeBytes, 0x71}};
#endif


void check_if_finish()
{
    uint8_t val = 0;
    /* Check WIP bit */
    do
    {
        SPIFI_SetCommand(EXAMPLE_SPIFI, &command[GET_STATUS]);
        while ((EXAMPLE_SPIFI->STAT & SPIFI_STAT_INTRQ_MASK) == 0U)
        {
        }
        val = SPIFI_ReadDataByte(EXAMPLE_SPIFI);
    } while (val & 0x1);
}

#if defined QUAD_MODE_VAL
void enable_quad_mode()
{
    /* Write enable */
    SPIFI_SetCommand(EXAMPLE_SPIFI, &command[WRITE_ENABLE]);

    /* Set write register command */
    SPIFI_SetCommand(EXAMPLE_SPIFI, &command[WRITE_REGISTER]);
#if defined FLASH_S25FL
    SPIFI_WriteDataByte(EXAMPLE_SPIFI, 0x00);
#endif
    SPIFI_WriteDataByte(EXAMPLE_SPIFI, QUAD_MODE_VAL);

    check_if_finish();
}
#endif
/*******************************************************************************
* Prototypes
******************************************************************************/

/*******************************************************************************
 * variables
 ******************************************************************************/

//uint8_t mem_writeBuffer[PAGE_SIZE];
uint8_t mem_readBuffer[PAGE_SIZE] = {0};
uint8_t mem_readBufferS[SECTOR_SIZE] = {0};


/*******************************************************************************
 * Code
 ******************************************************************************/


/*void SPIFI_Clock(spifi_nor_clock_init_t clock)
{
	uint32_t sourceClockFreq;

	switch(clock)
	{
		case kSpifiNorClockInit_Max:
	    sourceClockFreq = CLOCK_GetFroHfFreq();
	    CLOCK_SetClkDiv(kCLOCK_DivSpifiClk, sourceClockFreq / SPIFI_CLOCK_FREQ_MAX, false);
	    break;
		case kSpifiNorClockInit_Sdfp:
        default:
	    sourceClockFreq = CLOCK_GetFroHfFreq();
	    // Set the clock divider.
	    CLOCK_SetClkDiv(kCLOCK_DivSpifiClk, sourceClockFreq / SPIFI_CLOCK_FREQ_MIN, false);
	    break;
	}
}*/

/**********************************************************************************************
                    FUNCIONES DE BAJO NIVEL
**********************************************************************************************/
/* Configuracion inicial de la memoria
 *
 * Activa alimentacion, Activa Reset
 * Pone pines en valores por defecto */
//void memOn(void){}; //todo implemantar
void memOn(void){
    spifi_config_t config = {0};
    uint32_t sourceClockFreq;
    /* Set SPIFI clock source */
    CLOCK_AttachClk(kFRO_HF_to_SPIFI_CLK);
    sourceClockFreq = CLOCK_GetFroHfFreq();


    /* Set the clock divider */
    CLOCK_SetClkDiv(kCLOCK_DivSpifiClk, sourceClockFreq / EXAMPLE_SPI_BAUDRATE, false);

    /* Initialize SPIFI */
    SPIFI_GetDefaultConfig(&config);
    SPIFI_Init(EXAMPLE_SPIFI, &config);

#if defined QUAD_MODE_VAL
    /* Enable Quad mode */
    enable_quad_mode();
#endif

    /* Setup memory command */
   // SPIFI_SetMemoryCommand(EXAMPLE_SPIFI, &command[READ]);
}

/*  Pone pines en 0, Corta la alimentacion */
void memOff(void){};//todo implemantar


/**********************************************************************************************
                    FUNCIONES DE ALTO NIVEL
**********************************************************************************************/

/* Valida los punteros de Inicio y Fin de una pila */
uint8_t memCheckPila(uint8_t pila)  //todo ver!!
{   uint32_t cnt=10, ok;
    do{
      ok = 1;
      memRdCfgFlash(pila);
      if( !cfgReg.pageFin || (cfgReg.pageFin>=Format[pila].Long) ) ok = 0;
      if( !cfgReg.pageIni || (cfgReg.pageIni>=Format[pila].Long) ) ok = 0;
      cnt--;
    }while(!ok && cnt);
    return ok;  // Si leyo 10 veces mal la config -> retorna error (-> borra la pila)
}

/**********************************************************************************************
   FUNCIONES DE ALTO NIVEL - SON LAS QUE SE COMPARTEN !!!
**********************************************************************************************/
void memInit(void)
{ uint8_t i, ok;
  uint16_t fechaReg;
  memOn();

  // Arreglar fecha en caso que no este OK antes de chequear memorias y ... posiblemente inicializarlas
  // Valido fecha actual con fecha del reg "Time" de la pila "Eventos en Mem Interna"
  // Leo "Date de Flash" en tempReg[1]
  ok = memCheckPila(18);
  if(ok)
  {   memRdFlash((uint8_t*)&fechaReg, Format[18].Start+cfgReg.pagePast, cfgReg.offsetPast+2, 2);
      if((Status.ErrRTC!=0) && (fechaReg>Rtc.Date) && (fechaReg<20000U))
      {   Rtc.Date = fechaReg;
          rtcSet(Rtc);
      }
  }
  else fechaReg = Rtc.Date;

  // Chequeo pilas, doy formato inicial si es necesario
  for(i=0; i<19; i++)
  {
      /*TODO memExterna, por ahora no hay
       * if(!__PORTLP_bit.MemAusente)
      { Status.MemExt = 1;
        ok = memCheckPila(i);  // Valida los punteros pageIni, pageFin
        if(!ok) memBorrarPila(i);
      }*/
      Status.MemExt = 0;
      ok = memCheckPila(i);  // Valida los punteros pageIni, pageFin
      if(!ok) memBorrarPila(i);
  }
  // Si fecha actual es mayor al dia actual de registros se introduce un nuevo registro Time
  if(fechaReg < Rtc.Date) execProcDia();
}

/*
  Lee bytes desde una pagina de Flash
  Parametros
	ptrDest: bufer donde se colocan los bytes leidos
	page: pagina desde la cual se lee
	byteIni: byte inicial en la pagina a leer
	bytes: 0..255 - cantidad de bytes a leer
*/
void memRdFlash(uint8_t *ptrDest, uint16_t page, uint8_t byteIni, uint8_t bytes)
{
  uint32_t i,ini;//,prim;
  //uint32_t address = NOR_FLASH_START_ADDRESS + norHandle.bytesInPageSize * (uint32_t)page;
  //status_t status;
  //status=Nor_Flash_Read(&norHandle, address, mem_readBuffer,norHandle.bytesInPageSize);
  /* Read PRIMASK register, check interrupt status before you disable them */
      /* Returns 0 if they are enabled, or non-zero if disabled */
     // prim = __get_PRIMASK();

      /* Disable interrupts */
      //__disable_irq();


  SPIFI_SetMemoryCommand(EXAMPLE_SPIFI, &command[READ]);
  ini=(((uint32_t)page)*PAGE_SIZE);
  ini+=FSL_FEATURE_SPIFI_START_ADDR;
  for (i = 0; i < PAGE_SIZE; i++)
  {
  	  mem_readBuffer[i] = * ((uint8_t *)(ini + i)); //el valor apuntado
  }
  //(&mem_readBuffer[0]) = (uint8_t *)(FSL_FEATURE_SPIFI_START_ADDR + page);

  //memcpy(destino, origen, cantidad)
  if (ptrDest!=NULL)  memcpy(ptrDest, &mem_readBuffer[(uint32_t)byteIni],bytes);

  /* Enable interrupts back */
     // if (!prim) {
     //     __enable_irq();
     //e }

/*
  memEna(page);    // /CS Low  -> Inicio
  memRW(READ_MMP); // OPCODE	-> 0x52  para Buff 1
  memRW( (unsigned char)(page>>7) );     // 15b page Address
  memRW( (unsigned char)(page<<1) & 0xfe );
  memRW( byteIni );                      // 9b byte Address - MSBit first
  for (i=0; i<4; i++)    memRW(0);       // 32b don´t care
  for (i=0; i<bytes; i++)       // CK out Datos desde Flash
    ptrDest[i] = memRW(0);
  memDis();   // /CS High -> Fin
  */
}



void memRdFlashS(uint8_t *ptrDest, uint16_t page, uint8_t byteIni, uint8_t bytes)
{
  uint32_t i, sector;
  sector=(((uint32_t)page)*PAGE_SIZE)/SECTOR_SIZE;
  SPIFI_SetMemoryCommand(EXAMPLE_SPIFI, &command[READ]);
  sector=FSL_FEATURE_SPIFI_START_ADDR + (sector*SECTOR_SIZE);

  for (i = 0; i < SECTOR_SIZE; i++)
  {
  	  //mem_readBuffer[i] = * ((uint8_t *)(FSL_FEATURE_SPIFI_START_ADDR + (page*PAGE_SIZE) + i)); //el valor apuntado
	  mem_readBufferS[i] = * ((uint8_t *)(sector + i)); //el valor apuntado
  }
  if (ptrDest!=NULL)  memcpy(ptrDest, &mem_readBufferS[(uint32_t)byteIni],bytes);


}
/* Lee cfgReg de una determinada pila */
void memRdCfgFlash(uint8_t pila)
{
  uint8_t *ptr;
  uint16_t page;

  ptr = (uint8_t*)&cfgReg;
  // Leo cfgReg de la pag 0
  page = Format[pila].Start;

  /*
  memEna(page);    // /CS Low  -> Inicio
  memRW(READ_MMP); // OPCODE	-> 0x52  para Buff 1
  memRW( (unsigned char)(page>>7) );    // 15b page Address
  memRW( (unsigned char)(page<<1) & 0xfe );
  memRW( 0 );                      	// 9b byte Address - MSBit first
  for (i=0; i<4; i++)    memRW(0);      // 32b don´t care
  for (i=0; i<7; i++)    ptr[i] = memRW(0);   // 7 bytes de la struct cfgReg
  memDis();   // /CS High -> Fin
  */
  memRdFlash(ptr,page,0,7);

  // Leo offset de la pageFin
  page = Format[pila].Start + cfgReg.pageFin;

  memRdFlash(NULL,page,0,0);
  cfgReg.offsetFin=mem_readBuffer[256];
  cfgReg.offsetTime=mem_readBuffer[257];
  /*
  memEna(page);    // /CS Low  -> Inicio
  memRW(READ_MMP); // OPCODE	-> 0x52  para Buff 1
  memRW( (unsigned char)(page>>7) );   // 15b page Address
  memRW( (unsigned char)((page<<1) | 0x01));
  for (i=0; i<5; i++)   memRW(0); // 9b offset Address + 32b don´t care
  cfgReg.offsetFin = memRW(0);    // Lee byte 256
  cfgReg.offsetTime = memRW(0);   // Lee byte 257
  memDis();   // /CS High -> Fin
  */
}







/*  Escribe el Buffer 1 en una pagina de Flash
    Parametros	page:	Pagina de Flash a escribir 0..6143  */
void memWrBufAFlash (uint32_t page)
{
   //uint32_t address = NOR_FLASH_START_ADDRESS + norHandle.bytesInPageSize * (uint32_t)page;
   //status_t status;
   //status=Nor_Flash_Page_Program(&norHandle, address, mem_readBuffer);
   uint32_t i, j, k, data,sector;//,prim;

   /* Read PRIMASK register, check interrupt status before you disable them */
       /* Returns 0 if they are enabled, or non-zero if disabled */
     //  prim = __get_PRIMASK();  NO deshabilitar!!!! deja de escribir memoria! boludazo
       /* Disable interrupts */
       //__disable_irq();

   /* Reset the SPIFI to switch to command mode */
   SPIFI_ResetCommand(EXAMPLE_SPIFI);
   EnableIRQ(SPIFI0_IRQn);
   memRdFlashS(NULL,page, 0, 0);

   sector=(page/PAG_POR_SECTOR);

   //memcpy(out,in + start_offset, total_len - end -start_offset);
   memcpy(&mem_readBufferS[(page%PAG_POR_SECTOR)*PAGE_SIZE],&mem_readBuffer[0],PAGE_SIZE);
   /* Write enable */
   SPIFI_SetCommand(EXAMPLE_SPIFI, &command[WRITE_ENABLE]);

   //page ahora va a ser la pagina inicial del sector
   page=(sector*SECTOR_SIZE);///PAG_POR_SECTOR;

   /* Set address */
   SPIFI_SetCommandAddress(EXAMPLE_SPIFI, page);
   /* Erase sector */
   SPIFI_SetCommand(EXAMPLE_SPIFI, &command[ERASE_SECTOR]);
   /* Check if finished */
   check_if_finish();



   for (k=0; k<SECTOR_SIZE; k+=PAGE_SIZE_){
	   SPIFI_SetCommand(EXAMPLE_SPIFI, &command[WRITE_ENABLE]);
	   SPIFI_SetCommandAddress(EXAMPLE_SPIFI, page+ k);//(k * PAGE_SIZE_));
	   SPIFI_SetCommand(EXAMPLE_SPIFI, &command[PROGRAM_PAGE]);

	   for (i = 0; i < PAGE_SIZE_;  i += 4)
          {
        	  data = 0;
        	  for (j = 0; j < 4; j++)
              {
                  data |= ((uint32_t)(mem_readBufferS[k+ i + j])) << (j * 8);
              }
              SPIFI_WriteData(EXAMPLE_SPIFI, data);
              //SPIFI_WriteDataByte(EXAMPLE_SPIFI, g_buffer[i]);
          }
       check_if_finish();
       k+=PAGE_SIZE_;

       SPIFI_SetCommand(EXAMPLE_SPIFI, &command[WRITE_ENABLE]);
	   SPIFI_SetCommandAddress(EXAMPLE_SPIFI, page+ k);//(k * PAGE_SIZE_));
	   SPIFI_SetCommand(EXAMPLE_SPIFI, &command[PROGRAM_PAGE]);
	   for (i = 0; i < PAGE_SIZE_;  i += 4)
			{
			  data = 0;
			  for (j = 0; j < 4; j++)
				{
					data |= ((uint32_t)(mem_readBufferS[k+ i + j])) << (j * 8);
				}
				SPIFI_WriteData(EXAMPLE_SPIFI, data);
				//SPIFI_WriteDataByte(EXAMPLE_SPIFI, g_buffer[i]);
			}
		check_if_finish();
   }
  /* Reset to memory command mode */
  SPIFI_ResetCommand(EXAMPLE_SPIFI);
  /*memEna(page);	  // /CS Low  -> Inicio
  memRW(WRITE_BUF1_MMP); // OPCODE -> 0x83
  memRW( (unsigned char)(page>>7)); // 15b page Address - MSBit first
  memRW( (unsigned char)(page<<1) & 0xfe ); // 9b don´t care
  memRW(0);
  memDis();   // /CS High -> ahora se programa
  memWaitForReady(page);  // Espera fin de programacion
  */

  /* Enable interrupts back */
//      if (!prim) {
 //         __enable_irq();
 //    }

}

/*	memWrBuf
	Escribe un nuevo registro en el buffer temporal 1 de la memoria Flash
	Primero escribe la hora y luego los bytes de datos
	Parametros:
		datos: puntero al buffer con los datos de origen
		byteIni: byte inicial dentro del buffer de la Flash: 0..255
		bytes: cantidad de bytes de datos a escribir
*/
void memWrBuf(uint16_t page, uint8_t *datos, uint32_t byteIni, uint32_t bytes)
{
  /*unsigned char i;
  memEna(page);   // /CS Low  -> Inicio
  memRW(WRITE_BUF1);  // OPCODE	 -> 0x84
  memRW( 0 );         // 15b don´t care
  memRW( 0 );
  memRW( byteIni );   //  9b byte inicial del buffer a escribir
  */
	 uint32_t i;
  //la memoria esta leida en mem_readbuffer[]
  for (i=0; i<bytes; i++)
	  mem_readBuffer[byteIni+i]=datos[i];
  //memDis();
}

/* Escribe la estructura de cfgReg en la pagina "page" de manera segura
    pageIni       Page Cofig: b0, b1
    pageFin       Page Cofig: b2, b3
    pagePast      Page Cofig: b4, b5
    offsetPast    Page Cofig: b6
    offsetFin     Page: b256, posicion del proximo registro a escribir
    offsetTime    Page: b257, posicion de registro Time en la pag
*/
void memWrPageConfig(uint32_t pila)
{
    uint32_t cnt = 0;
    uint16_t page;
    page = Format[pila].Start;
    do{
    	//memset(mem_readBuffer,0xff,sizeof(mem_readBuffer));//borra el readbuffer para no escribir basura
        memWrBuf(page, (uint8_t*)&cfgReg, 0, 7);   // Escribo Buffer
        memWrBufAFlash(page);                            // Copio buffer a Flash
        memRdFlash((uint8_t*)&tmpCfg, page, 0, 7); // Re leo Flash
        cnt++;
    }while(( (cfgReg.pageIni!=tmpCfg.pageIni) || (cfgReg.pageFin!=tmpCfg.pageFin) ||
             (cfgReg.pagePast!=tmpCfg.pagePast) || (cfgReg.offsetPast!=tmpCfg.offsetPast) ) && (cnt<3));
}



/*  Guarda un dato en el byte 256 del BUF1. Ptr al registro proximo a utilizar
    Parametros: byte = 0 -> pone a CERO todo el buffer
	            != 0 -> escribe el byte en la posicion 256
*/
void memWrOffset(uint16_t page, uint8_t offsetFin, uint8_t offsetTime)
{
	//page esta por compatibilidad, escribe direactamente sobre el buffer
	//siempre se llama con el buffer cargado
	mem_readBuffer[256]=offsetFin;
	mem_readBuffer[257]=offsetTime;
/*
  memEna(page);
  memRW(WRITE_BUF1);  // opcode
  memRW( 0 );         // 15b don´t care
  memRW( 1 );   // Add=256
  memRW( 0 );   // 9b byte address
  memRW(offsetFin);   // byte 256
  memRW(offsetTime);  // byte 257
  memDis();    // /CS: low -> high
  */
}


uint8_t memRdOffsetTime(uint16_t page)
{
  uint8_t offTime;
  uint32_t i;
  SPIFI_SetMemoryCommand(EXAMPLE_SPIFI, &command[READ]);

  i=257;  //lee offsetTime en la posicion 255 de la pagina
  offTime = * ((uint8_t *)(FSL_FEATURE_SPIFI_START_ADDR + ((uint32_t)page*PAGE_SIZE) + i));
 /*
  memEna(page);    // /CS Low  -> Inicio
  memRW(READ_MMP); // OPCODE	-> 0x52  para Buff 1
  memRW( (unsigned char)(page>>7) );     // 15b page Address
  memRW( (unsigned char)(page<<1) | 0x01 );
  memRW( 0x01 );                      // Addres = 257
  for (i=0; i<4; i++)    memRW(0);       // 32b don´t care
  offTime = memRW(0);
  memDis();   // /CS High -> Fin
  */
  return offTime;
}

/* Funcion que controla el avance de la pila
Se ingresa con la estructura cfgReg cargada
  cfgReg.offsetFin = 0
  cfgReg.offsetTime = 0xff
  cfgReg.pagePast ya actualizado
  cfgReg.offsetPast ya actualizado
  cfgReg.pageFin es la que tiene que avanzar -> avanzar pageIni si es necesario
  cfgReg.pageIni !!??¿??¿?
  El avance de la pagina de inicio debe contemplar el avande de los punteros Past, PtrXXTxed, y la
  posible eliminacion de un registro Time -> la lectura de datos podria no quedar sincronizada y daria error
  Solucion: se adopta que se avanza hasta el proximo registro Time, principio del siguiente dia
  Para esto en cada pag, en la posicion 257 se pone el offset del registro Time que se haya guardado en la misma,
  Si no tiene reg Time el byte 257 vale 0xff

  Retorno:  !=0 si esta todo OK;  =0 si no se puede porque pisa el puntero "Past" */
uint8_t memIncPageFin(uint8_t pila)
{
   uint8_t offsetTime;
   uint32_t cnt;
   uint16_t pgFinTmp, pgTmp;
   __ptrEnd *ptr;

   pgFinTmp = cfgReg.pageFin;
   cfgReg.pageFin++;
   if(cfgReg.pageFin >= Format[pila].Long) cfgReg.pageFin = 1;  //
   // ACA esta el quilombete ... !!!
   if(cfgReg.pageFin == cfgReg.pageIni)
   {
      cnt = 0;
      if(cfgReg.pageIni == cfgReg.pagePast) // Se lleno la pila en menos de un dia !!!
      {   cfgReg.pageIni += 4;  // Avanzo 4 paginas
          if(cfgReg.pageIni >= Format[pila].Long) cfgReg.pageIni = cfgReg.pageIni - Format[pila].Long + 1;
          cfgReg.pagePast = cfgReg.pageIni; // Avanzo 4 pgs manteniendo el mismo offset para el Reg Time
          offsetTime = cfgReg.offsetPast;
      }
      else  // avanzo el inicio 4 pgs o hasta encontrar la proxima pg con un registro Time
      {   do{   cfgReg.pageIni++;
                if(cfgReg.pageIni >= Format[pila].Long) cfgReg.pageIni = 1;
                offsetTime = memRdOffsetTime(Format[pila].Start + cfgReg.pageIni);
                cnt++;
          }while((offsetTime == 0xff) && (cnt<4));
          if(offsetTime == 0xff) cnt++;
      }
      // cnt=0 -> pagePast;  cnt=1..4 -> page con reg Time; cnt=5 -> pages comunes
      if(cnt < 5)  // Reg Time ubicado en: pageIni, offsetTime
      {
          if(cnt==0)  // Cargar reg PAST con el mismo offset que el anterior pero 4 pgs mas adelante
          {   tempReg.tr16_t[0] = 0x4000;
              tempReg.tr16_t[1] = Rtc.Date;
              tempReg.tr16_t[2] = 0x2000 | (cfgReg.pageIni & 0x1fff);
              tempReg.tr16_t[3] = (uint16_t)offsetTime;
              //memRdFlashABuf(cfgReg.pageIni + Format[pila].Start);  // Pg actual de Flash a Buffer
              memRdFlash(NULL,cfgReg.pageIni + Format[pila].Start,0,0);
              if(offsetTime <= 248)
              {   memWrBuf(cfgReg.pageIni + Format[pila].Start, (uint8_t*)tempReg.tr8_t, offsetTime, 8);
                  memWrOffset(cfgReg.pageIni+ Format[pila].Start, 0, offsetTime);  // pongo offsetTime
                  memWrBufAFlash(cfgReg.pageIni + Format[pila].Start);
              }
              else  // escribo el registro Time partido en 2 paginas
              {   memWrBuf(cfgReg.pageIni + Format[pila].Start, (uint8_t*)tempReg.tr8_t, offsetTime, 4);
                  memWrOffset(cfgReg.pageIni+ Format[pila].Start, 0, offsetTime);  // pongo offsetTime
                  memWrBufAFlash(cfgReg.pageIni + Format[pila].Start);
                  pgTmp = cfgReg.pageIni+1;
                  if(pgTmp >= Format[pila].Long) pgTmp = 1;
                  //memRdFlashABuf(pgTmp + Format[pila].Start);
                  memRdFlash(NULL,pgTmp + Format[pila].Start,0,0);
                  memWrBuf(pgTmp + Format[pila].Start, ((uint8_t*)tempReg.tr8_t)+4, 0, 4);
                  memWrBufAFlash(pgTmp + Format[pila].Start);
              }
          }
          else  // Modificar el registro Time para que apunte a si mismo: primer dia de la pila
          {   tempReg.tr16_t[0] = 0x2000 | (cfgReg.pageIni & 0x1fff);
              tempReg.tr16_t[1] = (uint16_t)offsetTime;
              offsetTime += 4;
              if(offsetTime <= 248)  pgTmp = cfgReg.pageIni; //MAC era 248, cambiado para que entre
              else
              {   pgTmp = cfgReg.pageIni+1;
                  if(pgTmp >= Format[pila].Long) pgTmp = 1;
              }
              //memRdFlashABuf(pgTmp + Format[pila].Start);
              memRdFlash(NULL,pgTmp + Format[pila].Start,0,0);
              memWrBuf(pgTmp + Format[pila].Start, (uint8_t*)tempReg.tr8_t, offsetTime+4, 4);
              memWrBufAFlash(pgTmp + Format[pila].Start);
          }
      }

      // Veo si pageIni arrastro alguno de los punteros ...Txed, siempre y cuando se trate de la memExterna
      if(((pila==17)  || (pila==18)) && !Status.MemExt)
      {   if(pila==17)    ptr = &PtrTxTxed;
          else            ptr = &PtrEvTxed;
          if(pgFinTmp >= cfgReg.pageIni)
          {   if((ptr->page < cfgReg.pageIni) || (ptr->page > pgFinTmp))
              {   ptr->page = cfgReg.pageIni;
                  ptr->offset = offsetTime;
                  uniSaveTxed();
              }
          }
          else
          {   if((ptr->page < cfgReg.pageIni) && (ptr->page > pgFinTmp))
              {   ptr->page = cfgReg.pageIni;
                  ptr->offset = offsetTime;
                  uniSaveTxed();
              }
          }
      }
   }
   cfgReg.newData = 1;
   return 1;
}


/*  Escribe un nuevo registro en la flash
      pila: 0..15 Sensores Anal, 16: pluvi, 17: cola Tx, 18: Eventos
      datos: ptr al buffer con el registro a grabar en flash
      bytes: tamaño en bytes del registro
      newDay: pone 1 registro Time en pila, no le da bola a datos */
void memWrReg(uint32_t pila, uint8_t *datos, uint8_t bytes)
{
  uint16_t tmpStart;
  uint8_t espacio, tmpBytes, *tmpDatos;

  tmpStart = Format[pila].Start;
  tmpBytes = bytes;
  tmpDatos = datos;
  memRdCfgFlash(pila); // Cargo la config de la pila
  cfgReg.newData = 0; // flag q indica modif del regCfg
  // Valido pageFin en estructura de Config
  if(cfgReg.pageFin && (cfgReg.pageFin < Format[pila].Long))
	  {   memRdFlash(NULL,cfgReg.pageFin + tmpStart,0,0);
		  espacio = (cfgReg.offsetFin^0xff) + 1;   // ofsset=0xf8-> espacio = 7+1 = 8
		  // Evaluar si requiere salto de pagina
		  if((tmpBytes>=espacio) && cfgReg.offsetFin) // grabo los bytes que entran y salto de pagina
		  {   memWrBuf(cfgReg.pageFin+tmpStart, tmpDatos, cfgReg.offsetFin, espacio);  // Registro de Dato
			  // No actualizo offsetFin y offsetTime en esta pagina !!!
			  memWrBufAFlash(cfgReg.pageFin + tmpStart);
			  cfgReg.offsetFin = 0;
			  cfgReg.offsetTime = 0xff;
			  tmpBytes -= espacio; // bytes restantes para la pag siguiente
			  tmpDatos += espacio; // adelanto puntero
			  memIncPageFin(pila);
		  }
		  // Cargar nuevo registro
		  if(tmpBytes)
		  {   memWrBuf(cfgReg.pageFin+tmpStart, tmpDatos, cfgReg.offsetFin, tmpBytes);  // Registro de Dato
			  cfgReg.offsetFin += tmpBytes;      // Incremento Offset segun el registro cargado
		  }
		  memWrOffset(cfgReg.pageFin+tmpStart, cfgReg.offsetFin, cfgReg.offsetTime);
		  memWrBufAFlash(cfgReg.pageFin+tmpStart);
	  }
	// Actualizo Page de config si es necesario
    if(cfgReg.newData)  memWrPageConfig(pila);
    //memDelay(10);  // GGB32
#ifdef DEBUG
printf("M");
#endif

  /*
  for(i=0; i<2; i++)  // Memoria Interna y Externa
  {
      tmpBytes = bytes;
      tmpDatos = datos;
      Status.MemExt = i;
      if(Status.MemExt && __PORTLP_bit.MemAusente) break;

      memRdCfgFlash(pila); // Cargo la config de la pila
      cfgReg.newData = 0; // flag q indica modif del regCfg
      // Valido pageFin en estructura de Config
      if(cfgReg.pageFin && (cfgReg.pageFin < Format[pila].Long))
      {   memRdFlashABuf(cfgReg.pageFin + tmpStart);  // Pg actual de Flash a Buffer
          espacio = (cfgReg.offsetFin^0xff) + 1;   // ofsset=0xf8-> espacio = 7+1 = 8
          // Evaluar si requiere salto de pagina
          if((tmpBytes>=espacio) && cfgReg.offsetFin) // grabo los bytes que entran y salto de pagina
          {   memWrBuf(cfgReg.pageFin+tmpStart, tmpDatos, cfgReg.offsetFin, espacio);  // Registro de Dato
              // No actualizo offsetFin y offsetTime en esta pagina !!!
              memWrBufAFlash(cfgReg.pageFin + tmpStart);
              cfgReg.offsetFin = 0;
              cfgReg.offsetTime = 0xff;
              tmpBytes -= espacio; // bytes restantes para la pag siguiente
              tmpDatos += espacio; // adelanto puntero
              memIncPageFin(pila);
          }
          // Cargar nuevo registro
          if(tmpBytes)
          {   memWrBuf(cfgReg.pageFin+tmpStart, tmpDatos, cfgReg.offsetFin, tmpBytes);  // Registro de Dato
              cfgReg.offsetFin += tmpBytes;      // Incremento Offset segun el registro cargado
          }
          memWrOffset(cfgReg.pageFin+tmpStart, cfgReg.offsetFin, cfgReg.offsetTime);
          memWrBufAFlash(cfgReg.pageFin+tmpStart);
      }
      // Actualizo Page de config si es necesario
      if(cfgReg.newData)  memWrPageConfig(pila);
      memDelay(10);  // GGB32
  }*/
  Status.MemExt = 0;
}


/* Se incorpora un registro Time de 8 bytes
   Si el offset de la pila esta en 250 se colocan 4 bytes en la pagina actual y 4 en la siguiente
*/
void memWrRegTime(uint8_t pila)
{
  uint16_t tmpStart;
  uint8_t espacio;

  tmpStart = Format[pila].Start;

  memRdCfgFlash(pila);	// Cargo la config de la pila
  // Valido pageFin en Config
  if(cfgReg.pageFin && (cfgReg.pageFin < Format[pila].Long))
  {
	//memRdFlashABuf(cfgReg.pageFin + tmpStart);  // Pg actual de Flash a Buffer
	memRdFlash(NULL,cfgReg.pageFin + tmpStart,0,0);
    // Salva ptrPast en un registro "Time"
    tempReg.tr16_t[0] = 0x4000;
    tempReg.tr16_t[1] = Rtc.Date;
    tempReg.tr16_t[2] = 0x2000 | (cfgReg.pagePast & 0x1fff);
    tempReg.tr16_t[3] = (uint16_t)cfgReg.offsetPast;
    // Actualiza valores de ptrPast y offsetTime dentro de la pagina
    cfgReg.pagePast = cfgReg.pageFin;       // Guardo la posicion del registro Time
    cfgReg.offsetPast = cfgReg.offsetFin;   // ... antes de incrementar offsetFin
    cfgReg.offsetTime = cfgReg.offsetFin;
    // Evaluar si cabe el nuevo registro en Pg actual
    if(cfgReg.offsetFin >= 248) //MAC era 248, lo cambiamos porque las paginas son mas chicas en esta memoria
    {   espacio = (cfgReg.offsetFin^0xff) + 1; // ofsset=0xf8-> espacio = 7+1 = 8
        memWrBuf(cfgReg.pageFin+tmpStart, (uint8_t*)tempReg.tr8_t, cfgReg.offsetFin, espacio); // Registro de Dato
        memWrOffset(cfgReg.pageFin+tmpStart, cfgReg.offsetFin, cfgReg.offsetTime);  // Guardo el offsetTime !!!
        memWrBufAFlash(cfgReg.pageFin+tmpStart);
        cfgReg.offsetFin = 0;
        cfgReg.offsetTime = 0xff;
        espacio = 8 - espacio; // bytes restantes para la pag siguiente
        memIncPageFin(pila);  // Modifica cfgReg.pageFin y si es necesario cfgReg.pageIni, cfgReg.pagePast
    }
    else espacio = 8;
    // Escribo registro en pageFin actual
    if(espacio)
    {   memWrBuf(cfgReg.pageFin+tmpStart, ((uint8_t*)tempReg.tr8_t)+8-espacio, cfgReg.offsetFin, espacio);
        cfgReg.offsetFin += espacio;
    }
    // Escribo el registro en la flash, o bien el offset
    memWrOffset(cfgReg.pageFin+tmpStart, cfgReg.offsetFin, cfgReg.offsetTime);
    memWrBufAFlash(cfgReg.pageFin+tmpStart);

    // Escribo pag de config, No importa q hay en el buffer en este momento ...
    memWrPageConfig(pila);
  }
}



/* Borra todas las pilas de registro */
void memBorrarPila(uint8_t pila)
{
  cfgReg.pageIni = 1;
  cfgReg.pageFin = 1;
  cfgReg.pagePast = 1;  // Comienzo del dia en page 1, offset 0
  cfgReg.offsetPast = 0;
  cfgReg.offsetFin = 8;  // Dir de Proximo reg a escribir
  cfgReg.offsetTime = 0; // Offset del reg Time
  tempReg.tr16_t[0] = 0x4000;
  tempReg.tr16_t[1] = Rtc.Date;
  tempReg.tr16_t[2] = 0x2001;    // pagePast=1
  tempReg.tr16_t[3] = 0;         // offsetPast=0

  // Escribo pag de config, No importa q hay en el buffer en este momento ...
  memWrPageConfig(pila);

  //memset(void *str, int c, size_t n)
  memset(&mem_readBuffer, 0xFF, PAGE_SIZE);
  // Escribo reg Time y Offset=8 en la pagina 1
  memWrBuf(Format[pila].Start+1, (uint8_t *)tempReg.tr8_t, 0, 8);
  memWrOffset(Format[pila].Start+1, cfgReg.offsetFin, cfgReg.offsetTime);
  memWrBufAFlash(Format[pila].Start+1);
}
