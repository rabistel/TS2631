/*
 * cpuUNIcation1.c
 * Procesador de comunicaciones
 ******************************
 * Aquí estan todas las funciones que interpretan los frames
 *  recibidos de la UART y de la IO.
 * Está toda la interpretación de los comandos y datos de UART
 ******************************************************************** *  Created on: 15 ago. 2018
 *      Author: Marcelo.Caamaño
 */
#include "CPU_def.h"
#include "fsl_wwdt.h"

static uint8_t txbuff[128]; //ver despues


uint16_t uniCalcEnvios(uint16_t pageIni, uint8_t offIni, uint16_t pageEnd, uint8_t offEnd, uint8_t pila);

/* Función que envía por el comm serie el frame fabricado previamente
 ********************************************************************/
 void uniTxFrame(void)
 {
   uint32_t Temp;

   //TODO ver como implementar en el nuevo micro
   // Verifica y aplica Delay RTS -> Tx Datos: 10ms x HandShake
   if (Com.DelayHandShake!=0)
   {
      //__PORTCD_bit.RTS = 1;   // Activa RTS
	   UART0_RTS_1;
      if(Com.DelayHandShake > 100) Com.DelayHandShake=100;
      for(Temp=0; Temp<Com.DelayHandShake; Temp++) lowTimer(1); // delays de 10ms ver!!
   }
   // Tx Encabezado del Frame - HEADER

   uint32_t txcnt;//
   txcnt=0;
   s_sendSize=0;
   //txusbCNT=s_sendSize;//=0;
   for(PtrUART=&BufUart.Ast; PtrUART<=&BufUart.CheckSum; PtrUART++)
   {
      //while (__ENU_bit.tbmt==0){}; // Espera mientras busy
      //__TBUF = *PtrUART;
	  txbuff[txcnt]=*PtrUART;
	  s_currSendBuf[s_sendSize]=*PtrUART;
	  //printf("%c",(*PtrUART));
	  txcnt++;
	  s_sendSize++;
   };
   //s_sendSize+=txcnt;
   //txusbCNT

  // USART_WriteBlocking(USART_RTU, txbuff, txcnt);

   // Tx Datos del Frame - DATA

   //usart_transfer_t datosT;

   if (Status.WithData) 
   {
	//  txcnt=0;
	  for (PtrUART=&DataCom.BufData[0]; PtrUART<=&DataCom.CheckSum; PtrUART++)
      {
          //while (__ENU_bit.tbmt==0){};
          //__TBUF = *PtrUART;
    	  txbuff[txcnt]=*PtrUART;
    	  s_currSendBuf[s_sendSize]=*PtrUART;
    	  //printf("%c",(*PtrUART));
    	  txcnt++;
    	  s_sendSize++;
      }

   }
    //USART_WriteBlocking(USART_RTU, txbuff, txcnt);
    while(txOnGoing){}; //espera que termine de tranmitir trama anterior
    sendXfer.data = txbuff;
    sendXfer.dataSize = txcnt;
    txBufferFull=true; //le digo que envie

    txOnGoing = true;
    //USART_TransferSendDMA(USART_RTU, &g_uartDmaHandle, &sendXfer);
   //datosT.data=txbuff;
   //datosT.dataSize=txcnt;
   USART_TransferSendNonBlocking(USART_RTU,&g_uartHandle,&sendXfer);

   // Estados de la UART
     Status.UartFull=0;

   //__ENUI_bit.eri=1;  // Habilita nuevamente la Rx Int
   //EnableIRQ(USART_RTU_IRQn);
   //USART_EnableRxDMA(USART_RTU,true);


   BufUart.BufState = HeaderAst;
   // Ver que no se prolongue eternamente la ventana con el comoando RdCoreState que manda el AS3006/7
   if((Status.TxMand) || (Status.TxWndw) || (Status.TxEvent))
       if (NextAgend.Long<=1) NextAgend.Long++;  // baje de 2 a 1
   if (Status.Com2On) BufUart.TimeOut = 5;   // Trigger el time out: 5 seg
   //while (__ENUR_bit.xmtg){};

   // Baja el RTS
   //__PORTCD_bit.RTS=0;
   UART0_RTS_0;
}

/* Función que calcula el checksum del frame de comando de la uart
 *****************************************************************/
 void uniCalcCheck(void)
 {
   BufUart.CheckSum=0;
   for (PtrUART=&BufUart.Ast; PtrUART<&BufUart.CheckSum; PtrUART++)
       BufUart.CheckSum=BufUart.CheckSum+*PtrUART;
 }

/* Funcion que calcula el checksum del frame de datos de la uart
***************************************************************/
uint8_t uniCalcDataCheck(void)
{
uint8_t CheckTmp;
CheckTmp=0;
for (PtrUART=&DataCom.BufData[0]; PtrUART<&DataCom.CheckSum; PtrUART++)
	CheckTmp=CheckTmp+*PtrUART;
return (CheckTmp);
}

/* Función que lee los IO instantánemente
****************************************
* Se le envía el comando a la IO, y se transmite integramente lo que envió.
***************************************************************************/
void uniMakeRdInst(void)
{
	uint32_t Cnt=0;
	__canal Canales;
	//__InstADprom	InstADprom;
	__Tipo *TipoPtr_;  //ver si global
 //TODO: leer instantaneos y mandar por COM
    //intraRdInstUWIRE();
	/* Ejecuta la lectura de las entradas y salidas
	 **********************************************
	 * Lee la última lectura disponible de todos los canales analógicos y digitales.
	 * También las salidas.
	 **********************/
	//TODO ver si meter en una funcion (y donde)
	CntInstantaneo=0x0a;       // TimeOut de la medicion instantanea
	StatusIO.Instantaneo=1;
    //__PORTED_bit.Cut2=1;
    //__PORTED_bit.Cut1=1;
    HAB_12V_VSW2_ON;
    HAB_12V_VSW1_ON;
    LED_R_ON;

    //cadCalAD();    // Calibracion del CAD

    ///pone a cero todos los valores en el vector de promediado
   // InstADprom.Ptr = &InstADprom.Canal1; // Para dejar indexado todos los canales
   // for (Canales=Canal1; Canales<CanalOla; Canales++){
   // 	(*InstADprom.Ptr) =0;
   // 	InstADprom.Ptr++;
   // }
/*    do{
        FlagsAD.MeterAll=1;
        cadConvAll();
        //va sumando los valores leidos en el canal de promediado
        InstADprom.Ptr = &InstADprom.Canal1; // Para dejar indexado todos los canales
        InstAD.Ptr=&InstAD.Canal1;
        for (Canales=Canal1; Canales<CanalOla; Canales++)
        {
        	(*InstADprom.Ptr) += (*InstAD.Ptr);
        	InstAD.Ptr++;
        	InstADprom.Ptr++;
        }
        Cnt++;
    }while((Cnt<3));// && BitValid.MalAD); //ADQUIERE 4 veces
*/
    do{
		cadCalAD();    // Calibracion del CAD
		FlagsAD.MeterAll=1;
		cadConvAll();
		}
    while((++Cnt<2)&&(BitValid.MalAD));

	RS485_instantaneos();
/*	InstADprom.Ptr = &InstADprom.Canal1; // Para dejar indexado todos los canales
	InstAD.Ptr=&InstAD.Canal1;
	for (Canales=Canal1; Canales<CanalOla; Canales++)
	{
		TipoPtr_=&Tipo[Canales];
        //if(ChPtr485->Flags.On) //canal habilitado
        if((*TipoPtr_)==RS485) //canal es RS485
        {
			(*InstADprom.Ptr) = 4 * (*InstAD.Ptr);
        }
        InstAD.Ptr++;
        InstADprom.Ptr++;
	}
*/

	 //uWireBuf.Ptr=&uWireBuf.Data[0];
	 //uWireBuf.State.Gral=Ok;
	 //uWireBuf.Long=64;
	 PtrUART=&DataCom.BufData[0];
	 InstAD.Ptr=&InstAD.Canal1;
	 //InstADprom.Ptr = &InstADprom.Canal1;
	 // Copia las mediciones de las 16 EA  al buffer
	 for (Canales=Canal1; Canales<CanalOla; Canales++){
	    //uWireBuf.Value[Cnt]=*InstAD.Ptr;
		// // (*InstAD.Ptr)=(uint16_t)(*InstADprom.Ptr)/4; //corre 2 lugares (divide por 4)
		*PtrUART= (BitValid.MalAD ? 0 : (uint8_t) *InstAD.Ptr);
		PtrUART++;
		*PtrUART= (BitValid.MalAD ? 0 : (uint8_t) (*InstAD.Ptr >> 8));
		PtrUART++;
	    InstAD.Ptr++;
	    //InstADprom.Ptr++;
	    };
	 //uWireBuf.Value[28]=InstAD.Cangilones-Pluviometro.TPluviometrico.ValorCero;
	 PtrUART=&DataCom.BufData[56];
	 uint16_t aux=(uint16_t) InstAD.Cangilones;//-Pluviometro.TPluviometrico.ValorCero;
	 *PtrUART= (uint8_t) aux;
	 PtrUART++;
	 *PtrUART= (uint8_t) (aux >> 8);
	 PtrUART++;

	 //uWireBuf.Value[29]=0;
	 //uWireBuf.Value[29]= __PORTAP;
	 //uWireBuf.Value[29]<<=2;
	 //if (__PORTLP_bit.Ps1)uWireBuf.Value[29]+=1;
	 //if (__PORTLP_bit.Ps2)uWireBuf.Value[29]+=2;
     aux=1u;
	 //todo asignar a aux el valor de __portap
	 *PtrUART= (uint8_t) aux;
	 *PtrUART++;

	 // Cargar valores de SD en byte 59, bits menos significativos
	 // uWireBuf.Data[59] = __PORTEP;   // VERIFICAR !!!

	 //DataCom.BufData[59]=__PORTEP; //TODO

 DataCom.CheckSum = uniCalcDataCheck();
 Status.WithData=1; 
 
}

/* Funcion que ejecuta el reinicio de la UTR en respuesta a un pedido del COM
********************************************/
void uniMakeRestart(void)
{
//  WWDT_Disable(WWDT);
  execMakeReini(BufUart.Rx.Restrt.Code);  // Arma el Evento de Reinicio
  execExePack(&PackTemp.Ev.Config);
  Status.WithData=0;
  
  //ejecuta rutinas de restart
  cpuInicio = 5;
  DisableIRQ(RTC_IRQn);
  ioStartUp();
  vtoFindViento(); //Se busca el canal con anemómetro y veleta para procesar según corresponda
  chIniAnalogicos();
  IniAlimentacion(1);
  __PORTAP_bit.BateriaOK=batADC_ADQ_OK();
  Status.BatOK = 1;
  s_ticker_init_RTC();
  cpuStartUp(0U); //el 0 indica que no se activo el WatchDog
  txedInit(1);
 // WWDT_Enable(WWDT);
}

/* Borrado de la memoria Flash de Datos en respuesta a un pedido del puerto COM
   Todas las pilas quedan vacias
 ******************************/
 void uniMakeReset(void)
 {
   uint8_t pila;
   if(!Status.MemExt)
   { //Se inicializan los punteros de Cola de Transmisión y Eventos pendiente
     PtrTxTxed.page=1;
     PtrTxTxed.offset=0;
     PtrEvTxed.page=1;
     PtrEvTxed.offset=0;
     uniSaveTxed();
   }

   // Borrado de todas las pilas
   //SoftWD = 0;
   for(pila=0; pila<19; pila++) memBorrarPila(pila);

   if(!Status.MemExt)
   { // Delay > 5 seg para que no considere error de borrado de flash
     ticTimer = 8;
     //SoftWD = 0;
     while(ticTimer); // Delay de 8 segundos
     Status.RtcIO = 1; // Sincronismo de Relojes CPU -> IO
   }
 }

/* Función que arma el frame de respuesta a  RdCoreStt
*****************************************************/
void uniMakeRdCoreStt(void)
{
	 BufUart.Tx.RdCoreStt.Seconds = Rtc.Seconds;
	 BufUart.Tx.RdCoreStt.Time = Rtc.Time;
	 BufUart.Tx.RdCoreStt.Date = Rtc.Date;
	 BufUart.Tx.RdCoreStt.State = Status;
	 // Estos flags cambiaron desde las versiones anteriores del TS2621-TR, por eso se fuerzan a 0
	 BufUart.Tx.RdCoreStt.State.BatOK = 0;
	 BufUart.Tx.RdCoreStt.State.ErrRTC = 0;
	 BufUart.Tx.RdCoreStt.State.MemExt = 0;
	 BufUart.Tx.RdCoreStt.State.RtcIO = 0;
	 BufUart.Tx.RdCoreStt.State.ReiniIO = 0;
	 uniCalcCheck();
}


 /* Función que arma y ejecuta el wr core state
  *********************************************/
  void uniMakeWrCoreStt(void)
  {
	  int32_t auxiliar;
	  uint32_t prim;
     if(BufUart.Rx.WrCoreStt.StatusCmd.WrHora)
     {   // Preparo evento de Set RTC y flag p/sincro de la IO
         Status.RtcIO = 1;
         execMakeReini(CambioRTC);
         PackTemp.Ev.Value1 = Rtc.Date;
         PackTemp.Ev.Value2 = Rtc.Time;
         // Verifico si hubo cambio de Fecha
         if(Rtc.Date != BufUart.Rx.WrCoreStt.Date) FlagGral.FechaDist = 1;
         else                                      FlagGral.FechaDist = 0;
         // Programo Fecha-Hora del Sistema y en RTC Hard
         Rtc.Seconds = BufUart.Rx.WrCoreStt.Seconds;
         Rtc.Time = BufUart.Rx.WrCoreStt.Time;
         Rtc.Date = BufUart.Rx.WrCoreStt.Date;
         rtcSet(Rtc);
     }
    // prim = __get_PRIMASK();
    // __disable_interrupt();
     if (BufUart.Rx.WrCoreStt.StatusCmd.TxMand) Status.TxMand=0; // Entrada Agenda con Tx obligatoria
     if (BufUart.Rx.WrCoreStt.StatusCmd.TxWndw) Status.TxWndw=0; // Entrada Agenda modo Rx
     if (BufUart.Rx.WrCoreStt.StatusCmd.TxEvent)Status.TxEvent=0; // Evento "ParamSnsrPC"
     if (BufUart.Rx.WrCoreStt.StatusCmd.TxHora) Status.TxHora=0; // flag para Puesta en Hora de la UTR
     if (BufUart.Rx.WrCoreStt.StatusCmd.TxCond) Status.HayCond=0; // Eventos Limni Asc, Desc, Pluvi delta Tx
     Rtc.CtrlByte=0;
    // if(!prim){
    //     	 __enable_interrupt();
    //      	 }
    //printf("dat: %d, ev: %d",BufUart.Rx.WrCoreStt.StatusCmd.UpDateTx,BufUart.Rx.WrCoreStt.StatusCmd.UpDateEv);
     // Actualizacion de Punteros PtrTxTxEd y PtrEvTxed
     //cfgReg.newData = 0; //MAC2020 ver si esto puede generar problema en guardado de datos; si no, ver como separar adquisicion 
	 auxiliar=0; //no dato a escribir
     if (BufUart.Rx.WrCoreStt.StatusCmd.UpDateEv||BufUart.Rx.WrCoreStt.StatusCmd.UpDateTx)
     //if (BufUart.Rx.WrCoreStt.StatusCmd.UpDateEv) lo pongo asi porque no borraba eventos
     {   Status.MemExt = 0;
         memRdCfgFlash(18);
         PtrEvTxed.page = cfgReg.pageFin;
         PtrEvTxed.offset = cfgReg.offsetFin;
         //cfgReg.newData = 1;
		 auxiliar=1; //MAC2020
     }
     if (BufUart.Rx.WrCoreStt.StatusCmd.UpDateTx)
     {   Status.MemExt = 0;
         memRdCfgFlash(17);
         PtrTxTxed.page = cfgReg.pageFin;
         PtrTxTxed.offset = cfgReg.offsetFin;
         //cfgReg.newData = 1;
		 auxiliar=1;
     }
     //if(cfgReg.newData) uniSaveTxed();  // Salva PtrTxTxEd y PtrEvTxed en Pag 2 de Flash
	 if(auxiliar) uniSaveTxed();  // Salva PtrTxTxEd y PtrEvTxed en Pag 2 de Flash

     // Inserta Registros Time en todas las pilas
     if(FlagGral.FechaDist)   execProcDia();

     if(BufUart.Rx.WrCoreStt.StatusCmd.WrHora)
     {
       uniMakeRstAgend();  // resincroniza la agenda
       execExePack(&PackTemp.Ev.Config);   // Evento de Puesta en Hora
     }


     //Se llamaba en main de IO cuando se cambiaba la hora de RTU. Estimo que acá está bien
     auxiliar=(int32_t)PackTemp.Ev.Value2-(int32_t)Rtc.Time;
     //if(PackTemp.Ev.Value2 != Rtc.Time)
     if(!FlagGral.FechaDist) //si no cambia el dia y la hora difiere en +-30 minutos
    	 if ((auxiliar>30)||(auxiliar<-30))
    	 {
    	  chIniEnHora();
    	 }

  }


/* Función que lee una página de Flash de uno de los uC CPU/IO (64 bytes)
 Son paginas de configuración o texto
 Pagina < 128:  ->  Lee desde uC CPU
 Pagina >= 128: ->  Lee desde uC IO
*****************************************************/
void uniMakeRdPage(void)
{
  uint8_t *PtrTemp;
  //TODO ver! muy interesante,
  if (BufUart.Rx.RdPage.Page<128)
  {
	  lowRdPageC(BufUart.Rx.RdPage.Page); //lee pagina del uC
	  PtrTemp=&Variable[0].Byte.Lo;
	  for (PtrUART=&DataCom.BufData[0]; PtrUART<&DataCom.CheckSum; PtrUART++)
	  {
		  *PtrUART=*PtrTemp;
		  PtrTemp++;
	  }
  }
  else {//intraRdPageUWIRE(BufUart.Rx.RdPage.Page); //Lee pagina del IO
	  lowRdPage(BufUart.Rx.RdPage.Page-128); //lee pagina de IO
	  PtrTemp=&Buffer.Variable[0].Byte.Lo;
	  for (PtrUART=&DataCom.BufData[0]; PtrUART<&DataCom.CheckSum; PtrUART++)
	  {
		  *PtrUART=*PtrTemp;
		  PtrTemp++;
	  }

  }

  DataCom.CheckSum = uniCalcDataCheck();
  #ifdef DEBUG
   printf("Lee pag de EEP: %d \r\n",BufUart.Rx.RdPage.Page);
  #endif
  Status.WithData=1;
}

/* Función que escribe una página en la flash de uno de los uC CPU/IO (64 bytes)
  Son paginas de configuración o texto
  Pagina < 128:  ->  Escribe uC CPU
  Pagina >= 128: ->  Escribe uC IO
****************************************************/
void uniMakeWrPage(void)
{
	//TODO ver como implementar
   uint8_t *PtrTemp;
   uint32_t  i;
   uint16_t suma;

   if(BufUart.Rx.WrPage.Page<128) PtrTemp = &Variable[0].Byte.Lo; // Escribe uC CPU
   else PtrTemp = &Buffer.Variable[0].Byte.Lo; //&uWireBuf.Data[0];   // Escribe buffer uWire - uC IO
   // Traspasa los datos al buffer que corresponde
   for (PtrUART = &DataCom.BufData[0]; PtrUART < &DataCom.CheckSum; PtrUART++)
   {   // Copia los 64 bytes de BufData a PtrTemp
	   *PtrTemp = *PtrUART;
	   PtrTemp++;
   }
   // Verifico y/o corrijo checksumen posicion 31 de pag 0, ver otras pag !!!
   if(BufUart.Rx.WrPage.Page == 0)
   {
	 suma = 0;
	 for(i=0; i<31; i++)   suma += Variable[i].Value;
	 Variable[31].Value = suma;
   }
  #ifdef DEBUG
   printf("escribe EEPROM pag:%d \r\n",BufUart.Rx.WrPage.Page);
  #endif
 //  if(BufUart.Rx.WrPage.Page==143){//para debug TODO BORRAR
//	   Status.WithData=0;
//	   return;
//   }
   // Escribe en donde corresponde
   if (BufUart.Rx.WrPage.Page<128) lowWrPageC(BufUart.Rx.WrPage.Page); // Comando de escritura de EEPROM uC CPU
   else lowWrPage(BufUart.Rx.WrPage.Page -128);
	   //intraWrPageUWIRE(BufUart.Rx.WrPage.Page & 0x7f); // Comando de escritura EEPROM uC IO -> page=page-128 //
   Status.WithData=0;
}


/* Función que arma la respuesta a la lectura del transmision pending state
 **************************************************************************
 * Coloca en el frame comando, la cantidad de páginas de 64 bytes que forman la cola
 *  de transmision de transmision y eventos.
 *******************************************/
 void uniMakeRdPndStt(void)
 {

    memRdCfgFlash(17);  // Lee config -> pageFin
    BufUart.Tx.RdPndStt.TotTxPage = uniCalcEnvios(PtrTxTxed.page, PtrTxTxed.offset, cfgReg.pageFin, cfgReg.offsetFin, 17);

    memRdCfgFlash(18);  // Lee config -> pageFin
    BufUart.Tx.RdPndStt.TotEvPage = uniCalcEnvios(PtrEvTxed.page, PtrEvTxed.offset, cfgReg.pageFin, cfgReg.offsetFin, 18);

    uniCalcCheck();
    Status.WithData=0;
 }

 /* Función que escribe un pack de datos (en la flash de datos) entrados de la UART
  ******************************************************************/
  void uniMakeWrPack(void)
  {
    uint8_t *PtrBuf;
    uint8_t Cnt;
    PtrBuf = &DataCom.BufData[0];
    for(Cnt=BufUart.Rx.WrPack.Packs; Cnt>0; Cnt--)
    {
      execExePack(PtrBuf);
      if ((*PtrBuf & 0x10)||(*PtrBuf & 0x80))PtrBuf=PtrBuf+8;
      else PtrBuf=PtrBuf+4;
    }
    Status.WithData=0;
 }

  /* Función que lee páginas de datos pendientes por TX de la cola de TX
   *********************************************************************
   * Cuando se contesta al pedido, se colocan los offsets dentro de la
   *  página. En todas las páginas se colocan los offset de inicio y fin.
   * Si ambos offsets apuntan a 00, es que la página solicitada, no contiene
   *  información válida, ya que se superó la dirección apuntada por el ptrend.
   "PtrTxTxed" apunta al primer registro de evento pendiente de transmision
   ****************************************************************************/
   void uniMakeRdTxPnd (void)
   {
      union
      { uint32_t Tmp;
        struct
        {   uint8_t offset;
            uint16_t page;
            uint8_t NoUsado;
        }__attribute__ ((packed)) dir;
      }Address;

      Status.MemExt = 0;  // Memoria Interna
      // Cantidad de Paginas Totales
      memRdCfgFlash(17);  // Lee config -> pageFin
      BufUart.Tx.RdEvPnd.Total = uniCalcEnvios(PtrTxTxed.page, PtrTxTxed.offset, cfgReg.pageFin, cfgReg.offsetFin, 17);

      // Offset inicial de la pagina
      if (BufUart.Rx.RdTxPnd.Page == 0) BufUart.Tx.RdTxPnd.OffIni = PtrTxTxed.offset & 0x003f;
      else                              BufUart.Tx.RdTxPnd.OffIni = 0;
      // Offset final de la pagina
      if (BufUart.Rx.RdTxPnd.Page < BufUart.Tx.RdTxPnd.Total)   // Pagina intermedia
          BufUart.Tx.RdTxPnd.OffEnd = 0x40;
      else  if (BufUart.Rx.RdTxPnd.Page == BufUart.Tx.RdTxPnd.Total)  // Pagina Final
                  BufUart.Tx.RdTxPnd.OffEnd = cfgReg.offsetFin & 0x003f;
            else  BufUart.Tx.RdTxPnd.OffEnd = 0;    // Tomo el Offset Final del ptrEnd

      // Lee de la flash y salva en el buffer de datos
      Address.Tmp = 0;
      Address.Tmp = (uint32_t)(PtrTxTxed.offset & 0xc0)+(uint32_t)(BufUart.Rx.RdTxPnd.Page<<6);
      Address.dir.page += PtrTxTxed.page;
      if(Address.dir.page >= Format[17].Long)  Address.dir.page = Address.dir.page - Format[17].Long + 1;

      // Carga buffer de Tx desde la Flash de datos y Agrega Checksum
      if(Address.dir.page<Format[17].Long && Address.dir.page)
      {   Address.dir.page += Format[17].Start; // page absoluta en memoria
          memRdFlash((uint8_t *)DataCom.BufData, Address.dir.page, Address.dir.offset, 64);
      }else     BufUart.Tx.RdEvPnd.OffEnd = 0;

      uniCalcCheck();
      DataCom.CheckSum = uniCalcDataCheck();
      Status.WithData=1;
   }

   /* Función que lee páginas de datos pendientes por TX de la cola de EV
    *********************************************************************
    *  Cuando se contesta al pedido, se colocan los offsets dentro de la
    *  página. En todas las páginas se colocan los offset de inicio y fin.
    *  Si ambos offsets apuntan a 00, es que la página solicitada, no contiene
    *  información válida, ya que se superó la dirección apuntada por el ptrend
    "PtrEvTxed" apunta al primer registro de evento pendiente de transmision
    ****************************************************************************/
    void uniMakeRdEvPnd (void)
    {
       union
       { uint32_t Tmp;
         struct
         {   uint8_t offset;
             uint16_t page;
             uint8_t NoUsado;
         }__attribute__ ((packed)) dir;
       }Address;

       Status.MemExt = 0;
       // Cantidad de pages totales
       memRdCfgFlash(18);  // Lee config -> pageFin
       BufUart.Tx.RdEvPnd.Total = uniCalcEnvios(PtrEvTxed.page, PtrEvTxed.offset, cfgReg.pageFin, cfgReg.offsetFin, 18);

       // Offset inicial de la pagina
       if (BufUart.Rx.RdEvPnd.Page==0) BufUart.Tx.RdEvPnd.OffIni = PtrEvTxed.offset & 0x003f;
       else                            BufUart.Tx.RdEvPnd.OffIni = 0;
       // Offset final de la pagina
       if (BufUart.Rx.RdEvPnd.Page < BufUart.Tx.RdEvPnd.Total)   // Pagina intermedia
           BufUart.Tx.RdEvPnd.OffEnd = 0x40;
       else  if (BufUart.Rx.RdEvPnd.Page == BufUart.Tx.RdEvPnd.Total)  // Pagina Final
                   BufUart.Tx.RdEvPnd.OffEnd = cfgReg.offsetFin & 0x003f;          // Tomo el Offset Final del ptrEnd
             else  BufUart.Tx.RdEvPnd.OffEnd = 0;

       // Lee de la flash y salva en el buffer de datos
       Address.Tmp = 0;
       Address.Tmp = (uint32_t)(PtrEvTxed.offset & 0xc0)+(uint32_t)(BufUart.Rx.RdEvPnd.Page<<6);
       Address.dir.page += PtrEvTxed.page;
       if(Address.dir.page >= Format[18].Long)  Address.dir.page = Address.dir.page - Format[18].Long + 1;

       // Carga buffer de Tx desde la Flash de datos y Agrega Checksum
       if(Address.dir.page<Format[18].Long && Address.dir.page)
       {   Address.dir.page += Format[18].Start; // page absoluta en memoria
           memRdFlash((uint8_t *)DataCom.BufData, Address.dir.page, Address.dir.offset, 64);
       }
       else     BufUart.Tx.RdEvPnd.OffEnd = 0;

       uniCalcCheck();
       DataCom.CheckSum = uniCalcDataCheck();
       Status.WithData=1;
    }

   /* Función que busca datos en una pila ordenados para un determinado día
    *********************************************************************
    * Se ingresa con la página y la fecha. PRimero se busca la fecha en el chipflash
    *  luego se arman las direcciones por páginas y se TX.
    * El tope hacia atrás, es la cantidad de datos que debe almacenar. PAra los eventos
    *  que tienen 2 tracks, son 64K, y los que tienen 3 tracks, son 128K.

    "BufUart.Rx.RdChDay.CanalFisico" tiene el dato del canal fisico que se solicita
    TipoPila: define si es la pila de eventos, de tx, de 1 canal
    ***********************************************************************************/
    #define Eventos (0)
    #define Canal   (1)
    #define Transm  (2)

    void uniMakeRdDay(uint8_t TipoPila)
    {
    	uint8_t Find;
    	uint8_t pila;
    	uint8_t offset00;
    	uint8_t offset24;
    	uint16_t page00;
    	uint16_t page24;
    	uint16_t pageTmp;

      struct{
    	  uint16_t FlgDay;  // 0x4000
    	  uint16_t Day;     // dia
    	  uint16_t FlgPast; // 0x2000 | pagePast
    	  uint16_t Past;    // offsetPast
      } __attribute__ ((packed)) Info;

      union{
        uint32_t Tmp;
        struct{
        	uint8_t offset;
        	uint16_t page;
           uint8_t NoUsado;
        }__attribute__ ((packed))  Byte;
      } Address;

       // Verifico presencia de cartucho
       /* no hay cartucho en este equipo! TODO ver!
       if(Status.MemExt && __PORTLP_bit.MemAusente)
       {
           BufUart.Tx.RdChDay.Channel |= 0x80;
           BufUart.Tx.RdTxDay.Page = 0;
           BufUart.Tx.RdTxDay.Total = 0;
           BufUart.Tx.RdTxDay.OffIni = 0;
           BufUart.Tx.RdTxDay.OffEnd = 0;
           DataCom.BufData[0] = Error;
           uniCalcCheck(); // CheckSum del header
           DataCom.CheckSum = uniCalcDataCheck();  // checksum del pack de datos
           Status.WithData=1;
           return;
       }
       */

      // Obtengo Nro de Pila
          if (TipoPila == Canal)
          {   if(BufUart.Rx.RdChDay.CanalFisico<14) pila = BufUart.Rx.RdChDay.CanalFisico;
              else if(BufUart.Rx.RdChDay.CanalFisico==14) pila = 16;
              else if((BufUart.Rx.RdChDay.CanalFisico==0x15) || (BufUart.Rx.RdChDay.CanalFisico==0x16))
                       pila = BufUart.Rx.RdChDay.CanalFisico-7; // pilas 14 y 15
          }
          else 	if(TipoPila == Eventos) pila=18;  // Eventos
      		else			pila=17;  // Transmision
          // Cargo config de la pila
          memRdCfgFlash(pila);
          // Inicializa los punteros a las 00:00 y ultimo registro del dia de hoy
          offset00 = cfgReg.offsetPast;
          page00 = cfgReg.pagePast;
          page24 = cfgReg.pageFin;
          offset24 = cfgReg.offsetFin;

          do{
      	// Cargo en Info el registro "Time"
      	if(offset00 <= 248)
      	{
      		memRdFlash((uint8_t *)&Info, Format[pila].Start + page00, offset00, 8);
      	}
      	else  // Leo en 2 bloques de 4 bytes c/u
      	{       memRdFlash((uint8_t *)&Info, Format[pila].Start + page00, offset00, 4);
                      pageTmp = page00+1;
        		if(pageTmp >= Format[pila].Long) pageTmp = 1;
      //		memRdFlash(((unsigned char *)&Info)+4, Format[pila].Start + pageTmp, 0, 4);
      	        memRdFlash((uint8_t *)&Info.FlgPast, Format[pila].Start + pageTmp, 0, 4);
      	}
              // Si la fecha es la buscada, ok
              Find=Ok;
              if ((Info.FlgDay!=0x4000) || ((Info.FlgPast&0x2000)!=0x2000) || (Info.Day<BufUart.Rx.RdTxDay.Date)) Find=Error;
              else
              {   if((offset00==(uint8_t)Info.Past) && (page00==(Info.FlgPast&0x1fff))) Find=Inicial; // El reg apunta a si mismo
                  if (Info.Day==BufUart.Rx.RdTxDay.Date) {  Find=Ok;   }
                  else  // Set la noche a la mañana del día anterior
                  {   if (Find==Inicial) {   Find=Error;  }
                      else  // Me muevo un dia hacia atras
                      {   offset24 = offset00;
                          page24 = page00;
                          // Set la mañana en lo que dice el pack almacenado en la flash de datos
                          offset00 = (uint8_t)Info.Past;
                          page00 = Info.FlgPast & 0x1fff;
                          Find=Not;
                      };
                  };
              };
          } while (Find==Not);  // Puede salir con OK o Error

          if(Find==Ok)    // Envio de paginas de 64 bytes ...
          {   BufUart.Tx.RdTxDay.Total = uniCalcEnvios(page00,offset00,page24,offset24,pila);
      	// Offset Inicial
              if (BufUart.Rx.RdTxDay.Page==0) BufUart.Tx.RdTxDay.OffIni = offset00 & 0x003f;
      	else	                        BufUart.Tx.RdTxDay.OffIni = 0;
      	// Offset Final
              if (BufUart.Rx.RdTxDay.Page < BufUart.Tx.RdTxDay.Total)
              {    BufUart.Tx.RdTxDay.OffEnd = 0x40;  }
              else
              { 	if(BufUart.Rx.RdTxDay.Page == BufUart.Tx.RdTxDay.Total)
                  		BufUart.Tx.RdTxDay.OffEnd = offset24 & 0x003f;
              	else    BufUart.Tx.RdTxDay.OffEnd = 0;
              }
              // Lee de la flash y salva en el buffer de datos
              Address.Tmp = 0;
              Address.Tmp = (uint32_t)(offset00&0xc0)+(uint32_t)(BufUart.Rx.RdTxDay.Page<<6);
              Address.Byte.page += page00;
      	if(Address.Byte.page >= Format[pila].Long) Address.Byte.page = Address.Byte.page-Format[pila].Long+1;

      	if(Address.Byte.page < Format[pila].Long)
      	{     Address.Byte.page += Format[pila].Start;
      	      memRdFlash((uint8_t *)DataCom.BufData, Address.Byte.page ,Address.Byte.offset, 64);
      	}
      	else  BufUart.Tx.RdTxDay.OffEnd = 0;
          }
          else
          {
              // Al pedir pila Tx por dia y no haber dato tira un error pero parece ser un quilombo del soft
              // Al pedir eventos por dia, cuando se pide el dia de ayer se traen los de hoy tambien
              BufUart.Tx.RdChDay.Channel |= 0x80;
              BufUart.Tx.RdTxDay.Page = 0;
              BufUart.Tx.RdTxDay.Total = 0;
              BufUart.Tx.RdTxDay.OffIni = 0;
              BufUart.Tx.RdTxDay.OffEnd = 0;
              DataCom.BufData[0] = Error;
          };

          uniCalcCheck(); // CheckSum del header
          DataCom.CheckSum = uniCalcDataCheck();  // checksum del pack de datos
          Status.WithData=1;
 }

/* Función que arma el frame y exe MakRstAgend
 *****************************************************/
 void uniMakeRstAgend(void)
 {
	 //TODO implementar, listo! _read reemplazado por lowRdPage
	uint16_t window;
	//__disable_interrupt();
	// Lee ventada de comunicaciones desde Pag0 de Flash
	//__read_flash_block ((unsigned short)&window, ConfigIni+6, 2); // Pag 0, Variable[3].value
	//__enable_interrupt();
	lowRdPageC(0); //lee pagina 0, Variable[3].value
	window=(uint16_t) Variable[3].Value;

	NextAgend.Order=0;
	do{  execRdNextComm();
	}while((((NextAgend.Time&0x0fff)+window-2) < Rtc.Time) && (NextAgend.Order<300) );
	// Si Time actual es mayor al maximo de la agenda, carga el primero del dia siguiente
	if (NextAgend.Time == 0xffff)
	{  NextAgend.Order=0;
	   execRdNextComm();
	}
 }


/* Lee desde la flash de datos: 64 bytes en respuesta a un pedido del COM
Cada pagina de flash tiene 256 bytes / c/page se lee en 4 packs de 64 datos c/u
   BufUart.Rx.RdFlash.Track: Nro de Pila: 0..18
   BufUart.Rx.RdFlash.Page: Nro de Pagina: packs de 64 bytes dentro de la pila
*****************************************************/
void uniMakeRdFlash(void)
{
	 uint16_t tmpPage;
	 uint8_t off;

	 tmpPage = Format[BufUart.Rx.RdFlash.Track].Start;    // Pag Inicial de la pila
	 tmpPage += BufUart.Rx.RdFlash.Page>>2; // Cada 4 pages de envio es una Pag de la Flash
	 off = (BufUart.Rx.RdFlash.Page & 0x03)<<6; // El offset puede ser: 0, 64, 128, 192
	 memRdFlash((uint8_t*)DataCom.BufData, tmpPage, off, 64);
	 uniCalcCheck();
	 DataCom.CheckSum = uniCalcDataCheck();
	 Status.WithData=1;
	#ifdef DEBUG 
	 printf("Lee Flash pag: %d  \r\n",tmpPage);
	#endif
}

/* Escribe en la IO los valores de las Salidas Digitales 2 y 3 */
/* Fuerza un valor en alguna de las salidas digitales
   sd: 0..2  SD1..SD3
   value: 0 apaga;  != 0 conmuta
*****************************************************/
void uniMakeWrSD(void)
{
	 //if((BufUart.Rx.WrSD.sd == 1) || (BufUart.Rx.WrSD.sd == 2))
	 //  intraWrSD(BufUart.Rx.WrSD.sd, (BufUart.Rx.WrSD.value!=0));
	//TODO ver como hacer con mas salidas
	//if(uWireBuf.State.Outs.Out) lowRdPage(0x17);   // Salidas 2 o 3
	 // sd (2 bits): 0,1,2  es el nro de SD
	if(BufUart.Rx.WrSD.sd) lowRdPage(0x17);   // Salidas 2 o 3

	// value (1 bit) : 0, 1 estado a poner en la SD
	if(BufUart.Rx.WrSD.value){ //escribe un  '1'
		 switch (BufUart.Rx.WrSD.sd){
		        case    0:  //__PORTED_bit.Ctl_01=1;
		        			OUT_1_ON;
		                    break;

		        case    1:  //__PORTED_bit.Ctl_02=1;
		        			OUT_2_ON;
		        			Buffer.Variable[0].Byte.Lo |= 0x02;  // Variable pra Backup
		                    break;

		        case    2:  //__PORTED_bit.Ctl_03=1;
		        			OUT_3_ON;
		        			Buffer.Variable[0].Byte.Lo |= 0x04;
		                    break;
		        };
	}
	else{ //escribe un '0'
		 switch (BufUart.Rx.WrSD.sd){
				case    0:  //__PORTED_bit.Ctl_01=0;
							OUT_1_OFF;
							break;

				case    1:  //__PORTED_bit.Ctl_02=0;
							OUT_2_OFF;
							Buffer.Variable[0].Byte.Lo &= ~0x02;
							break;

				case    2:  //__PORTED_bit.Ctl_03=0;
							OUT_3_OFF;
							Buffer.Variable[0].Byte.Lo &= ~0x04;
							break;
				};

	}
	Buffer.Variable[0].Byte.Hi = ~Buffer.Variable[0].Byte.Lo;
	if(BufUart.Rx.WrSD.sd) lowWrPage(0x17);   // Salidas 2 o 3

	 Status.WithData=0;
}





/* Función que interpreta lo que entró por la UART
*************************************************
* Se ingresa a esta función, cuando hay en el buffer de RX, un frame OK.
* Se lee la información, se interpreta, y se llama a las distintas funciones
*  que arman el frame para responder.
* Por último, se llama a la función que transmite el frame recientemente generado.
* Terminadas todas las tareas, se reenciende la interrupción de RX de la UART.
**********************************************************************************/
void uniRxExe(void)
{
 //WWDT_Disable(WWDT);
 //WWDT_Refresh(WWDT);
 WWDT_Deinit(WWDT);
 configWWDT.enableWatchdogReset=false;
 WWDT_Init(WWDT,&configWWDT);
 WWDT_Refresh(WWDT);

 
 PtrUART=&BufUart.Commands;
 switch (*PtrUART){

 case _RdCoreStt: uniMakeRdCoreStt(); // 0x20: Lectura de Core State
				 break;               // Fecha, Hora y Estado de la UTR

 case _RdPndStt: 
				#ifdef DEBUG 
					printf("cola de transmision \r\n");
				#endif
	 	 	 	 uniMakeRdPndStt();   // 0X21
				 break;

 case _RdInst:  
				#ifdef DEBUG
				 printf("datos inst \r\n");
				#endif
	 	 	 	 uniMakeRdInst();     // 0x22: Lectura de Datos Instantaneos
				 break;

 case _RdChDay: 
				#ifdef DEBUG
				 printf("datos canal \r\n");
				#endif
	 	 	 	 Status.MemExt = 0;    // 0x23: Lectura de Datos de un canal, por fecha, memoria interna
				 uniMakeRdDay(Canal);
				 break;

 case _RdChDayCar: 
				#ifdef DEBUG
				 printf("datos canal Dia\r\n");
				#endif
	 	 	 	 Status.MemExt = 1;  // 0xA3: Lectura de Datos de un canal, por fecha, cartucho
				 uniMakeRdDay(Canal);
				 Status.MemExt = 0;
				 break;

 case _RdEvDay:  Status.MemExt = 0;    // 0x24: Lectura de Eventos por fecha, memoria interna
 				#ifdef DEBUG
 	 	 	 	 printf("eventos por fecha \r\n");
				#endif
 	 	 	 	 uniMakeRdDay(Eventos);
				 break;

 case _RdEvDayCar: 
 				#ifdef DEBUG
				 printf("ev. cartucho \r\n");
				#endif
	 	 	 	 Status.MemExt = 1;  // 0xA4: Lectura de Eventos por fecha, cartucho
				 uniMakeRdDay(Eventos);
				 Status.MemExt = 0;
				 break;

 case _RdEvPnd: 
				#ifdef DEBUG
				 printf("eventos pendientes \r\n");
				#endif
	 	 	 	 uniMakeRdEvPnd();  // 0x25: Lectura de eventos pendientes de Tx
				 break;

 case _RdTxDay: 
 				#ifdef DEBUG
				 printf("pila tx MemInt \r\n");
				#endif
	 	 	 	 Status.MemExt = 0;    // 0x26: Lectura de Datos Pila Tx por fecha, memoria Interna
				 uniMakeRdDay(Transm);
				 break;

 case _RdTxDayCar: 
				#ifdef DEBUG 
				 printf("pila tx MemExt \r\n");
				#endif 
	 	 	 	 Status.MemExt = 1;  // 0xA6: Lectura de Datos Pila Tx por fecha, cartucho
				 uniMakeRdDay(Transm);
				 Status.MemExt = 0;
				 break;

 case _RdTxPnd:
				#ifdef DEBUG
				 printf("Datos tx pend \r\n");
				#endif
	 	 	 	 uniMakeRdTxPnd();  // 0x27: Lectura de Datos pendientes en la cola de Tx
				 break;

 case _RdPage:  
				#ifdef DEBUG
				 printf("lee pagina de EEP \r\n");
				#endif
	 	 	 	 uniMakeRdPage();   // 0x28: Lectura de Pagina de Flash de los uC CPU/IO (64 bytes)
				 break;

 case _WrPage:   
				#ifdef DEBUG
				 printf("escribe pagina EEP \r\n");
				#endif
	 	 	 	 uniMakeWrPage();   // 0x47: Escritura de Pagina de Flash de los uC CPU/IO (64 bytes)
				 break;

 case _WrCoreStt:printf("escribe core state \r\n");
				   /* Copy first struct values into the second one, para no perder el estado del micro*/
				 memcpy(&cfgReg, &tmpCfg, sizeof cfgReg);
	 	 	 	 uniMakeWrCoreStt();  // 0x48: Escritura del Core State, Estado de la UTR
				   /* Copy first struct values into the second one */
				 memcpy(&tmpCfg, &cfgReg, sizeof tmpCfg);
				 break;

 case _WrPack:   
				#ifdef DEBUG
				 printf("escribe datos en flash \r\n");
				#endif
	 	 	 	 uniMakeWrPack(); // 0x49 Escribe datos en la Flash
				 break;

 case _Reset:    Status.MemExt = 0;  // 0x69: Borrado de la memoria Flash Interna, todas las pilas quedan vacias
				#ifdef DEBUG
				 printf("RESET memoria \r\n");
				#endif
				 uniMakeReset();
				 break;

 case _ResetCar: //   if(__PORTAP_bit.MemAusente) break; // 0xE9: Borrado de la memoria Flash Externa
				 //Status.MemExt = 1;
				 //uniMakeReset();
				 Status.MemExt = 0;
				 break;

 case _Restart:	 
				#ifdef DEBUG
				 printf("reinicio \r\n");
				#endif
 	 	 	 	 PowerOnSS=0;
 	 	 	 	 PowerOnaa=0;//para que ponga en 0 los cangilones
 	 	 	 	 PowerOn55=0x56;
	 	 	 	 uniMakeRestart();   // 0x4B: Reinicio de la UTR ... agenda, punteros y todo lo demas
				 break;

 case _RstAgend:
				#ifdef DEBUG
				 printf("reset agenda \r\n");
				#endif
	 	 	 	 uniMakeRstAgend();  // 0x4C: comando de reinicio de agenda, a ejecutar cada vez que se cambie la agenda
				 execMakeReini(BufUart.Rx.RstAgend.Motivo);
				 execExePack(&PackTemp.Ev.Config);
				 break;

 case _RdFlash:  Status.MemExt = 0;  // 0x29: Lectura de la Flash de datos (64 bytes) track:0..31, pagina:0..1023
				 uniMakeRdFlash();
				 break;

 case _RdFlashCar: // if(__PORTAP_bit.MemAusente) break;  // 0xA9: Lectura del Cartucho (datos crudos)
				   //Status.MemExt = 1;
				   //uniMakeRdFlash();
				 Status.MemExt = 0;
				 break;

 case _WrSD:     
				#ifdef DEBUG
				 printf("escribe salidas Dig \r\n");
				#endif
	 	 	 	 uniMakeWrSD();      // 0x30: Escribe las Salidas Digitales 2 y 3
				 break;
 }
 uniTxFrame();  // transmite el buffer apuntado por PtrUART:    __TBUF=*PtrUART;
// if(BufUart.Commands==_Restart){
//	 PowerOn55=0x56;
	 /*SoftWD=60;*/
	 //lowUCReset();  //TODO estaba bien

     /*while(1){};*/
 //};

 WWDT_ClearStatusFlags(WWDT,kWWDT_TimeoutFlag);
 //WWDT_Enable(WWDT);
#ifndef DEBUG
 configWWDT.enableWatchdogReset = true;
#else
 configWWDT.enableWatchdogReset = false;
#endif
 WWDT_Init(WWDT,&configWWDT);
 WWDT_Refresh(WWDT);
}



/* Calcula cuantos packs de 64 bytes se necesitan para mandar todo lo que hay entre PageIni,offIni y pageEnd,offEnd
   Particiona cada pagina de Flash (256b) en 4 pages de 64bytes (son los datos q van en cada comando)
   Manda Offset Ini y Offset Fin para cada page enviada
   Retorna: Cantidad de Pages-1		*/
uint16_t uniCalcEnvios(uint16_t pageIni, uint8_t offIni, uint16_t pageEnd, uint8_t offEnd, uint8_t pila)
{   uint16_t temp;
    if((pageIni>=Format[pila].Long) || (pageEnd>=Format[pila].Long)) return 0;
    temp = pageEnd;
    if(pageIni > pageEnd) temp = temp + Format[pila].Long - 1;
    temp -= pageIni;
    temp <<= 2;   // 4 envios por pagina
    // Proceso offsets dentro de las paginas
    temp += offEnd>>6;
    temp -= offIni>>6;
    return temp;
}

/*  Comando RdAny
    En el loop main, se llama si hay info de IO
    luego la CPU lo procesa.
    era: intraRdAnyUwire
 ************************************************************************************/
void intraRdAny(void){

	if(StatusIO.Full1){ //  EVENTOS: AlMax, AlMin, Al_SupervAn, Al_SupervDig,
						//  CanalInvalido, Pta_0_Pluvi, MalAD
		execExePack((uint8_t *)&Resultados1);
		StatusIO.Full1=0;
		StatusIO.Vacio=1;
	}
	if(StatusIO.Full2){  // EVENTOS: AlAsc, AlDesc
		execExePack((uint8_t *)&Resultados2);
		StatusIO.Full2=0;
		StatusIO.Vacio=1;
	}
	if(StatusIO.Full3){ // EVENTOS: AlPkMax, AlPkMin, TxCond, MalAD al iniciar
		execExePack((uint8_t *)&Resultados3);
		StatusIO.Full3=0;
		StatusIO.Vacio=1;
	}
	if(StatusIO.Full4){ // StorageLimni, StorageMeteo, StorageVelVto, StorageVeleta,
		                // StoragePluvi, Ev_ReiniIO
		execExePack((uint8_t *)&Resultados4);
	    StatusIO.Full4=0;
	    StatusIO.Vacio=1;
	}
}


