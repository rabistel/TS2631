/*
 * Calculos1.c
 * Calculos de los canales
 *************************
 * Aquí se ubican todos los calculos de cada canal y cada tipo de entrada
 *  Created on: 10 ago. 2018
 *      Author: Marcelo.Caamaño
 */
#include "CPU_def.h"
//#include "Variables1.h"

//extern  char Page;

 //extern   LastDireccion;   // Ultimo promedio vectorial del unico canal vectorial posible.
 //extern   MaxDireccion;    // Direccion registrada en el TRead de maxima vel. Lo set el velocidad del viento
 //extern   MinDireccion;    // Idem para la minima velocidad.
 //extern   StDireccion;

/* Aquí estan las funciones para armar los paquetes de datos del limnimetro
 **************************************************************************/

 // Arma el paquete de datos correspondiente al TStorage
 void calcMakeStorageLimni(void)
 {
    Resultados4.Var.Config = DatoValido;
    if(Buffer.ChStruct.Temporario.Flags.NoVal)Resultados4.Bit.Inval = 1;
    Resultados4.Var.Value = ValorAct; // Valor Medio en Tread
    Resultados4.Var.CanalFisico = Page;
    StatusIO.Full4 = 1;
    StatusIO.Vacio = 0;
 }

 // Arma al paquete del Discret
 void calcMakeDiscretLimni(void)
 {
    if (!StatusIO.Full4) calcMakeStorageLimni(); // Si no se hizo el storage, se hace
    Resultados4.Bit.TxToo=1;  // Además se marca que también se quiere transmitir
 }

/* Aquí estan las funciones para armar los paquetes de datos del meteorologico
 *****************************************************************************/

 // Arma el paquete de datos correspondiente al TStorage
 void calcMakeStorageMete(void)
 {
    Resultados4.Var.Config = DatoLargo;
    if(Buffer.ChStruct.Temporario.Flags.NoVal) Resultados4.Bit.Inval = 1;
    Resultados4.Var.Value = Buffer.ChStruct.Temporario.TMeteorologico.MedMed;
    Resultados4.Var.Max = Buffer.ChStruct.Temporario.TMeteorologico.MedMax;
    Resultados4.Var.Min = Buffer.ChStruct.Temporario.TMeteorologico.MedMin;
    Resultados4.Var.CanalFisico = Page;
    StatusIO.Full4 = 1;
    StatusIO.Vacio = 0;
 }

 // Arma al paquete del Discret
 void calcMakeDiscretMete(void)
 {
    if(!StatusIO.Full4) calcMakeStorageMete();
    Resultados4.Bit.TxToo=1;
 }
 
 
 /* Aquí estan las funciones para armar los paquetes de datos del SDI12
 *****************************************************************************/

 // Arma el paquete de datos correspondiente al TStorage==TRead en SDI12
 void calcMakeStorageSDI12(void)
 {
    Resultados4.Var.Config = DatoValido;
    if(Buffer.ChStruct.Temporario.Flags.NoVal)Resultados4.Bit.Inval = 1;
    Resultados4.Var.Value = Buffer.ChStruct.Temporario.TSDI12.MedMed; // Valor Medio en Tread
    Resultados4.Var.CanalFisico = Page;
    if(Buffer.ChStruct.Temporario.TSDI12.quintobith){
    	Resultados4.Var.Config = DatoLargo;
    	Resultados4.Var.Max=Buffer.ChStruct.Temporario.TSDI12.quintobitv;
		Resultados4.Var.Min=0;
    }
    StatusIO.Full4 = 1;
    StatusIO.Vacio = 0;
 }

 // Arma al paquete del Discret
 void calcMakeDiscretSDI12(void)
 {
    if(!StatusIO.Full4) calcMakeStorageSDI12();
    Resultados4.Bit.TxToo=1;
 }

/* Aquí estan las funciones para armar los paquetes de datos del velocidad
 *****************************************************************************/

 // Arma el paquete de datos correspondiente al TStorage
 void calcMakeStorageVelo(void)
 {
    Resultados4.Var.Config=DatoLargo;
    if (Buffer.ChStruct.Temporario.Flags.NoVal)Resultados4.Bit.Inval=1;
    Resultados4.Var.Value = Buffer.ChStruct.Temporario.TVelocidad.MedMed;
    Resultados4.Var.Max = Buffer.ChStruct.Temporario.TVelocidad.MedMax;
    Resultados4.Var.Min = Buffer.ChStruct.Temporario.TVelocidad.MedMin;
    Resultados4.Var.CanalFisico = Page;
    StatusIO.Full4=1;
    StatusIO.Vacio=0;
 }

 // Arma al paquete del Discret
 void calcMakeDiscretVelo(void)
 {
    if(!StatusIO.Full4) calcMakeStorageVelo();
    Resultados4.Bit.TxToo=1;
 }

/* Aquí estan las funciones para armar los paquetes de datos del direccion
 *****************************************************************************/

 // Arma el paquete de datos correspondiente al TStorage
 void calcMakeStorageVele(void)
 {
    Resultados4.Var.Config = DatoLargo;
    Resultados4.Var.Value = StDireccion;
    Resultados4.Var.Max = MaxDireccion;
    Resultados4.Var.Min = MinDireccion;
    Resultados4.Var.CanalFisico = Page;
    StatusIO.Full4 = 1;
    StatusIO.Vacio=0;
 }

 // Arma al paquete del Discret
 void calcMakeDiscretVele(void)
 {
    if (!StatusIO.Full4) calcMakeStorageVele();
    Resultados4.Bit.TxToo=1;
 }

 /* Aquí estan las funciones para armar los paquetes de datos del pluviometro
 ****************************************************************************/
 // Arma el paquete de datos correspondiente al TStorage
 void calcMakeStoragePluvi(void)
 {
    Resultados4.Var.Config = DatoValido;
    if(Buffer.ChStruct.Temporario.Flags.NoVal) Resultados4.Bit.Inval=1;
    Resultados4.Var.Value = ValorAct;
    Resultados4.Var.CanalFisico = Page;
    StatusIO.Full4=1;
    StatusIO.Vacio=0;
 }

 // Arma al paquete del Discret
 void calcMakeDiscretPluvi(void)
 {
    if (!StatusIO.Full4) calcMakeStoragePluvi();
    Resultados4.Bit.TxToo=1;
 }


/* Geeneración de Evento por Alarma del limnimetro
 *****************************************/
 void calcProcAlLimni(uint8_t Motivo, uint16_t Valor)
 {  if(Buffer.ChStruct.Temporario.TLimnimetrico.CntTResetAlarma == 0)
    {
        switch(Motivo)
        { case AlMaxLimni:
          case AlMinLimni:    Lugar=&Resultados1; StatusIO.Full1=1; break;
          case AlAscLimni:
          case AlDesLimni:    Lugar=&Resultados2; StatusIO.Full2=1; break;
        }//Se marcan distintos indicadores

        if(Page != 0)  // Correccion para canales != 0 ya que no se toman como limni
        { if(Motivo==AlMaxLimni) Motivo=AlMax;
          if(Motivo==AlMinLimni) Motivo=AlMin;
        } // Los eventos Asc y Des se generan solamente para page==0 !
        // Se arma el paquete del evento
        Lugar->Ev.Config=Evento;
        Lugar->Ev.Channel=Event;
        Lugar->Ev.Bite.CodeHi=0;
        Lugar->Ev.Bite.CodeLo=Motivo;
        Lugar->Ev.Value1=Page;
        Lugar->Ev.Value2=Valor;
        StatusIO.Vacio=0;//Se borra el indicador de vacío
    }
    Buffer.ChStruct.Temporario.TLimnimetrico.CntTResetAlarma = Buffer.ChStruct.TResetAlarma;
 }

 /* Geeneración de Evento por Alarma del limnimetro
  *****************************************/
  void calcProcAlSDI12(uint8_t Motivo, uint16_t Valor)
  {  if(Buffer.ChStruct.Temporario.TSDI12.CntTResetAlarma == 0)
     {
         switch(Motivo)
         { case AlMaxLimni:
           case AlMax:
           case AlMin:    Lugar=&Resultados1; StatusIO.Full1=1; break;
           case AlMinLimni:
           case AlAsc:
           case AlDes:    Lugar=&Resultados2; StatusIO.Full2=1; break;
         }//Se marcan distintos indicadores

         // Se arma el paquete del evento
         Lugar->Ev.Config=Evento;
         Lugar->Ev.Channel=Event;
         Lugar->Ev.Bite.CodeHi=0;
         Lugar->Ev.Bite.CodeLo=Motivo;
         Lugar->Ev.Value1=Page;
         Lugar->Ev.Value2=Valor;
         StatusIO.Vacio=0;//Se borra el indicador de vacío
     }
     Buffer.ChStruct.Temporario.TSDI12.CntTResetAlarma = Buffer.ChStruct.TResetAlarma;
  }

/* Procesador de las alarmas del meteorologico
 *********************************************/
 void calcProAlMete(uint8_t Motivo, uint16_t Valor)
 {  if(Buffer.ChStruct.Temporario.TMeteorologico.CntTResetAlarma == 0)
    {
        switch(Motivo)
        { case AlMax:
          case AlMin:         Lugar=&Resultados1;
                              StatusIO.Full1=1;
                              break;
          case AlAsc:
          case AlDes:         Lugar=&Resultados2;
                              StatusIO.Full2=1;
                              break;
          case AlPkMax:
          case AlPkMin:       Lugar=&Resultados3;
                              StatusIO.Full3=1;
                              break;
        }
        Lugar->Ev.Config=Evento;
        Lugar->Ev.Channel=Event;
        Lugar->Ev.Bite.CodeHi=0;
        Lugar->Ev.Bite.CodeLo=Motivo;
        Lugar->Ev.Value1=Page;
        Lugar->Ev.Value2=Valor;
        StatusIO.Vacio=0;
    }
    Buffer.ChStruct.Temporario.TMeteorologico.CntTResetAlarma = Buffer.ChStruct.TResetAlarma;
 }

 /* Procesador de las alarmas del SDI12
 *********************************************/
 void calcProAlSDI12(uint8_t Motivo, uint16_t Valor)
 {  if(Buffer.ChStruct.Temporario.TMeteorologico.CntTResetAlarma == 0)
    {
        switch(Motivo)
        { case AlMax:
          case AlMin:         Lugar=&Resultados1;
                              StatusIO.Full1=1;
                              break;
          case AlAsc:
          case AlDes:         Lugar=&Resultados2;
                              StatusIO.Full2=1;
                              break;
          case AlPkMax:
          case AlPkMin:       Lugar=&Resultados3;
                              StatusIO.Full3=1;
                              break;
        }
        Lugar->Ev.Config=Evento;
        Lugar->Ev.Channel=Event;
        Lugar->Ev.Bite.CodeHi=0;
        Lugar->Ev.Bite.CodeLo=Motivo;
        Lugar->Ev.Value1=Page;
        Lugar->Ev.Value2=Valor;
        StatusIO.Vacio=0;
    }
    Buffer.ChStruct.Temporario.TSDI12.CntTResetAlarma = Buffer.ChStruct.TResetAlarma;
 }
 
/* Procesador de las alarmas del velocidad
 *********************************************/
 void calcProAlVelo(uint8_t Motivo, uint16_t Valor)
 {  if (Buffer.ChStruct.Temporario.TVelocidad.CntTResetAlarma==0)
    {
        switch(Motivo)
        { case AlMax:
          case AlMin:      Lugar=&Resultados1;
                           StatusIO.Full1=1;
                           break;
          case AlAsc:
          case AlDes:      Lugar=&Resultados2;
                           StatusIO.Full2=1;
                           break;
          case AlPkMax:
          case AlPkMin:    Lugar=&Resultados3;
                           StatusIO.Full3=1;
                           break;
        }
        Lugar->Ev.Config=Evento;
        Lugar->Ev.Channel=Event;
        Lugar->Ev.Bite.CodeHi=0;
        Lugar->Ev.Bite.CodeLo=Motivo;
        Lugar->Ev.Value1=Page;
        Lugar->Ev.Value2=Valor;
        StatusIO.Vacio=0;
    }
    Buffer.ChStruct.Temporario.TVelocidad.CntTResetAlarma = Buffer.ChStruct.TResetAlarma;
 }


/* PRoceso de las alarmas del supervision
 *****************************************/
 void calcProcAlSuperv(uint8_t Motivo, uint16_t Valor)
 {  if (Buffer.ChStruct.Temporario.TSuperv.CntTResetAlarma==0)
    {
        Resultados1.Ev.Config=Evento;
        Resultados1.Ev.Bite.CodeHi=0;
        Resultados1.Ev.Bite.CodeLo=Motivo;
        Resultados1.Ev.Value1=Page;
        Resultados1.Ev.Value2=Valor;
        StatusIO.Vacio=0;
        StatusIO.Full1=1;
    }
    Buffer.ChStruct.Temporario.TSuperv.CntTResetAlarma = Buffer.ChStruct.TResetAlarma;
 }

/* Evento de Variacion Asc/Des respecto del ultimo dato transmitido en Limnimetro
 ***********************************************************************/
 void calcProcTxLimni(uint8_t Motivo, uint16_t Valor)
 {
      Resultados3.Ev.Config = Evento;
      Resultados3.Ev.Channel = Event;
      Resultados3.Ev.Bite.CodeHi = 0;
      Resultados3.Ev.Bite.CodeLo = Motivo;
      Resultados3.Ev.Value1 = Page;
      Resultados3.Ev.Value2 = Valor;
      StatusIO.Vacio = 0;
      StatusIO.Full3 = 1;
 }

/* PRoceso de las alarmas del supervision
 *****************************************/
 void calcProcTxPluvi(uint8_t Motivo, uint16_t Valor)
 {
      Resultados3.Ev.Config=Evento;
      Resultados3.Ev.Channel=Event;
      Resultados3.Ev.Bite.CodeHi=0;
      Resultados3.Ev.Bite.CodeLo=Motivo;
      Resultados3.Ev.Value1=Page;
      Resultados3.Ev.Value2=Valor;
      StatusIO.Vacio=0;
      StatusIO.Full3=1;
 }

/* Funcion que arma los datos por un evento de canal invalido
 ************************************************************/
 void calcProcEvValid(uint16_t Valor)
 {
      Resultados1.Ev.Config=Evento;
      Resultados1.Ev.Channel=Event;
      Resultados1.Ev.Bite.CodeHi=0;
      Resultados1.Ev.Bite.CodeLo=Invalido;
      Resultados1.Ev.Value1=Page;
      Resultados1.Ev.Value2=Valor;
      StatusIO.Vacio=0;
      StatusIO.Full1=1;
 }

/* Funciones del evento del pluvi a cero
 ***************************************/
 void calcProcPluvi0(void)
 {
      Resultados1.Ev.Config=Evento;
      Resultados1.Ev.Channel=Event;
      Resultados1.Ev.Bite.CodeHi=0;
      Resultados1.Ev.Bite.CodeLo=Pluvi0;
      Resultados1.Ev.Value1=Page;
      Resultados1.Ev.Value2=InstAD.Cangilones;
      StatusIO.Vacio=0;
      StatusIO.Full1=1;
 }

 // ValorAct es una copia de InstAD.Cangilones
 void calcSavePluvi(void)
 {
    // Backup del acumulador de PLUVI en Pag23: bytes 2..3
    lowRdPage(0x17);
    if( Buffer.Variable[1].Value != ValorAct )
    {
        Buffer.Variable[31].Byte.Hi -= Buffer.Variable[1].Byte.Hi;
        Buffer.Variable[31].Byte.Hi -= Buffer.Variable[1].Byte.Lo;
        Buffer.Variable[1].Value = ValorAct;
        Buffer.Variable[31].Byte.Hi += Buffer.Variable[1].Byte.Hi;
        Buffer.Variable[31].Byte.Hi += Buffer.Variable[1].Byte.Lo;
        lowWrPage(0x17);
    }
 }

/* PRoceso de las alarmas del supervision digital
 ************************************************/
 void calcProcAlDigital(void)
 {
    if (Buffer.ChStruct.Temporario.TSupervDigital.CntTResetAlarma==0)
    {
        Resultados1.Ev.Config=Evento;
        Resultados1.Ev.Bite.CodeHi=0;
        Resultados1.Ev.Bite.CodeLo=AlCambioDig;
        Resultados1.Ev.Value1=Page;
        Resultados1.Ev.Value2=0;
        StatusIO.Vacio=0;
        StatusIO.Full1=1;
    }
    Buffer.ChStruct.Temporario.TSupervDigital.CntTResetAlarma = Buffer.ChStruct.TResetAlarma;
 }

/* PRoceso de las alarmas de validez del supervision digital
 ***********************************************************/
 void calcProcDgValid(void)
 {
    if (Buffer.ChStruct.Temporario.TSupervDigital.CntTResetAlarma==0)
    {
        Resultados1.Ev.Config=Evento;
        Resultados1.Ev.Bite.CodeHi=0;
        Resultados1.Ev.Bite.CodeLo = CabDigCort;
        Resultados1.Ev.Value1=Page;
        Resultados1.Ev.Value2=0;
        StatusIO.Vacio=0;
        StatusIO.Full1=1;
    }
    Buffer.ChStruct.Temporario.TSupervDigital.CntTResetAlarma = Buffer.ChStruct.TResetAlarma;
 }

