/*
 * The Clear BSD License
 * Copyright (c) 2015 - 2016, Freescale Semiconductor, Inc.
 * Copyright 2016 - 2017 NXP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted (subject to the limitations in the disclaimer below) provided
 * that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of the copyright holder nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * NO EXPRESS OR IMPLIED LICENSES TO ANY PARTY'S PATENT RIGHTS ARE GRANTED BY THIS LICENSE.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#define __SEMIHOST_HARDFAULT_DISABLE //para produccion

//#define DEBUG //definir en cpu_def.h[9] para que sea global. para tener salid por consola del virtualhost


#include <board.h>
#include "fsl_device_registers.h"
#include "clock_config.h"
#include <stdio.h>
#include <stdlib.h>

#include "usb_device_config.h"
#include "usb.h"
#include "usb_device.h"

#include "usb_device_class.h"
#include "usb_device_cdc_acm.h"
#include "usb_device_ch9.h"
#include "fsl_debug_console.h"

#include "usb_device_descriptor.h"
#include "virtual_com.h"
#if (defined(FSL_FEATURE_SOC_SYSMPU_COUNT) && (FSL_FEATURE_SOC_SYSMPU_COUNT > 0U))
#include "fsl_sysmpu.h"
#endif /* FSL_FEATURE_SOC_SYSMPU_COUNT */

#if defined(USB_DEVICE_CONFIG_EHCI) && (USB_DEVICE_CONFIG_EHCI > 0)
#include "usb_phy.h"
#endif
#if defined(FSL_FEATURE_USB_KHCI_KEEP_ALIVE_ENABLED) && (FSL_FEATURE_USB_KHCI_KEEP_ALIVE_ENABLED > 0U) && \
    defined(USB_DEVICE_CONFIG_KEEP_ALIVE_MODE) && (USB_DEVICE_CONFIG_KEEP_ALIVE_MODE > 0U) &&             \
    defined(FSL_FEATURE_USB_KHCI_USB_RAM) && (FSL_FEATURE_USB_KHCI_USB_RAM > 0U)
extern uint8_t USB_EnterLowpowerMode(void);
#endif
#include "pin_mux.h"
#include <stdbool.h>
#include "fsl_power.h"
#include "fsl_wwdt.h"
#include "CPU_def.h"
#include "Variables1.h"




/*******************************************************************************
* Definitions
******************************************************************************/


/*******************************************************************************
 * Prototypes
 ******************************************************************************/
void BOARD_InitHardware(void);
void USB_DeviceClockInit(void);
void USB_DeviceIsrEnable(void);
#if USB_DEVICE_CONFIG_USE_TASK
void USB_DeviceTaskFn(void *deviceHandle);
#endif

void BOARD_DbgConsole_Deinit(void);
void BOARD_DbgConsole_Init(void);
usb_status_t USB_DeviceCdcVcomCallback(class_handle_t handle, uint32_t event, void *param);
usb_status_t USB_DeviceCallback(usb_device_handle handle, uint32_t event, void *param);

void StartUp_IO(void);



//extern void ProAllSeg(void);
//extern void ProAllMin(void);
//extern void ConvOla(void);
//extern void SyncAll(void);
//
//
//extern void SetVar(void);

extern void cadConvAll(void);
extern void cadCalAD(void);

/*******************************************************************************
* Variables
******************************************************************************/
extern usb_device_endpoint_struct_t g_UsbDeviceCdcVcomDicEndpoints[];
extern usb_device_class_struct_t g_UsbDeviceCdcVcomConfig;
/* Data structure of virtual com device */
usb_cdc_vcom_struct_t s_cdcVcom;

uint32_t Com2Contador=0; //pera temporizar COM
uint32_t TMR_SDI=0; //para temporizar SDI12
uint32_t TMR_485=0; //para temporizar RS485

/* Line codinig of cdc device */
USB_DMA_INIT_DATA_ALIGN(USB_DATA_ALIGN_SIZE) static uint8_t s_lineCoding[LINE_CODING_SIZE] = {
    /* E.g. 0x00,0xC2,0x01,0x00 : 0x0001C200 is 115200 bits per second */
    (LINE_CODING_DTERATE >> 0U) & 0x000000FFU,
    (LINE_CODING_DTERATE >> 8U) & 0x000000FFU,
    (LINE_CODING_DTERATE >> 16U) & 0x000000FFU,
    (LINE_CODING_DTERATE >> 24U) & 0x000000FFU,
    LINE_CODING_CHARFORMAT,
    LINE_CODING_PARITYTYPE,
    LINE_CODING_DATABITS};

/* Abstract state of cdc device */
USB_DMA_INIT_DATA_ALIGN(USB_DATA_ALIGN_SIZE) static uint8_t s_abstractState[COMM_FEATURE_DATA_SIZE] = {(STATUS_ABSTRACT_STATE >> 0U) & 0x00FFU,
                                                          (STATUS_ABSTRACT_STATE >> 8U) & 0x00FFU};

/* Country code of cdc device */
USB_DMA_INIT_DATA_ALIGN(USB_DATA_ALIGN_SIZE) static uint8_t s_countryCode[COMM_FEATURE_DATA_SIZE] = {(COUNTRY_SETTING >> 0U) & 0x00FFU,
                                                        (COUNTRY_SETTING >> 8U) & 0x00FFU};

/* CDC ACM information */
USB_DMA_NONINIT_DATA_ALIGN(USB_DATA_ALIGN_SIZE) static usb_cdc_acm_info_t s_usbCdcAcmInfo;
/* Data buffer for receiving and sending*/
USB_DMA_NONINIT_DATA_ALIGN(USB_DATA_ALIGN_SIZE) static uint8_t s_currRecvBuf[DATA_BUFF_SIZE];
extern USB_DMA_NONINIT_DATA_ALIGN(USB_DATA_ALIGN_SIZE)  uint8_t s_currSendBuf[512];
volatile static uint32_t s_recvSize = 0;
extern volatile uint32_t s_sendSize;

/* USB device class information */
static usb_device_class_config_struct_t s_cdcAcmConfig[1] = {{
    USB_DeviceCdcVcomCallback, 0, &g_UsbDeviceCdcVcomConfig,
}};

/* USB device class configuraion information */
static usb_device_class_config_list_struct_t s_cdcAcmConfigList = {
    s_cdcAcmConfig, USB_DeviceCallback, 1,
};

#if defined(FSL_FEATURE_USB_KHCI_KEEP_ALIVE_ENABLED) && (FSL_FEATURE_USB_KHCI_KEEP_ALIVE_ENABLED > 0U) && \
    defined(USB_DEVICE_CONFIG_KEEP_ALIVE_MODE) && (USB_DEVICE_CONFIG_KEEP_ALIVE_MODE > 0U) &&             \
    defined(FSL_FEATURE_USB_KHCI_USB_RAM) && (FSL_FEATURE_USB_KHCI_USB_RAM > 0U)
volatile static uint8_t s_waitForDataReceive = 0;
volatile static uint8_t s_comOpen = 0;
#endif
/*******************************************************************************
* Code
******************************************************************************/
#if (defined(USB_DEVICE_CONFIG_LPCIP3511FS) && (USB_DEVICE_CONFIG_LPCIP3511FS > 0U))
void USB0_IRQHandler(void)
{
    USB_DeviceLpcIp3511IsrFunction(s_cdcVcom.deviceHandle);
}
#endif
#if (defined(USB_DEVICE_CONFIG_LPCIP3511HS) && (USB_DEVICE_CONFIG_LPCIP3511HS > 0U))
void USB1_IRQHandler(void)
{
    USB_DeviceLpcIp3511IsrFunction(s_cdcVcom.deviceHandle);
}
#endif
void USB_DeviceClockInit(void)
{
#if defined(USB_DEVICE_CONFIG_LPCIP3511FS) && (USB_DEVICE_CONFIG_LPCIP3511FS > 0U)
    /* enable USB IP clock */
    CLOCK_EnableUsbfs0DeviceClock(kCLOCK_UsbSrcFro, CLOCK_GetFroHfFreq());
#if defined(FSL_FEATURE_USB_USB_RAM) && (FSL_FEATURE_USB_USB_RAM)
    for (int i = 0; i < FSL_FEATURE_USB_USB_RAM; i++)
    {
        ((uint8_t *)FSL_FEATURE_USB_USB_RAM_BASE_ADDRESS)[i] = 0x00U;
    }
#endif

#endif
#if defined(USB_DEVICE_CONFIG_LPCIP3511HS) && (USB_DEVICE_CONFIG_LPCIP3511HS > 0U)
    /* enable USB IP clock */
    CLOCK_EnableUsbhs0DeviceClock(kCLOCK_UsbSrcUsbPll, 0U);
#if defined(FSL_FEATURE_USBHSD_USB_RAM) && (FSL_FEATURE_USBHSD_USB_RAM)
    for (int i = 0; i < FSL_FEATURE_USBHSD_USB_RAM; i++)
    {
        ((uint8_t *)FSL_FEATURE_USBHSD_USB_RAM_BASE_ADDRESS)[i] = 0x00U;
    }
#endif
#endif
}
void USB_DeviceIsrEnable(void)
{
    uint8_t irqNumber;
#if defined(USB_DEVICE_CONFIG_LPCIP3511FS) && (USB_DEVICE_CONFIG_LPCIP3511FS > 0U)
    uint8_t usbDeviceIP3511Irq[] = USB_IRQS;
    irqNumber = usbDeviceIP3511Irq[CONTROLLER_ID - kUSB_ControllerLpcIp3511Fs0];
#endif
#if defined(USB_DEVICE_CONFIG_LPCIP3511HS) && (USB_DEVICE_CONFIG_LPCIP3511HS > 0U)
    uint8_t usbDeviceIP3511Irq[] = USBHSD_IRQS;
    irqNumber = usbDeviceIP3511Irq[CONTROLLER_ID - kUSB_ControllerLpcIp3511Hs0];
#endif
/* Install isr, set priority, and enable IRQ. */
    NVIC_SetPriority((IRQn_Type)irqNumber, USB_DEVICE_INTERRUPT_PRIORITY);
    EnableIRQ((IRQn_Type)irqNumber);
}
#if USB_DEVICE_CONFIG_USE_TASK
void USB_DeviceTaskFn(void *deviceHandle)
{
#if defined(USB_DEVICE_CONFIG_LPCIP3511FS) && (USB_DEVICE_CONFIG_LPCIP3511FS > 0U)
    USB_DeviceLpcIp3511TaskFunction(deviceHandle);
#endif
#if defined(USB_DEVICE_CONFIG_LPCIP3511HS) && (USB_DEVICE_CONFIG_LPCIP3511HS > 0U)
    USB_DeviceLpcIp3511TaskFunction(deviceHandle);
#endif
}
#endif
/*!
 * @brief CDC class specific callback function.
 *
 * This function handles the CDC class specific requests.
 *
 * @param handle          The CDC ACM class handle.
 * @param event           The CDC ACM class event type.
 * @param param           The parameter of the class specific request.
 *
 * @return A USB error code or kStatus_USB_Success.
 */
usb_status_t USB_DeviceCdcVcomCallback(class_handle_t handle, uint32_t event, void *param)
{
    uint32_t len;
    uint8_t *uartBitmap;
    usb_device_cdc_acm_request_param_struct_t *acmReqParam;
    usb_device_endpoint_callback_message_struct_t *epCbParam;
    usb_status_t error = kStatus_USB_Error;
    usb_cdc_acm_info_t *acmInfo = &s_usbCdcAcmInfo;
    acmReqParam = (usb_device_cdc_acm_request_param_struct_t *)param;
    epCbParam = (usb_device_endpoint_callback_message_struct_t *)param;
    switch (event)
    {
        case kUSB_DeviceCdcEventSendResponse:
        {
            if ((epCbParam->length != 0) && (!(epCbParam->length % g_UsbDeviceCdcVcomDicEndpoints[0].maxPacketSize)))
            {
                /* If the last packet is the size of endpoint, then send also zero-ended packet,
                 ** meaning that we want to inform the host that we do not have any additional
                 ** data, so it can flush the output.
                 */
                error = USB_DeviceCdcAcmSend(handle, USB_CDC_VCOM_BULK_IN_ENDPOINT, NULL, 0);
            }
            else if ((1 == s_cdcVcom.attach) && (1 == s_cdcVcom.startTransactions))
            {
                if ((epCbParam->buffer != NULL) || ((epCbParam->buffer == NULL) && (epCbParam->length == 0)))
                {
                    /* User: add your own code for send complete event */
                    /* Schedule buffer for next receive event */
                    error = USB_DeviceCdcAcmRecv(handle, USB_CDC_VCOM_BULK_OUT_ENDPOINT, s_currRecvBuf,
                                                 g_UsbDeviceCdcVcomDicEndpoints[0].maxPacketSize);
#if defined(FSL_FEATURE_USB_KHCI_KEEP_ALIVE_ENABLED) && (FSL_FEATURE_USB_KHCI_KEEP_ALIVE_ENABLED > 0U) && \
    defined(USB_DEVICE_CONFIG_KEEP_ALIVE_MODE) && (USB_DEVICE_CONFIG_KEEP_ALIVE_MODE > 0U) &&             \
    defined(FSL_FEATURE_USB_KHCI_USB_RAM) && (FSL_FEATURE_USB_KHCI_USB_RAM > 0U)
                    s_waitForDataReceive = 1;
                    USB0->INTEN &= ~USB_INTEN_SOFTOKEN_MASK;
#endif
                }
            }
            else
            {
            }
        }
        break;
        case kUSB_DeviceCdcEventRecvResponse:
        {
            if ((1 == s_cdcVcom.attach) && (1 == s_cdcVcom.startTransactions))
            {
                s_recvSize = epCbParam->length;

#if defined(FSL_FEATURE_USB_KHCI_KEEP_ALIVE_ENABLED) && (FSL_FEATURE_USB_KHCI_KEEP_ALIVE_ENABLED > 0U) && \
    defined(USB_DEVICE_CONFIG_KEEP_ALIVE_MODE) && (USB_DEVICE_CONFIG_KEEP_ALIVE_MODE > 0U) &&             \
    defined(FSL_FEATURE_USB_KHCI_USB_RAM) && (FSL_FEATURE_USB_KHCI_USB_RAM > 0U)
                s_waitForDataReceive = 0;
                USB0->INTEN |= USB_INTEN_SOFTOKEN_MASK;
#endif
                if (!s_recvSize)
                {
                    /* Schedule buffer for next receive event */
                    error = USB_DeviceCdcAcmRecv(handle, USB_CDC_VCOM_BULK_OUT_ENDPOINT, s_currRecvBuf,
                                                 g_UsbDeviceCdcVcomDicEndpoints[0].maxPacketSize);
#if defined(FSL_FEATURE_USB_KHCI_KEEP_ALIVE_ENABLED) && (FSL_FEATURE_USB_KHCI_KEEP_ALIVE_ENABLED > 0U) && \
    defined(USB_DEVICE_CONFIG_KEEP_ALIVE_MODE) && (USB_DEVICE_CONFIG_KEEP_ALIVE_MODE > 0U) &&             \
    defined(FSL_FEATURE_USB_KHCI_USB_RAM) && (FSL_FEATURE_USB_KHCI_USB_RAM > 0U)
                    s_waitForDataReceive = 1;
                    USB0->INTEN &= ~USB_INTEN_SOFTOKEN_MASK;
#endif
                }
            }
        }
        break;
        case kUSB_DeviceCdcEventSerialStateNotif:
            ((usb_device_cdc_acm_struct_t *)handle)->hasSentState = 0;
            error = kStatus_USB_Success;
            break;
        case kUSB_DeviceCdcEventSendEncapsulatedCommand:
            break;
        case kUSB_DeviceCdcEventGetEncapsulatedResponse:
            break;
        case kUSB_DeviceCdcEventSetCommFeature:
            if (USB_DEVICE_CDC_FEATURE_ABSTRACT_STATE == acmReqParam->setupValue)
            {
                if (1 == acmReqParam->isSetup)
                {
                    *(acmReqParam->buffer) = s_abstractState;
                }
                else
                {
                    *(acmReqParam->length) = 0;
                }
            }
            else if (USB_DEVICE_CDC_FEATURE_COUNTRY_SETTING == acmReqParam->setupValue)
            {
                if (1 == acmReqParam->isSetup)
                {
                    *(acmReqParam->buffer) = s_countryCode;
                }
                else
                {
                    *(acmReqParam->length) = 0;
                }
            }
            else
            {
            }
            error = kStatus_USB_Success;
            break;
        case kUSB_DeviceCdcEventGetCommFeature:
            if (USB_DEVICE_CDC_FEATURE_ABSTRACT_STATE == acmReqParam->setupValue)
            {
                *(acmReqParam->buffer) = s_abstractState;
                *(acmReqParam->length) = COMM_FEATURE_DATA_SIZE;
            }
            else if (USB_DEVICE_CDC_FEATURE_COUNTRY_SETTING == acmReqParam->setupValue)
            {
                *(acmReqParam->buffer) = s_countryCode;
                *(acmReqParam->length) = COMM_FEATURE_DATA_SIZE;
            }
            else
            {
            }
            error = kStatus_USB_Success;
            break;
        case kUSB_DeviceCdcEventClearCommFeature:
            break;
        case kUSB_DeviceCdcEventGetLineCoding:
            *(acmReqParam->buffer) = s_lineCoding;
            *(acmReqParam->length) = LINE_CODING_SIZE;
            error = kStatus_USB_Success;
            break;
        case kUSB_DeviceCdcEventSetLineCoding:
        {
            if (1 == acmReqParam->isSetup)
            {
                *(acmReqParam->buffer) = s_lineCoding;
            }
            else
            {
                *(acmReqParam->length) = 0;
            }
        }
            error = kStatus_USB_Success;
            break;
        case kUSB_DeviceCdcEventSetControlLineState:
        {
            s_usbCdcAcmInfo.dteStatus = acmReqParam->setupValue;
            /* activate/deactivate Tx carrier */
            if (acmInfo->dteStatus & USB_DEVICE_CDC_CONTROL_SIG_BITMAP_CARRIER_ACTIVATION)
            {
                acmInfo->uartState |= USB_DEVICE_CDC_UART_STATE_TX_CARRIER;
            }
            else
            {
                acmInfo->uartState &= (uint16_t)~USB_DEVICE_CDC_UART_STATE_TX_CARRIER;
            }

            /* activate carrier and DTE */
            if (acmInfo->dteStatus & USB_DEVICE_CDC_CONTROL_SIG_BITMAP_DTE_PRESENCE)
            {
                acmInfo->uartState |= USB_DEVICE_CDC_UART_STATE_RX_CARRIER;
            }
            else
            {
                acmInfo->uartState &= (uint16_t)~USB_DEVICE_CDC_UART_STATE_RX_CARRIER;
            }

            /* Indicates to DCE if DTE is present or not */
            acmInfo->dtePresent = (acmInfo->dteStatus & USB_DEVICE_CDC_CONTROL_SIG_BITMAP_DTE_PRESENCE) ? true : false;

            /* Initialize the serial state buffer */
            acmInfo->serialStateBuf[0] = NOTIF_REQUEST_TYPE;                /* bmRequestType */
            acmInfo->serialStateBuf[1] = USB_DEVICE_CDC_NOTIF_SERIAL_STATE; /* bNotification */
            acmInfo->serialStateBuf[2] = 0x00;                              /* wValue */
            acmInfo->serialStateBuf[3] = 0x00;
            acmInfo->serialStateBuf[4] = 0x00; /* wIndex */
            acmInfo->serialStateBuf[5] = 0x00;
            acmInfo->serialStateBuf[6] = UART_BITMAP_SIZE; /* wLength */
            acmInfo->serialStateBuf[7] = 0x00;
            /* Notifiy to host the line state */
            acmInfo->serialStateBuf[4] = acmReqParam->interfaceIndex;
            /* Lower byte of UART BITMAP */
            uartBitmap = (uint8_t *)&acmInfo->serialStateBuf[NOTIF_PACKET_SIZE + UART_BITMAP_SIZE - 2];
            uartBitmap[0] = acmInfo->uartState & 0xFFu;
            uartBitmap[1] = (acmInfo->uartState >> 8) & 0xFFu;
            len = (uint32_t)(NOTIF_PACKET_SIZE + UART_BITMAP_SIZE);
            if (0 == ((usb_device_cdc_acm_struct_t *)handle)->hasSentState)
            {
                error = USB_DeviceCdcAcmSend(handle, USB_CDC_VCOM_INTERRUPT_IN_ENDPOINT, acmInfo->serialStateBuf, len);
                if (kStatus_USB_Success != error)
                {
                    usb_echo("kUSB_DeviceCdcEventSetControlLineState error!");
                }
                ((usb_device_cdc_acm_struct_t *)handle)->hasSentState = 1;
            }

            /* Update status */
            if (acmInfo->dteStatus & USB_DEVICE_CDC_CONTROL_SIG_BITMAP_CARRIER_ACTIVATION)
            {
                /*  To do: CARRIER_ACTIVATED */
            }
            else
            {
                /* To do: CARRIER_DEACTIVATED */
            }
            if (acmInfo->dteStatus & USB_DEVICE_CDC_CONTROL_SIG_BITMAP_DTE_PRESENCE)
            {
                /* DTE_ACTIVATED */
                if (1 == s_cdcVcom.attach)
                {
                    s_cdcVcom.startTransactions = 1;

#if defined(FSL_FEATURE_USB_KHCI_KEEP_ALIVE_ENABLED) && (FSL_FEATURE_USB_KHCI_KEEP_ALIVE_ENABLED > 0U) && \
    defined(USB_DEVICE_CONFIG_KEEP_ALIVE_MODE) && (USB_DEVICE_CONFIG_KEEP_ALIVE_MODE > 0U) &&             \
    defined(FSL_FEATURE_USB_KHCI_USB_RAM) && (FSL_FEATURE_USB_KHCI_USB_RAM > 0U)
                    s_waitForDataReceive = 1;
                    USB0->INTEN &= ~USB_INTEN_SOFTOKEN_MASK;
                    s_comOpen = 1;
                    usb_echo("USB_APP_CDC_DTE_ACTIVATED\r\n");
#endif
                }
            }
            else
            {
                /* DTE_DEACTIVATED */
                if (1 == s_cdcVcom.attach)
                {
                    s_cdcVcom.startTransactions = 0;
                }
            }
        }
        break;
        case kUSB_DeviceCdcEventSendBreak:
            break;
        default:
            break;
    }

    return error;
}

/*!
 * @brief USB device callback function.
 *
 * This function handles the usb device specific requests.
 *
 * @param handle          The USB device handle.
 * @param event           The USB device event type.
 * @param param           The parameter of the device specific request.
 *
 * @return A USB error code or kStatus_USB_Success.
 */
usb_status_t USB_DeviceCallback(usb_device_handle handle, uint32_t event, void *param)
{
    usb_status_t error = kStatus_USB_Error;
    uint16_t *temp16 = (uint16_t *)param;
    uint8_t *temp8 = (uint8_t *)param;

    switch (event)
    {
        case kUSB_DeviceEventBusReset:
        {
            s_cdcVcom.attach = 0;
#if (defined(USB_DEVICE_CONFIG_EHCI) && (USB_DEVICE_CONFIG_EHCI > 0U)) || \
    (defined(USB_DEVICE_CONFIG_LPCIP3511HS) && (USB_DEVICE_CONFIG_LPCIP3511HS > 0U))
            /* Get USB speed to configure the device, including max packet size and interval of the endpoints. */
            if (kStatus_USB_Success == USB_DeviceClassGetSpeed(CONTROLLER_ID, &s_cdcVcom.speed))
            {
                USB_DeviceSetSpeed(handle, s_cdcVcom.speed);
            }
#endif
        }
        break;
        case kUSB_DeviceEventSetConfiguration:
            if (param)
            {
                s_cdcVcom.attach = 1;
                s_cdcVcom.currentConfiguration = *temp8;
                if (USB_CDC_VCOM_CONFIGURE_INDEX == (*temp8))
                {
                    /* Schedule buffer for receive */
                    USB_DeviceCdcAcmRecv(s_cdcVcom.cdcAcmHandle, USB_CDC_VCOM_BULK_OUT_ENDPOINT, s_currRecvBuf,
                                         g_UsbDeviceCdcVcomDicEndpoints[0].maxPacketSize);
                }
            }
            break;
        case kUSB_DeviceEventSetInterface:
            if (s_cdcVcom.attach)
            {
                uint8_t interface = (uint8_t)((*temp16 & 0xFF00U) >> 0x08U);
                uint8_t alternateSetting = (uint8_t)(*temp16 & 0x00FFU);
                if (interface < USB_CDC_VCOM_INTERFACE_COUNT)
                {
                    s_cdcVcom.currentInterfaceAlternateSetting[interface] = alternateSetting;
                }
            }
            break;
        case kUSB_DeviceEventGetConfiguration:
            break;
        case kUSB_DeviceEventGetInterface:
            break;
        case kUSB_DeviceEventGetDeviceDescriptor:
            if (param)
            {
                error = USB_DeviceGetDeviceDescriptor(handle, (usb_device_get_device_descriptor_struct_t *)param);
            }
            break;
        case kUSB_DeviceEventGetConfigurationDescriptor:
            if (param)
            {
                error = USB_DeviceGetConfigurationDescriptor(handle,
                                                             (usb_device_get_configuration_descriptor_struct_t *)param);
            }
            break;
        case kUSB_DeviceEventGetStringDescriptor:
            if (param)
            {
                /* Get device string descriptor request */
                error = USB_DeviceGetStringDescriptor(handle, (usb_device_get_string_descriptor_struct_t *)param);
            }
            break;
        default:
            break;
    }

    return error;
}

/*!
 * @brief Application initialization function.
 *
 * This function initializes the application.
 *
 * @return None.
 */
void APPInit(void)
{
    USB_DeviceClockInit();
#if (defined(FSL_FEATURE_SOC_SYSMPU_COUNT) && (FSL_FEATURE_SOC_SYSMPU_COUNT > 0U))
    SYSMPU_Enable(SYSMPU, 0);
#endif /* FSL_FEATURE_SOC_SYSMPU_COUNT */

    s_cdcVcom.speed = USB_SPEED_FULL;
    s_cdcVcom.attach = 0;
    s_cdcVcom.cdcAcmHandle = (class_handle_t)NULL;
    s_cdcVcom.deviceHandle = NULL;

    if (kStatus_USB_Success != USB_DeviceClassInit(CONTROLLER_ID, &s_cdcAcmConfigList, &s_cdcVcom.deviceHandle))
    {
        usb_echo("USB device init failed\r\n");
    }
    else
    {
        usb_echo("USB device CDC virtual com demo\r\n");
        s_cdcVcom.cdcAcmHandle = s_cdcAcmConfigList.config->classHandle;
    }

    USB_DeviceIsrEnable();

    USB_DeviceRun(s_cdcVcom.deviceHandle);
}

/*!
 * @brief Application task function.
 *
 * This function runs the task for application.
 *
 * @return None.
 */
void USBTask(void)
{
    usb_status_t error = kStatus_USB_Error;
    if ((1 == s_cdcVcom.attach) && (1 == s_cdcVcom.startTransactions))
    {

        /* User Code */
        if ((0 != s_recvSize) && (0xFFFFFFFFU != s_recvSize))
        {
            int32_t i;
            Status.Com2On=1;                        // Flag de Com 2 en 1
            Com2Contador=50;
            /* Copy Buffer to Send Buff */
            for (i = 0; i < s_recvSize; i++)
            {
                //s_currSendBuf[s_sendSize++] = s_currRecvBuf[i];
                //printf("%c",s_currRecvBuf[i]); //MAC
                intProcUSB(s_currRecvBuf[i]);
            }
            s_recvSize = 0;
        }

        if (s_sendSize)
        {
            uint32_t size = s_sendSize;
            s_sendSize = 0;

            error = USB_DeviceCdcAcmSend(s_cdcVcom.cdcAcmHandle, USB_CDC_VCOM_BULK_IN_ENDPOINT, s_currSendBuf, size);

            if (error != kStatus_USB_Success)
            {
                /* Failure to send Data Handling code here */
            }
        }

        //USB attached, COM2
     //   Status.Com2On=1;                        // Flag de Com 2 en 1
     //   BufUart.TimeOut = 5;
#if defined(FSL_FEATURE_USB_KHCI_KEEP_ALIVE_ENABLED) && (FSL_FEATURE_USB_KHCI_KEEP_ALIVE_ENABLED > 0U) && \
    defined(USB_DEVICE_CONFIG_KEEP_ALIVE_MODE) && (USB_DEVICE_CONFIG_KEEP_ALIVE_MODE > 0U) &&             \
    defined(FSL_FEATURE_USB_KHCI_USB_RAM) && (FSL_FEATURE_USB_KHCI_USB_RAM > 0U)
        if ((s_waitForDataReceive))
        {
            if (s_comOpen == 1)
            {
                /* Wait for all the packets been sent during opening the com port. Otherwise these packets may
                                        * wake up the system.
                */
                usb_echo("Waiting to enter lowpower ...\r\n");
                for (uint32_t i = 0U; i < 16000000U; ++i)
                {
                    __ASM("NOP"); /* delay */
                }

                s_comOpen = 0;
            }
            usb_echo("Enter lowpower\r\n");
            BOARD_DbgConsole_Deinit();
            USB0->INTEN &= ~USB_INTEN_TOKDNEEN_MASK;
            USB_EnterLowpowerMode();

            s_waitForDataReceive = 0;
            USB0->INTEN |= USB_INTEN_TOKDNEEN_MASK;
            BOARD_DbgConsole_Init();
            usb_echo("Exit  lowpower\r\n");
        }
#endif
    }
 //   else
 //   	{
 //   	Status.Com2On=0; //USB desconectado
 //   	}
}


#if defined(__CC_ARM) || defined(__GNUC__)
int main(void)
#else
void main(void)
#endif
{

    /* attach 12 MHz clock to FLEXCOMM0 (COM PC) */
    CLOCK_AttachClk(BOARD_DEBUG_UART_CLK_ATTACH);

    BOARD_InitPins();
  //  BOARD_BootClockFROHF96M();
    BOARD_BootClockRUN();
 //  BOARD_InitDebugConsole(); 20181210 lo deshabilito paraa ver si interfiere con UART

#if (defined USB_DEVICE_CONFIG_LPCIP3511HS) && (USB_DEVICE_CONFIG_LPCIP3511HS) //high speed (480Mb/s)
    POWER_DisablePD(kPDRUNCFG_PD_USB1_PHY);
    /* enable usb1 host clock */
    CLOCK_EnableClock(kCLOCK_Usbh1);
    /*According to reference mannual, device mode setting has to be set by access usb host register */
    *((uint32_t *)(USBHSH_BASE + 0x50)) |= USBHSH_PORTMODE_DEV_ENABLE_MASK;
    /* enable usb1 host clock */
    CLOCK_DisableClock(kCLOCK_Usbh1);
#endif
#if (defined USB_DEVICE_CONFIG_LPCIP3511FS) && (USB_DEVICE_CONFIG_LPCIP3511FS)  //full Speed (12Mb/s)
    //es este el que está definido! MAC
    POWER_DisablePD(kPDRUNCFG_PD_USB0_PHY); /*< Turn on USB Phy */
    CLOCK_SetClkDiv(kCLOCK_DivUsb0Clk, 1, false);
    CLOCK_AttachClk(kFRO_HF_to_USB0_CLK);
    /* enable usb0 host clock */
    CLOCK_EnableClock(kCLOCK_Usbhsl0);
    /*According to reference mannual, device mode setting has to be set by access usb host register */
    *((uint32_t *)(USBFSH_BASE + 0x5C)) |= USBFSH_PORTMODE_DEV_ENABLE_MASK;
    /* disable usb0 host clock */
    CLOCK_DisableClock(kCLOCK_Usbhsl0);
#endif

    APPInit();

	uint32_t watchValue= lowWatchDogInit();

	__PORTAP_bit.MemAusente=1;//no hay Memoria extraible!

	batADC_ClockPower_Configuration(); //inicializa ADC interno para sensado de Bateria

	lowEEPInternaInit(); //inicializa la eeprom, de donde lee la configuracion

	//habilita interrupcion de Timer 8ms
	 s_ticker_init();

	//TODO SoftWD=0;   //Se borra el WatchDog
	ioStartUp();  //Realiza la rutina de inicialización
    vtoFindViento(); //Se busca el canal con anemómetro y veleta para procesar según corresponda
	//SoftWD=0;
	//TODO OnSPI(); //Funciones que generan el SPI para el conversor AD
	BitValid.MalAD=0;
	cadCalAD(); //Setea el modo de funcionamiento del conversor Analógico/Digital (AD)
	if (BitValid.MalAD){  // EVENTO de error del CAD
		 Resultados3.Ev.Config=Evento;
		 Resultados3.Ev.Channel=Event;
		 Resultados3.Ev.Bite.CodeHi=0;
		 Resultados3.Ev.Bite.CodeLo=ErrCAD;
		 Resultados3.Ev.Value1=0;
		 Resultados3.Ev.Value2=0;
		 StatusIO.Full3=1;
		 StatusIO.Vacio=0;
	};

	//s_ticker_init();  //con timer 1
		 		s_ticker_init_RTC(); //con RTC
	// Inicializa puerto de encendido de sensores. Alimenta los sensores forzado para inicializar los valores de ref en ini
	IniAlimentacion(1);
	//__PORTED_bit.Cut2=1;  --ya lo incorporé en IniAlimentacion()
	//__PORTED_bit.Cut1=1;

    // espera 2 segundos aprox
	while (!Timing.Bits.Pps){ WWDT_Refresh(WWDT);};
		   Timing.Bits.Pps=0;
	while (!Timing.Bits.Pps){ WWDT_Refresh(WWDT);};
 		   Timing.Bits.Pps=0;

    // Habilita medicion de todos los canales + Ola
	//SetCanal(Canal0v); --maneja el MUX, ya no se usa mas, ahora canal se selecciona en SPI
	FlagsAD.MeterAll=1;
	FlagsAD.MeterOla=1;
	cadConvAll();

	IniAlimentacion(0); //apaga alimentacion de sensores

	//INI de CPU
	//PointersIni();
	 cntMalBAT = 0;
	 cntMalOrbcomm = 0;
	 Status.BatOK = 1;
	 // SoftWD = 0;
	 WWDT_Refresh(WWDT);
	 cpuInicio = 5;
	 	 cpuStartUp(watchValue); //  Inicializa los timers para las interrupciones (todo CONFIRMAR)
	 	 txedInit(1); //carga punteros desde flash

	 chIniAnalogicos();

	 __PORTAP_bit.BateriaOK=batADC_ADQ_OK();

	 lowUartIni();//Inicializa UART
	 SDI_lowUartIni(); //inicializaSDI12
	 RS485_lowUartIni(); //inicializa RS485
     printf("hola");
    while (1)
    {
        USBTask(); // tarea del USB TODO enviar datos a trama del COM
        COMTask(); //tarea del puerto COM entra solo si el USB desactivado
        SDI_Task();//tarea del SDI12
        RS485_Task(0);//tarea del RS485
        //Tareas de la IO
        //Verifica el external interrupt pending (SET si alguna EXP tiene un valor), y luego mandar el
        //comando RdAny para que se comuniquen la CPU y la EXP
        //slvAnswerUwire(EXP0)
        // Deshabilita Ints y copia valores de los flags pps, ppm a PpsCopy, PpmCopy
        lowRtcUpDate();
        if (Timing.Bits.PpsCopy){
        	//s_currSendBuf[s_sendSize++]='s';
        	WWDT_Refresh(WWDT); //refresh watch dog
        	//procesamiento de Segundo del CPU
        	if(cpuInicio) cpuInicio--;  // Flag que señaliza reinicio de la CPU
        	//if(__PORTCP_bit.BatOK)
        	//if(batADC_ADQ_OK())  // Recuperacion del Estado BatOK //TODO acá ver bateria
        	if(__PORTAP_bit.BateriaOK)
				{   if(cntMalBAT) cntMalBAT--;
					else  // Reinicio CPU + IO: para Resincronismo de RTCs y Agenda
					{ if(!Status.BatOK){
						PowerOn55=0x56;
						//SoftWD=60;
						lowUCReset();
						/*while(1){};*/
						}} // WD en cpu
				}
        	// Luego de 2,x segundos de no recibir caracteres vuelve al estado inicial
        	if(BufUart.TimeOutRx==0) BufUart.BufState = HeaderAst;
        	else BufUart.TimeOutRx--;

        	if(Com2Contador)Com2Contador--;
        	else {
				Status.UartFull=0; //MAC2020
				Status.Com2On=0; //Prende el com
				}

        	if(contadorUART && rxOnGoing){ //reinicia recepcion por UART
        		contadorUART--;
        		if (contadorUART==0){
        			rxBufferEmpty = false;
        			rxOnGoing = false;
					Status.UartFull=0;//MAC2020
        		}

        	}

        	if(Status.BatOK)
			  {
        		// Procesa el segundero de todos los canales
        		// Enciende alimentacion si es necesario, Toma mediciones del A/D en todos los canales
        		// Acumula las mediciones e incrementa el contador
        		chProAllSeg();

				// Actualiza y Procesa RTC (minutos y segundos)
				if(Status.ErrRTC) { Status.ErrRTC = 0;  rtcRead(&Rtc, 1); } //lee hora y fecha
				else              { Status.ErrRTC = 0;  rtcRead(&Rtc, 0); } //lee hora
				// Evento de Falla de RTC
				if(cntMalRTC == 240) {  execMakeReini(ReiniErrRTC); execExePack(&PackTemp.Ev.Config);}

			//	lowCom2Proc();  // Verifica conexion en el COM 2, inicializa Timeout p/desconexion  MAC------------------------ver!!!
				execEventProc(); //Enciende el com 1, si hay evento para transmitir inmediatamente
				lowOnOffCom();  // Enciende o Apaga los puertos Comm
				lowUartError(); // Revisa los flags de Error, reinicia la UART si es necesario
				if((Rtc.Seconds & 0x20) && !Rtc.Ctrl.Ppm)  // Tic de minuto: Seconds >= 32
				{   // Cada 10 Minutos (min=X8, Segundo=32) -> Sincroniza Relojes
					if((Rtc.Time % 10) == 8) Status.RtcIO = 1;
					// GGB31 - Cada 60 Minutos (min=3, Segundo=32) -> Fuerza lectura de Fecha
					if((Rtc.Time % 60) == 3) Status.ErrRTC = 1;
					// Tb puede sincronizar por Inicializacion o por comando de WrCoreState en Puerto com
					if(Status.RtcIO || cntMalIO)
					{
						// Esta linea esta generando reinicio de la IO, una o dos veces al dia
						//intraWrParamUWIRE();    el reloj es es mismo, no hace falta sincronizar
						//TODO sincroniza relojes!! si ok, cntMalIO=0, si no, cntMalIO++. si cntMalIO>120, PowerOn55=0x56; reset micro!!!!!!!
						rtcRead(&Rtc, 1); //sincroniza relojes
						Status.RtcIO = 0;
						cntMalIO=0;
					}
					Rtc.Ctrl.Ppm = 1;
					// GGB31 - doy mas chances para que se active Ppd
					if(Rtc.Time > 1430) Rtc.Ctrl.Ppd = 1; // lo enciendo 10 minutos antes

					if(Rtc.Time%2)
						{
							__PORTAP_bit.BateriaOK=batADC_ADQ_OK();//20181210
						}
				}
			  }// End BatOK
			// strncpy(c1_txbuffer, "hello", 5);
			// USART_WriteBlocking(USART1, c1_txbuffer, 5);
			if (0!=TMR_SDI)TMR_SDI--; //descuenta tiempo de espera de medicion del SDI12
			if (0!=TMR_485)TMR_485--; //descuenta tiempo de espera de medicion del RS485
        	Timing.Bits.PpsCopy=0;
        	 SDI12_motor();//procesa el puerto SDI12. Ver donde ubicarlo
        	 RS485_motor();
            } //Timing.Bits.PpsCopy
        cadConvOla(); //de IO
        if (Timing.Bits.PpmCopy){
        	//s_currSendBuf[s_sendSize++]='m';
        	//if(++Time >= 1440) Time = 0;  // Minutero del RTC
        	// Procesa el minutero de todos los canales
        	// Señaliza en "Hay.Full" si el canal tiene nuevo dato (TRead)
        	Time=Rtc.Time;// importante, se usa en procesamientos!
        	chProAllMin();

        	// Cada 6hs Habilita un nuevo evento de error del AD
        	if((Rtc.Time%360) == 0){
        		   BitValid.EventoAD=0;
        		   rtcRead(&Rtc, 1); //agregado 10/12/2018
        	       }

        	//Procesamiento de minuto CPU
        	if(Status.BatOK)
				{
				//__PORTGD_bit.PPD=1; // 1->0: Señalizacion de nuevo dia para sincronismo de la IO TODO ver como era este mecanismo
				// Procesamiento de DIA
				if(Rtc.Ctrl.Ppd && (Rtc.Time < 5) )  // Una vez por dia, minuto menor a 5
				{
					 // if(Rtc.Time==0) __PORTGD_bit.PPD = 0; // Señal nuevo dia p/IO TODO ver cómo hacer sincronismo con IO.
					  // GGB 03/03/09: proceso el flag de lectura del RTC
					  Status.ErrRTC = 0;
					  rtcRead(&Rtc, 1);   // Lee Seconds, Time, Date
					  if(Status.ErrRTC) Rtc.Date++; // Avanzo fecha en caso de lectura erronea

					  execProcDia();      // Guarda la fecha y hora actual en todas las pilas
					  uniMakeRstAgend();  // Resincronismo de la Agenda
					  Status.TxHora = 1;  // Indica a la EC q debe poner en hora
					  cntMalOrbcomm = 0;
					  Rtc.Ctrl.Ppd = 0;
				}
				// Proc. Minuto
				execProcMinuto(); // Re Check IO si esta en falla
				execAgendProc();  // Inicia y Cierra ventana de Comm
				#ifdef DEBUG
				 printf("RTCe: %04d \r\n", Rtc.Time);
				#endif
			  }//Status.BatOK
        	Timing.Bits.PpmCopy=0;
        	Rtc.Ctrl.Ppm = 0;
        	}//Minuto
        //SoftWD=0;

        // Procesa el TRead, TStorage, TEval, TDiscret, TCero. Calcula Promedios, Maximos, Minimos
        // Invoca a chCalLimnimetrico, chCalMeteorologico ... segun "Hay.Full"
        // Se procesa un canal por cada pasada, no ponerlo dentro de un if !!!
        chCalAll();
        // Pulso en PORTF.3, señaliza requerimiento en bus uWire a la CPU
        // Actua en PORTG.0 de la CPU estando el Dip Switch en 1, Activa Ext. Int. Pending Flag
        if (!StatusIO.Vacio)
            {
            // TODO guardar en memoria de CPU (IO tiene datos, avisaba por UW)
        	//__PORTFD_bit.Ring=1;
        	//__PORTFD_bit.Ring=0;
        	//intraRdAnyUWIRE-> envia comando rdAny
        	intraRdAny();
            };
        //SyncAll(); //todo ver que hacia
        //Tareas de CPU

       /*************** Procesa placa IO si esta presente ******************/
       // Inhibo los untimos segundos del dia para que no tome registros a las 00 sin haber hecho
	   // el execProcDia()
	   if(!cntMalIO && Status.BatOK && !Rtc.Ctrl.Ppd)
	   {  // Evaluo si hay peticion de la IO, Ext. Int. Flag generado por PORTF.3 IO en PORTG.0 CPU
		  // Envio Frame a uWr+, Recibo Frame de uWr+ ... si hay algo
		  //intraRdAnyUWIRE(); //todo ver que hace aca!
		   intraRdAny();
		  // El flag Status.ReiniIO se encenderia en intraRdAnyUWIRE()
		  if(Status.ReiniIO)  // Reinicio de la IO solamente, Se activa con el evento
		  {   Status.RtcIO = 1;
			  txedInit(0);
			  Status.ReiniIO = 0;
		  }
	   }

       /********* Procesa Qry Comunicaciones y Tx la respuesta *************/
       SoftWD = 0;
       if(Status.UartFull && Status.BatOK) {
       	uniRxExe(); // El flag se activa en la Rx_Interrupt
       }

#if USB_DEVICE_CONFIG_USE_TASK
        USB_DeviceTaskFn(s_cdcVcom.deviceHandle);
#endif
    }
}
