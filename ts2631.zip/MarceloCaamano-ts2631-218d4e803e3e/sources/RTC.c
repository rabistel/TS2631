/*
 * RTC.c
 *
 *  Created on: 15 ago. 2018
 *      Author: Marcelo.Caamaño
 */
#include "CPU_def.h"
#include "fsl_i2c.h"
#include "fsl_rtc.h"


//#include "pin_mux.h" TODO aca configurar los pines
#define I2C_RTC_BASE (I2C2_BASE)
#define I2C_RTC_MASTER_CLOCK_FREQUENCY (12000000)
#define RTC_I2C_MASTER ((I2C_Type *)I2C_RTC_BASE)

#define RTC_I2C_ADDR_7BIT 0x68U // 1101000  address del DS1338
#define I2C_BAUDRATE 60000u;//100000U
#define I2C_DATA_LENGTH 33U

/*******************************************************************************
 * Variables
 ******************************************************************************/

//uint8_t g_master_txBuff[I2C_DATA_LENGTH];
//uint8_t g_master_rxBuff[I2C_DATA_LENGTH];
volatile bool g_MasterCompletionFlag = false;

//void delay(void){};
void i2cStartRTC(void);
void i2cStopRTC(void){};
void i2cWrite(uint8_t byte); //TODO implementar para este micro
uint8_t i2cRead(void);



void i2cConfigRTC(void){
    i2c_master_config_t masterConfig;
   // status_t reVal = kStatus_Fail;
   // uint8_t deviceAddress = 0x01U;

    /* attach 12 MHz clock to FLEXCOMM0 (debug console) */
   // CLOCK_AttachClk(BOARD_DEBUG_UART_CLK_ATTACH);

    /* attach 12 MHz clock to FLEXCOMM8 (I2C master) */
    CLOCK_AttachClk(kFRO12M_to_FLEXCOMM2); //TODO, ver cual flexcomm es

    /* reset FLEXCOMM for I2C */
    RESET_PeripheralReset(kFC2_RST_SHIFT_RSTn);

    /*
	* masterConfig.debugEnable = false;
	* masterConfig.ignoreAck = false;
	* masterConfig.pinConfig = kI2C_2PinOpenDrain;
	* masterConfig.baudRate_Bps = 100000U;
	* masterConfig.busIdleTimeout_ns = 0;
	* masterConfig.pinLowTimeout_ns = 0;
	* masterConfig.sdaGlitchFilterWidth_ns = 0;
	* masterConfig.sclGlitchFilterWidth_ns = 0;
	*/
   I2C_MasterGetDefaultConfig(&masterConfig);

   /* Change the default baudrate configuration */
   masterConfig.baudRate_Bps = I2C_BAUDRATE;

   /* Initialize the I2C master peripheral */
   I2C_MasterInit(RTC_I2C_MASTER, &masterConfig, I2C_RTC_MASTER_CLOCK_FREQUENCY);
}

void i2cStartRTC(void){
	status_t reVal = kStatus_Fail;
	reVal=I2C_MasterStart(RTC_I2C_MASTER, RTC_I2C_ADDR_7BIT, kI2C_Write);
}

void i2cWrite(uint8_t byte){
	status_t reVal = kStatus_Fail;
	 /* Send master blocking data to slave */
	 //if (kStatus_Success == I2C_MasterStart(RTC_I2C_MASTER, RTC_I2C_ADDR_7BIT, kI2C_Write))
	 reVal = I2C_MasterWriteBlocking(RTC_I2C_MASTER, &byte, 1, kI2C_TransferNoStopFlag);//0);
}

uint8_t i2cRead(void){
	status_t reVal = kStatus_Fail;
	uint8_t byte;
	reVal = I2C_MasterRepeatedStart(RTC_I2C_MASTER, RTC_I2C_ADDR_7BIT, kI2C_Read);
	reVal = I2C_MasterReadBlocking(RTC_I2C_MASTER, &byte, 1, 0);
	return byte;
}

void i2cStoptRTC(void){
	status_t reVal = kStatus_Fail;
	reVal = I2C_MasterStop(RTC_I2C_MASTER);

}

#define DS1338_SEC      0
#define DS1338_MIN      1
#define DS1338_HR       2
#define DS1338_DAY      3
#define DS1338_DATE     4
#define DS1338_MONTH    5
#define DS1338_YR       6
#define DS1338_CONTROL  7

uint8_t read_ds1338(uint8_t address)
{
   uint8_t result; //puede ser un uint8_t

   i2cStartRTC(); //solicitud de bus
   //i2cWrite( 0xD0); //escritura de bus
   i2cWrite( address);// escritura de bus
  // i2cStartRTC(); // reinicio de bus
   //i2cStoptRTC();
   //i2cWrite( 0xD1); //escrtura
   result = i2cRead(); //lectura de bus
   i2cStoptRTC(); // liberacion de bus

   return(result);
}

void write_ds1338(uint8_t address, uint8_t data)
{
   i2cStartRTC();
   //i2cWrite( 0xD0);
   i2cWrite( address);
   i2cWrite( data);
   i2cStoptRTC();
}

void i2crtc_init()
{
   uint8_t data;

   data = read_ds1338(DS1338_SEC);

   data &= 0x7F;

   i2cStartRTC();
   i2cWrite( 0xD0);
   i2cWrite( DS1338_SEC);
   i2cWrite( data);
   i2cStartRTC();
   i2cWrite( 0xD0);
   i2cWrite( DS1338_CONTROL);
   i2cWrite( 0x80);
   i2cStoptRTC();
}

uint8_t get_bcd(uint8_t data)
{
   uint8_t nibh;
   uint8_t nibl;

   nibh=data/10;
   nibl=data-(nibh*10);

   return((nibh<<4)|nibl);
}

uint8_t rm_bcd(uint8_t data)
{
   uint8_t i;

   i=data;
   data=(i>>4)*10;
   data=data+(i&0x0F);

   return data;
}

void rtc_set_datetime(uint8_t day, uint8_t mth, uint8_t year, uint8_t dow, uint8_t hr, uint8_t min, uint8_t seg)
{
	   i2cStartRTC();
/*
	   i2cWrite( DS1338_SEC);
	   i2cWrite(0x50);
	   //i2cWrite( DS1338_MIN);
	   i2cWrite( 0x50);
	   //i2cWrite( DS1338_HR);
	   i2cWrite( 0x01); //pone en modo 24horas
	   //i2cWrite( DS1338_DAY);
	   i2cWrite( 0x01);
	   //i2cWrite( DS1338_DATE);
	   i2cWrite(0x16);
	   //i2cWrite( DS1338_MONTH);
	   i2cWrite( 0x11);
	   //i2cWrite( DS1338_YR);
	   i2cWrite( 0x18);
	   i2cStoptRTC();*/
   i2cWrite( DS1338_SEC);
   i2cWrite( get_bcd(seg));
   i2cWrite( get_bcd(min));
   i2cWrite( (get_bcd(hr) & 0x3F)); //pone en modo 24horas
   i2cWrite( get_bcd(dow));
   i2cWrite(get_bcd(day));
   i2cWrite( get_bcd(mth));
   i2cWrite( get_bcd(year));
   i2cStoptRTC();
/*
   write_ds1338(DS1338_SEC,(get_bcd(seg)|0x80)); //paro el reloj
   write_ds1338(DS1338_MIN,get_bcd(min));
   write_ds1338(DS1338_HR,(get_bcd(hr)&0x3F));
   write_ds1338(DS1338_DAY,get_bcd(dow));
   write_ds1338(DS1338_DATE,get_bcd(day));
   write_ds1338(DS1338_MONTH,get_bcd(mth));
   write_ds1338(DS1338_YR,get_bcd(year));
*/
   /*Seteo Rtc interno tambien*/
   rtc_datetime_t date;
   date.year = year;
   date.month = mth;
   date.day = day;
   date.hour = hr;
   date.minute = min;
   date.second = seg;
   /* RTC time counter has to be stopped before setting the date & time in the TSR register */
   RTC_StopTimer(RTC);
   /* Set RTC time to default */
   RTC_SetDatetime(RTC, &date);
   RTC->MATCH = RTC->COUNT + 1;
   /* Start the RTC time counter */
   RTC_StartTimer(RTC);

}

void rtc_get_date(uint8_t * date, uint8_t * mth, uint8_t * year, uint8_t * dow)
{
   *date = rm_bcd(read_ds1338(DS1338_DATE));
   *mth = rm_bcd(read_ds1338(DS1338_MONTH));
   *year = rm_bcd(read_ds1338(DS1338_YR));
   *dow = rm_bcd(read_ds1338(DS1338_DAY));
}

void rtc_get_time(uint8_t * hr, uint8_t * min, uint8_t * sec)
{
   *hr = rm_bcd((read_ds1338(DS1338_HR) & 0x3F));
   *min = rm_bcd(read_ds1338(DS1338_MIN));
   *sec = rm_bcd((read_ds1338(DS1338_SEC)& 0x7F));
}


/**********************************************************************************************
                    FUNCIONES DE ALTO NIVEL
**********************************************************************************************/

/* Accede al RTC y actualiza la hora del sistema
   si actFecha != 0 -> ademas actualiza la fecha
*/
void rtcRead(__rtc_type *rtc, uint8_t actFecha)
{
  uint8_t seg,min,hora,dia,mes,anio,dow;
  uint16_t timeTmp;

  if (actFecha) //si actFecha es 0, lee desde el RTC interno. Se evita la lectura desde el Externo MAC2020
  {
  i2cConfigRTC();
  rtc_get_date( &dia, &mes, &anio, &dow);
  rtc_get_time( &hora, &min, &seg );
  }
  else  //MAC2020
  {  //dia, mes y año no se usan acá.
  hora=dateG.hour;
  min=dateG.minute;
  seg=dateG.second;
  }
/*
  printf("RTC externo: %04d-%02d-%02d %02d:%02d:%02d\r\n",
    				  anio,
    				  mes,
    				  dia,
    				  hora,
    				  min,
    				  seg);
*/
  // Paso de formato BCD a binario
  //ya viene en binario
  //seg = ((seg>>4) * 10) + (seg & 0x0F);
  //min = ((min>>4) * 10 ) + (min & 0x0F);
  //hora = ((hora>>4) * 10 ) + (hora & 0x0F);
  timeTmp = hora * 60 + min;

  // Verifico consistencia del dato leido
  if((seg < 60) && (timeTmp < 1440))
  {   rtc->Seconds = seg;
      if(timeTmp == rtc->Time)
      {  if(cntMalRTC < 250)  cntMalRTC++; } // No avanzo minuto, falla de oscilador
      else                    cntMalRTC = 0;
      rtc->Time = timeTmp;
  }
  else// falla de RTC, error de formato
  {   // hago avanzar el segundero para que se ejecute el minutero en el main
      if(++rtc->Seconds >= 60) rtc->Seconds=0;
// GGB30: mantengo el flag Status.ErrRTC para error en lectura de fecha
//      Status.ErrRTC = 1;
      if(cntMalRTC < 250) cntMalRTC++;
  }

  // A partir de anio, mes, dia leidos del chip de reloj debo obtener rtc.Date
  if(actFecha)
  {
      /*Seteo Rtc interno tambien*/
      rtc_datetime_t date;
      date.year = 2000+anio;// 2000+anio;
      date.month = mes;
      date.day = dia;
      date.hour = hora;
      date.minute = min;
      date.second = seg;
      /* RTC time counter has to be stopped before setting the date & time in the TSR register */
      RTC_StopTimer(RTC);
      /* Set RTC time to default */
      RTC_SetDatetime(RTC, &date);
      RTC->MATCH = RTC->COUNT + 1;
      /* Start the RTC time counter */
      RTC_StartTimer(RTC);

	 // Obtengo dias transcurridos desde 01/01/01
   // dia = ((dia>>4) * 10 ) + (dia & 0x0F);
   // mes = ((mes>>4) * 10 ) + (mes & 0x0F);
   // anio = ((anio>>4) * 10 ) + (anio & 0x0F);

    if((anio!=0) && (mes!=0) && (mes<13) && (dia!=0) && (dia<32))
    {
      rtc->Date = dia;  // Acumulo dia
      while(--mes)      // Acumulo mes
      {
        switch (mes){
          case  1:  rtc->Date += 31;
                    break;
          case  2:  rtc->Date += 28;
                    if(!(anio % 4)) rtc->Date++;  // Si el actual es biciesto sumo 1
                    break;
          case  3:  rtc->Date += 31;
                    break;
          case  4:  rtc->Date += 30;
                    break;
          case  5:  rtc->Date += 31;
                    break;
          case  6:  rtc->Date += 30;
                    break;
          case  7:  rtc->Date += 31;
                    break;
          case  8:  rtc->Date += 31;
                    break;
          case  9:  rtc->Date += 30;
                    break;
          case  10: rtc->Date += 31;
                    break;
          case  11: rtc->Date += 30;
                    break;
        }
      }
      anio--;
      rtc->Date += (uint16_t)anio * 365; // Acumulo años
      rtc->Date += (anio / 4);  // Sumo bisiestos anteriores al actual

    }
    else  Status.ErrRTC = 1;
  }
}

/* Programa el RTC con la hora del sistema */
void rtcSet(__rtc_type rtc)
{
  uint8_t seg,min,hora,dia,mes,anio;
  uint16_t temp;

  // A partir de rtc.Date debo obtener año, mes, dia para grabar al chip de reloj
  // Proceso dias de los años que hayan pasado desde 2001
  anio = 1;
  temp = 365;
  while(rtc.Date > temp)
  {
    rtc.Date -= temp;
    // Nuevo año a descontar
    anio++;
    // Verifico si corresponde con un biciesto
    if( !(anio%4) ) temp=366;
    else            temp=365;
  }
  // Proceso dias de los meses que pasaron el año actual
  mes = 1;
  dia = 31;
  while(rtc.Date > dia)
  {
    rtc.Date -= dia;
    mes++;
    switch (mes) {
      case  2:  dia = 28;
                if( !(anio%4) ) dia++;
                break;
      case  3:  dia = 31;
                break;
      case  4:  dia = 30;
                break;
      case  5:  dia = 31;
                break;
      case  6:  dia = 30;
                break;
      case  7:  dia = 31;
                break;
      case  8:  dia = 31;
                break;
      case  9:  dia = 30;
                break;
      case  10: dia = 31;
                break;
      case  11: dia = 30;
                break;
      // El mes 12 no se procesa pues si hubiese en esta instancia mas de 31 dias deberia
      // haber sumado un año mas en el paso previo
    }
  }
  // Proceso Dias, es el resto que me quedo luego de descontar todos los años enteros pasados desde
  // el 2001 y los meses enteros pasados el año en curso
  dia = rtc.Date;
  // Proceso horas, minutos
  hora = 0;
  while(rtc.Time > 59)
  { // Horas pasadas el dia de hoy
    hora++;
    rtc.Time -= 60;
  }
  min = rtc.Time;
  // Proceso Segundos
  seg = rtc.Seconds;

  /*
  i2cStart();
  i2cWrite(0xD0); // Slave Address, Escritura
  i2cWrite(0x00); // Word Address
  i2cWrite((( seg/10)<<4 ) | ( seg%10 ) & 0x7F );
  i2cWrite((( min/10)<<4 ) | ( min%10 ));
  i2cWrite((( hora/10)<<4 ) | ( hora%10 ) & 0x3F ); // 24 hr mode
  i2cWrite(0);
  i2cWrite((( dia/10)<<4 ) | ( dia%10 ));
  i2cWrite((( mes/10)<<4 ) | ( mes%10 ));
  i2cWrite((( anio/10)<<4 ) | ( anio%10 ));
  i2cWrite(0x93);	//control: sq out 32khz
  i2cStop();
  */
  i2cConfigRTC();
  i2crtc_init();
  rtc_set_datetime(dia, mes, anio,  1/*dow*/,  hora, min, seg);

}

/* Inicializa la fecha y hora del sistema */
void rtcInit(void)
{
  uint32_t i=0;
  do{
	Status.ErrRTC = 0;
	RTC_StopTimer(RTC); //para que no joda con la interrupcion
        rtcRead(&Rtc, 1);
  }while(Status.ErrRTC && ++i<5);

  if(Status.ErrRTC)  // Error de formato en datos de Fecha-Hora
  {
        Rtc.Date = 1462;  // 1 de enero de 2005
        Rtc.Time = 0;
        Rtc.Seconds = 0;
 	rtcSet(Rtc);
  }

  cntMalRTC = 0;
  Rtc.CtrlByte = 0;
}

