/*
 * variables1.h
 *
 *  Created on: 2 ago. 2018
 *      Author: Marcelo.Caamaño
 */

#ifndef VARIABLES1_H_
#define VARIABLES1_H_

#include "CPU_def.h"
/* Formatos de paquetes de datos que deben ser interpretados.
 * Cada info que le llega a la CPU o genera ella misma, cumple
 *  con una clara estructura del paquete, ya que en él mismo,
 *  está la info suficiente para ser procesada.
 * Dicha estructura se define a continuación. Se comparten bytes
 *  pero con distintos nombres.
 * Long tiene en su byte low, la cantidad de var de 16 bits deben salvarse.
 * En su byte high, tiene flags de comandos a ejecutar. Estos flags
 *  en ningún caso sobreescriben valores a guardar (ej la hora, fecha, sensor, event, etc)
 *****************************************************************************************/

  __pack Pack;
  __pack PackTemp;
//  __pack PackTempCS;
  __pack Resultados1;
  __pack Resultados2;
  __pack Resultados3;
  __pack Resultados4;
  __pack * Lugar;      // Lugar dentro de los resultados para guardar el pack de datos

  PORTAP __PORTAP_bit;
  //extern  __pack Pack;
  //extern  __pack Resultados1;
  //extern  __pack Resultados2;
  //extern  __pack Resultados3;
  //extern  __pack Resultados4;
  //extern  __pack * Lugar;

/* Variables para el temporizado
 *******************************/
 __Timing Timing;//volatile

/* Variables de estado general
*****************************/
__flags_bits Status;
__Status StatusIO;
uint32_t CntInstantaneo; //Cuenta segundos para el time out de la medicion instantanea

__comparam  Com;

/* Variables para el AD
 **********************/
 uint32_t	OlaActiva;
 __InstAD	InstAD;

 __FlagsAD	FlagsAD;
 __Buffer	Buffer;
 __Tipo Tipo[Digit7]; //TODO van a ser 32 digitales
 __Tipo *TipoPtr;
uint16_t *PtrInstAD;

__variable Variable[32]; //Buffer de lectura escritura de la flash interna
uint16_t *FlashPtr;

uint8_t *PtrUART;

 /* Variables de analisis temporarios de cada canal
  *************************************************/

__Analogico Analogico1;
__Analogico Analogico2;
__Analogico Analogico3;
__Analogico Analogico4;
__Analogico Analogico5;
__Analogico Analogico6;
__Analogico Analogico7;
__Analogico Analogico8;
__Analogico Analogico9;
__Analogico Analogico10;
__Analogico Analogico11;
__Analogico Analogico12;
__Analogico Analogico13;
__Analogico Analogico14;
__Analogico Analogico15;
__Analogico Analogico16;


__Analogico Pluviometro;
__Analogico    *ChPtr;    // Los procesamientos se hacen con este


__SupervD   Digital1;
__SupervD   Digital2;
__SupervD   Digital3;
__SupervD   Digital4;
__SupervD   Digital5;
__SupervD   Digital6;
__SupervD  *DigPtr;

uint32_t PtrResultados;     // Cantidad de byte ocupados en el buffer de resultados

uint32_t CntAlim;              // Cuenta para el oneshoot de alimentacion de sensores
uint8_t CangDeb;

__Hay Hay;
__Hay Invalida;    // Para que no tx todos los eventos invalidos

__canal Llego;      // Para procesar a medida que se desocupa el buffer del uWire TODO ver que es esto!

__BitValid BitValid;       // Bits de validacion del AD y temporario para analisis

__FlagsViento FlagsViento;                         // flags para el manejo del anemometro-veleta


uint16_t Time;      // Se recibe la hora actual para sincronizar todas las RTUs.
//uint32_t Seconds;             // Idem para el segundero



//uint32_t CntAlim;    // Cuenta para el oneshoot de alimentacion de sensores
//uint32_t CntInstantaneo;

uint16_t Page;       // Es el numero de pagina en la flash que esta el canal TODO ver tipo
uint16_t ValorAct;   // Temporario para realizar la matemática en la misma página
uint16_t Diferencia; // Para las derivadas

/* Variables dedicadas a la veleta y el anemómetro
 *************************************************/
uint8_t  Direccion;          // Canal encontrado y seteado como direccion de viento (veleta)
uint8_t Velocidad;          // Canal encontrado y seteado como velocidad de veinto (Anemometro)

__Viento Viento;

__VCB VCB;
__VSB VSB;
__SD  SD;

uint32_t SoftWD;

uint16_t LastDireccion;   // Ultimo promedio vectorial del unico canal vectorial posible.
uint16_t MaxDireccion;    // Direccion registrada en el TRead de maxima vel. Lo set el velocidad del viento
uint16_t MinDireccion;    // Idem para la minima velocidad.

_CfgReg cfgReg, tmpCfg;

uint16_t CntMed;
uint16_t CntVueltas;
uint16_t CntVueltas2;
uint16_t StDireccion;
uint16_t LastDirInter;   // Ultimo promedio vectorial del unico canal vectorial posible.
uint16_t MedAnt;
__FlagsViento FlagsViento;                         // flags para el manejo del anemometro-veleta
__flaggral FlagGral;

__NOINIT_DEF uint32_t PowerOnAA, PowerOn55, PowerOnaa, PowerOnSS; // Para detectar el power on // Para detectar el power on
uint32_t cpuInicio, cntMalIO, cntMalBAT, cntMalRTC, cntMalOrbcomm;

//uint16_t Page;


volatile uint32_t ticTimer; //timer del RTC
volatile uint32_t delay; //para el timer de 1mSeg

// 19 pilas:  {Pila1.PagStart/32, Pila1.PagLong/4}, {Pila2.PagStart/32, Pila2.PagLong/4} ...
const __structformat Format[PILAS] = {{0,320},{320,320},{640,320},{960,320},{1280,320},{1600,320},{1920,320},{2240,320},
        {2560,320},{2880,320},{3200,320},{3520,320},{3840,320},{4160,320},{4480,320},{4800,320},
        {5120,160},{5280,640},{5920,64} };

__agend_struct NextAgend;
__rtc_type Rtc;

__buf_cmd_uart BufUart;
__data_com DataCom;




//punteros finales de escritura
__ptrEnd PtrTxTxed;
__ptrEnd PtrEvTxed;

volatile uint32_t s_sendSize =0;
USB_DMA_NONINIT_DATA_ALIGN(USB_DATA_ALIGN_SIZE) uint8_t s_currSendBuf[512];

//usart_handle_t s_COM1UsartHandler;
//volatile bool txOnGoing, rxOnGoing;


usart_handle_t g_uartHandle;
//usart_dma_handle_t g_uartDmaHandle;
//dma_handle_t g_uartTxDmaHandle;
//dma_handle_t g_uartRxDmaHandle;
uint8_t g_rx_ring_buffer[256] ={0};
//uint8_t g_txBuffer[128] = {0};
uint8_t g_rxBuffer[128] = {0};
//uint8_t c1_txbuffer[64] = {0};
volatile bool rxBufferEmpty = true;
volatile bool txBufferFull = false;
volatile bool txOnGoing = false;
volatile bool rxOnGoing = false;
usart_transfer_t sendXfer;
usart_transfer_t receiveXfer;
uint32_t contadorUART;

wwdt_config_t configWWDT;
rtc_datetime_t dateG;

#endif /* VARIABLES1_H_ */
