/*
 * ChProc1.c
 *
 *  Created on: 6 ago. 2018
 *      Author: Marcelo.Caamaño
 */
#include "CPU_def.h"
//#include "variables1.h"
#include "fsl_gpio.h"

void chAlimentador(void);
void chRdCanal(void);

#define ALIMENTACION_LED_PORT 2U  //TODO ver que pines manejan alimentacion
#define ALIMENTACION_LED_PIN 2U   // P2-2 (D9), P3-3 (D11) and P3-14 (D12).
#define ALIMENTACION1_LED_PORT 3U
#define ALIMENTACION1_LED_PIN 3U



/*
extern  __Analogico Analogico1;
extern  __Analogico Analogico2;
extern  __Analogico Analogico3;
extern  __Analogico Analogico4;
extern  __Analogico Analogico5;
extern  __Analogico Analogico6;
extern  __Analogico Analogico7;
extern  __Analogico Analogico8;
extern  __Analogico Analogico9;
extern  __Analogico Analogicoa;
extern  __Analogico Analogicob;
extern  __Analogico Analogicoc;
extern  __Analogico Analogicod;
extern  __Analogico Analogicoe;
extern  __Analogico Pluviometro;

extern  __SupervD   Digital1;
extern  __SupervD   Digital2;
extern  __SupervD   Digital3;
extern  __SupervD   Digital4;
extern  __SupervD   Digital5;
extern  __SupervD   Digital6;


extern __Timing Timing;
extern __Status Status;
extern  __BitValid BitValid;

extern __Tipo Tipo[Digit7]; //TODO van a ser 32 digitales
extern __Tipo *TipoPtr;

extern __Hay Hay;
extern __Hay Invalida;    // Para que no tx todos los eventos invalidos

extern __canal Llego;

extern  __Buffer Buffer;
extern __InstAD  InstAD;
extern  uint32_t *PtrInstAD;
extern  __Analogico    *ChPtr;
extern  __SupervD      *DigPtr;
extern  __canal    OlaActiva;

extern uint32_t Time;      // Se recibe la hora actual para sincronizar todas las RTUs.
extern uint32_t Seconds;
extern uint32_t CntAlim;
extern uint32_t CntInstantaneo;
extern uint32_t	LastDireccion;

extern uint32_t	CntMed;
extern uint32_t	CntVueltas;
extern uint32_t	CntVueltas2;
extern uint32_t	LastDirInter;   // Ultimo promedio vectorial del unico canal vectorial posible.
extern uint32_t	StDireccion;
extern uint32_t	MedAnt;
extern union{uint32_t  SumaDir;
                    struct{uint16_t DirLo,DirHi;}Suma;
                    }SumaDir;

 extern uint32_t Time;      // Se recibe la hora actual para sincronizar todas las RTUs.

extern void RdPage(uint32_t PageNum);
*/

extern void calcMakeStorageLimni(void);
extern void calcMakeDiscretLimni(void);
extern void calcMakeStorageMete(void);
extern void calcMakeDiscretMete(void);
extern void calcMakeStorageVelo(void);
extern void calcMakeDiscretVelo(void);
extern void calcMakeStoragePluvi(void);
extern void calcMakeDiscretPluvi(void);
extern void calcMakeStorageSDI12(void);
extern void calcMakeDiscretSDI12(void);


extern void calcProcAlLimni(uint8_t Motivo, uint32_t Valor);
extern void calcProcAlSDI12(uint8_t Motivo, uint32_t Valor);
extern void calcProAlMete(uint8_t Motivo, uint32_t Valor);
extern void calcProAlVelo(uint8_t Motivo, uint32_t Valor);
extern void calcProcAlSuperv(uint8_t Motivo, uint32_t Valor);
extern void calcProcTxPluvi(uint8_t Motivo, uint32_t Valor);
extern void calcProcTxLimni(uint8_t Motivo, uint32_t Valor);
extern void calcProcEvValid (uint32_t Valor);
extern void calcProcPluvi0 (void);
extern void calcSavePluvi(void);

extern void calcProcAlDigital(void);
extern void calcProcDgValid(void);


extern void vtoVientoProc(void);
/* Mediciones de cada tipo de canal
 **********************************/
 // Medicion del limni - Segundero
 void chMedLimnimetrico(void)
 {  if ((!ChPtr->Flags.Apagar)&&(ChPtr->Flags.Medir))
    {
            // MODIFICADO !!!
            if(ChPtr->Flags.Ola_Dif && (Page==0))  // Olas solo en canal 0
            {    // Promedia las mediciones realizadas en el segundo
                if(InstAD.CntOlaMed!=0)
                {   ChPtr->TLimnimetrico.SumaMed += (InstAD.CanalOla / InstAD.CntOlaMed);
                    ChPtr->TLimnimetrico.CntMed++;
                    InstAD.CntOlaMed=0;
                }
                InstAD.CanalOla=0;
            }
            else  //  Acumula la medicion de Nivel sin filtrado de Olas
            {   ChPtr->TLimnimetrico.SumaMed += *PtrInstAD;
                ChPtr->TLimnimetrico.CntMed++;
            }
    }
 }

 // Medicion de meteorologico - Segundero
 void chMedMeteorologico(void)
 {  if ((!ChPtr->Flags.Apagar)&&(ChPtr->Flags.Medir))
    {     // Se acumula la ultima medicion
          ChPtr->TMeteorologico.SumaMed += *PtrInstAD;
          ChPtr->TMeteorologico.CntMed++;
    }
 }

 // Medicion de velocidad - Segundero
 void chMedVelocidad(void)
 {  if ((!ChPtr->Flags.Apagar)&&(ChPtr->Flags.Medir))
    {     ChPtr->TVelocidad.SumaMed+=(uint32_t)*PtrInstAD;
          ChPtr->TVelocidad.CntMed++;
    };
 }

 // Medicion del promedio vectorial (direccion de viento)
 // *****************************************************
 void chMedDireccion(void){
	 //TODO ver tipos
    uint16_t Cambio;
    uint16_t MedAct;
    uint32_t Escala;

    if ((!ChPtr->Flags.Apagar)&&(ChPtr->Flags.Medir)){ // Toma la última medicion y la procesa
        Escala=((*PtrInstAD-VCB.VeleCero)*32768)/VSB.VeleSpan;
        MedAct=(uint16_t)Escala;
//        MedAct=*PtrInstAD;
        ChPtr->TDireccion.SumaDir+=MedAct;
        ChPtr->TDireccion.CntMed++;
        if (MedAct>ChPtr->TDireccion.MedAnt)
        {   Cambio = MedAct-ChPtr->TDireccion.MedAnt;
            if (Cambio>=0x8000)ChPtr->TDireccion.CntVueltas++;
        }
        else
        {   Cambio = ChPtr->TDireccion.MedAnt - MedAct;
            if (Cambio>=0x8000)ChPtr->TDireccion.CntVueltas--;
        }
        ChPtr->TDireccion.CntVueltas2+=ChPtr->TDireccion.CntVueltas;
        ChPtr->TDireccion.MedAnt=MedAct;
    }
 }

 // Medicion de la supervision analogica
 void chMedSupervisionAnalog(void)
 {  if ((!ChPtr->Flags.Apagar)&&(ChPtr->Flags.Medir))
    {    ChPtr->TSuperv.SumaMed+=*PtrInstAD;
         ChPtr->TSuperv.CntMed++;
    }
 }


/* Procesa el segundero de todos los canales analógicos
 ******************************************************/
 void chProAllSeg(void){

    chAlimentador();// Enciende las alimentaciones conmutadas, a los 2seg activa "Status.Alimentado"

	 if(StatusIO.Alimentado && !BitValid.MalAD)
	   {  cadConvAll();  // Mediciones Instantaneas en todos los canales: 1..16 + Ola

		  ChPtr=&Analogico1;    // puntero a la estructura del canal
		  PtrInstAD=&InstAD.Canal1; // Apunta al valor instant que tomo cadConvAll()
		  TipoPtr=&Tipo[Canal1];  // Tipo de canal: Limni, Meteo, DirVto, VelVto, SupervAnal
		  chRdCanal();  // Acumula la medicion / incrementa el contador: ...en la estructura apuntada por ChPtr

		  ChPtr=&Analogico2;
		  PtrInstAD=&InstAD.Canal2;
		  TipoPtr=&Tipo[Canal2];
		  chRdCanal();

		  ChPtr=&Analogico3;
		  PtrInstAD=&InstAD.Canal3;
		  TipoPtr=&Tipo[Canal3];
		  chRdCanal();

		  ChPtr=&Analogico4;
		  PtrInstAD=&InstAD.Canal4;
		  TipoPtr=&Tipo[Canal4];
		  chRdCanal();

		  ChPtr=&Analogico5;
		  PtrInstAD=&InstAD.Canal5;
		  TipoPtr=&Tipo[Canal5];
		  chRdCanal();

		  ChPtr=&Analogico6;
		  PtrInstAD=&InstAD.Canal6;
		  TipoPtr=&Tipo[Canal6];
		  chRdCanal();

		  ChPtr=&Analogico7;
		  PtrInstAD=&InstAD.Canal7;
		  TipoPtr=&Tipo[Canal7];
		  chRdCanal();

		  ChPtr=&Analogico8;
		  PtrInstAD=&InstAD.Canal8;
		  TipoPtr=&Tipo[Canal8];
		  chRdCanal();

		  ChPtr=&Analogico9;
		  PtrInstAD=&InstAD.Canal9;
		  TipoPtr=&Tipo[Canal9];
		  chRdCanal();

		  ChPtr=&Analogico10;
		  PtrInstAD=&InstAD.Canal10;
		  TipoPtr=&Tipo[Canal10];
		  chRdCanal();

		  ChPtr=&Analogico11;
		  PtrInstAD=&InstAD.Canal11;
		  TipoPtr=&Tipo[Canal11];
		  chRdCanal();

		  ChPtr=&Analogico12;
		  PtrInstAD=&InstAD.Canal12;
		  TipoPtr=&Tipo[Canal12];
		  chRdCanal();

		  ChPtr=&Analogico13;
		  PtrInstAD=&InstAD.Canal13;
		  TipoPtr=&Tipo[Canal13];
		  chRdCanal();

		  ChPtr=&Analogico14;
		  PtrInstAD=&InstAD.Canal14;
		  TipoPtr=&Tipo[Canal14];
		  chRdCanal();

		  ChPtr=&Analogico15;
		  PtrInstAD=&InstAD.Canal15;
		  TipoPtr=&Tipo[Canal15];
		  chRdCanal();

		  ChPtr=&Analogico16;
		  PtrInstAD=&InstAD.Canal16;
		  TipoPtr=&Tipo[Canal16];
		  chRdCanal();
	   }

 }



 /* Proceso para alimentar los sensores
    Se Invoca en el segundero dentro de ChProAllSeg()
  *************************************/
  void chAlimentador(void){
	 //MAC esto es solo para probar que es invocada!!!
	 /* static uint32_t a=0;

	  if (++a%2)
	  	  {
		  GPIO_PinWrite(GPIO, ALIMENTACION_LED_PORT, ALIMENTACION_LED_PIN, 0);
		  GPIO_PinWrite(GPIO, ALIMENTACION1_LED_PORT, ALIMENTACION1_LED_PIN, 1);
	  	  }
	  else
	  	  {
		  GPIO_PinWrite(GPIO, ALIMENTACION_LED_PORT, ALIMENTACION_LED_PIN, 1);
		  GPIO_PinWrite(GPIO, ALIMENTACION1_LED_PORT, ALIMENTACION1_LED_PIN, 0);
	  	  }
	   fin MAC!*/
     //   TODO ver si estado indica que hay que alimentar y enciende alim

        if (StatusIO.Alimentar) CntAlim++;
        if ((CntAlim >= Calentando) && (!StatusIO.Alimentado))
        {
        // proceso inicial cuando se encienden las alimentaciones de sensor
            cadCalAD();
            StatusIO.Alimentar=0;
            StatusIO.Alimentado=1;
            // Generacion de evento de Error del CAD si corresponde
            if(BitValid.MalAD && !BitValid.EventoAD){
              Resultados1.Ev.Config=Evento;
              Resultados1.Ev.Channel=Event;
              Resultados1.Ev.Bite.CodeHi=0;
              Resultados1.Ev.Bite.CodeLo=ErrCAD;
              Resultados1.Ev.Value1=0;
              Resultados1.Ev.Value2=0;
              StatusIO.Vacio=0;
              StatusIO.Full1=1;
              BitValid.EventoAD=1;
            }
        }
        if( (Analogico1.Flags.Apagar)&&(Analogico2.Flags.Apagar)&&(Analogico3.Flags.Apagar)&&
            (Analogico4.Flags.Apagar)&&(Analogico5.Flags.Apagar)&&(Analogico6.Flags.Apagar)&&
            (Analogico7.Flags.Apagar)&&(Analogico8.Flags.Apagar)&&(Analogico9.Flags.Apagar)&&
            (Analogico10.Flags.Apagar)&&(Analogico11.Flags.Apagar)&&(Analogico12.Flags.Apagar)&&
            (Analogico13.Flags.Apagar)&&(Analogico14.Flags.Apagar)&&(Analogico15.Flags.Apagar)&&
            (Analogico16.Flags.Apagar) )
        {
        	StatusIO.Alimentado=0;
        	StatusIO.Alimentar=0;
        }
        // Temporizado de alimentaciones para Med. Instantaneas
        if (CntInstantaneo != 0)  CntInstantaneo--;
        else {StatusIO.Instantaneo=0;}
        // Encendido o apagado de las alimentaciones conmutadas de sensores
        if ((StatusIO.Alimentar)||(StatusIO.Alimentado)||(StatusIO.Instantaneo))
        {    //__PORTED_bit.Cut2=1;
        	HAB_12V_VSW2_ON;
        	HAB_12V_VSW1_ON; //Ya estaba encendido. Porque lo fijamos para canal de viento (2019-06-11)
         	LED_R_ON;
			if (!StatusIO.Instantaneo)
			{
				Status.Com2On=1; //deshabilito puerto com MAC2020
			}
             //__PORTED_bit.Cut1=1;
        }
        else
        {
            //__PORTED_bit.Cut2=0;
            //__PORTED_bit.Cut1=0;
            HAB_12V_VSW1_OFF;  //20200717 cambio 2 por 1 a pedido de Seba
            if(!Hay.Full){
            	Status.Com2On=0; //habilito puerto com MAC2020
            }
            //HAB_12V_VSW1_OFF;  No lo apaga nunca. Esta dirigido solo al canal de viento
            LED_R_OFF;
            CntAlim=0;
        }

 }


void IniAlimentacion(uint8_t  onoff){
    /* Define the init structure for the output LED pin*/
    gpio_pin_config_t alim_pin_config = {
        kGPIO_DigitalOutput, 0,
    };
    /* Init output LED GPIO. */
    GPIO_PortInit(GPIO, ALIMENTACION_LED_PORT);
    GPIO_PinInit(GPIO, ALIMENTACION_LED_PORT, ALIMENTACION_LED_PIN, &alim_pin_config);
    GPIO_PinWrite(GPIO, ALIMENTACION_LED_PORT, ALIMENTACION_LED_PIN, onoff);
    //GPIO_PortInit(GPIO, 0);

    GPIO_PortInit(GPIO, ALIMENTACION1_LED_PORT);
    GPIO_PinInit(GPIO, ALIMENTACION1_LED_PORT, ALIMENTACION1_LED_PIN, &alim_pin_config);
    GPIO_PinWrite(GPIO, ALIMENTACION1_LED_PORT, ALIMENTACION1_LED_PIN, onoff);

    HAB_12V_VSW2_ON;
    HAB_12V_VSW1_ON;

    HAB_5V_OpAmp_OFF; //para SDI12
    CS_SDI12_txDIS; //habilitada recepción de SDI12
//MAC_LED    LED_R_ON;
}

/* Funcion que set y clr el bit correspondiente del Invalido para luego generar el evento o no
 *********************************************************************************************/
 // Es un buffer de 4 bytes en donde cada bit se corresponde a cada canal.
 // Se set el bit que el dato resulto invalido, y se reset cuando es valido
 void chSetInval(void)
 {   //TODO ver tipos
	 Invalida.Full=Invalida.Full | (1ULL<<Page); }

 void chClrInval(void)
 {   //TODO ver tipos
	 Invalida.Full=Invalida.Full ^ (1ULL<<Page); }

 // Test el bit correspondiente a cada canal para generar el evento o no
 uint8_t chTstInval(void)
 {  //TODO ver tipos
	 if((Invalida.Full ^ (1ULL<<Page))==0)  return 0;
    else return 1;
 }

/* Funcion que set y clr el bit correspondiente del Hay para luego calcular el resultado o no (Cambiada de lugar)
 ********************************************************************************************/
 // Es un buffer de 4 bytes en donde cada bit se corresponde a cada canal.
 // Se set el bit que debe calcularse el resultado
 void chCalcHay(void)
 {
    //TODO ver tipos
    Hay.Full = Hay.Full | (1U <<Page); //Se enciende el marcador de que existe un dato disponible de ese canal
 }

 void chClrHay(void)
 {
	 //TODO ver tipos
    Hay.Full = Hay.Full ^ (1U <<Page); //Se borra el marcador de que existe un dato disponible de ese canal
 }

/* Minutero  de cada tipo de canal
 **********************************/
 // La condicion de medir y apagar significa calcular

 // Minutero del limni
 void chProLimnimetrico(void)
 {
    if((Time % ChPtr->TLimnimetrico.TRead) == 0) // Fin de TRead
    {   ChPtr->Flags.Apagar = 1;  // Comando de Apagar Alimentacion
        ChPtr->Flags.Medir = 0;  // Comando de Parar de Medir
        chCalcHay();    // Flag de Nuevo Dato en Hay.Full, segun Page
    }
    if(((Time+ChPtr->TLimnimetrico.TMed) % ChPtr->TLimnimetrico.TRead) == 0) // Comienzo de Tmed
    {   StatusIO.Alimentar=1;
        ChPtr->Flags.Apagar=0;
        ChPtr->Flags.Medir=1;
    }
 }

 // Minutero de meteorologico
 void chProMeteorologico(void)
 {
    if((Time % ChPtr->TMeteorologico.TRead) == 0) // Fin de TRead
    {   ChPtr->Flags.Apagar = 1;  // Comando de Apagar Alimentacion
        ChPtr->Flags.Medir = 0;  // Comando de Parar de Medir
        chCalcHay();    // Flag de Nuevo Dato en Hay.Full
    }
    if(((Time+ChPtr->TMeteorologico.TMed) % ChPtr->TMeteorologico.TRead) == 0) // Comienzo de Tmed
    {   StatusIO.Alimentar=1;
        ChPtr->Flags.Apagar=0;
        ChPtr->Flags.Medir=1;
    }
 }

 // Minutero de velocidad
 void chProVelocidad(void)
 {
    if((Time % ChPtr->TVelocidad.TRead) == 0)
    {   ChPtr->Flags.Apagar = 1;  // Comando de Apagar Alimentacion
        ChPtr->Flags.Medir = 0;  // Comando de Parar de Medir
        chCalcHay();    // Flag de Nuevo Dato en Hay.Full
    }
    if(((Time+ChPtr->TVelocidad.TMed) % ChPtr->TVelocidad.TRead) == 0) // Comienzo de Tmed
    {   StatusIO.Alimentar=1;
        ChPtr->Flags.Apagar=0;
        ChPtr->Flags.Medir=1;
    }
  }

 // Minutero de direccion de viento
 void chProDireccion(void)
 {
    if((Time % ChPtr->TDireccion.TRead) == 0)
    {   ChPtr->Flags.Apagar = 1;  // Comando de Apagar Alimentacion
        ChPtr->Flags.Medir = 0;  // Comando de Parar de Medir
        chCalcHay();    // Flag de Nuevo Dato en Hay.Full
    }
    if(((Time+ChPtr->TDireccion.TMed) % ChPtr->TDireccion.TRead) == 0) // Comienzo de Tmed
    {   StatusIO.Alimentar=1;
        ChPtr->Flags.Apagar=0;
        ChPtr->Flags.Medir=1;
    }
 }

 // Minutero de la supervision analogica
 void chProSupervisionAnalog(void)
 {
    if((Time % ChPtr->TSuperv.TRead) == 0)
    {   ChPtr->Flags.Apagar = 1;  // Comando de Apagar Alimentacion
        ChPtr->Flags.Medir = 0;  // Comando de Parar de Medir
        chCalcHay();    // Flag de Nuevo Dato en Hay.Full
    }
    if(((Time+ChPtr->TSuperv.TMed) % ChPtr->TSuperv.TRead) == 0) // Comienzo de Tmed
    {   StatusIO.Alimentar=1;
        ChPtr->Flags.Apagar=0;
        ChPtr->Flags.Medir=1;
    }
 }

 // Minutero del pluviometro
 void chProPluviometrico(void)
 {
    if((Time % ChPtr->TPluviometrico.TRead) == 0)
    {   chCalcHay();
    }
    else
    {   ChPtr->Flags.Medir=1;
        ChPtr->Flags.Apagar=1;
    }
 }

 // Minutero del SDI12
 void chProSDI12(void)
 {
    if((Time % ChPtr->TSDI12.TRead) == 0)
    {
    	StatusIO.Alimentar=1; //no hace falta para SDI12, sí para RS485
    	ChPtr->Flags.Medir=1;
    	ChPtr->Flags.Apagar=0;
    	//chCalcHay();  todavía no
    }
    /* en SDI12 la medicion puede tomar bastante tiempo. Se apaga el canal dentro de la rutina de SDI
     * else
    {   ChPtr->Flags.Medir=0;
        ChPtr->Flags.Apagar=1;
    }*/
 }

 // Minutero del digital superv
 void chProDigital(void)
 {  if(DigPtr->Flags.On)
    {
       if((Time % DigPtr->TRead) == 0)  chCalcHay();
    }
 }

/* Proceso minutero de cada canal general
 *****************************************/
 void chProCanal(void)
 {
    if(ChPtr->Flags.On)   // Verifica si el canal esta habilitado
    {  switch (*TipoPtr){  // Buffer.ChStruct.Temporario.Tipo)
        case Limnimetrico:      chProLimnimetrico();
                                break;
        case Meteorologico:     chProMeteorologico();
                                break;
        case VelocidadViento:   chProVelocidad();
                                break;
        case DireccionViento:   chProDireccion();
                                break;
        case SupervAnalog:      chProSupervisionAnalog();
                                break;
        case Pluviometrico:     chProPluviometrico();
                                break;
        case SDI12:
        case RS485:
        						chProSDI12();
                                break;
        default:
        	break;
      }
    }
 }



/* Procesa el minutero de todos los canales analógicos
 ******************************************************/
 void chProAllMin(void){

    Page=0; // Pagina de config de la EA1
    ChPtr=&Analogico1;  // Estructura en RAM para la EA1
    TipoPtr=&Tipo[Canal1]; // Se apunta el arreglo donde se indica el tipo del canal
    chProCanal(); // Se procesa la EA1

    Page=1; // EA2
    ChPtr=&Analogico2;
    TipoPtr=&Tipo[Canal2];
    chProCanal();

    Page=2; // EA3
    ChPtr=&Analogico3;
    TipoPtr=&Tipo[Canal3];
    chProCanal();

    Page=3; // EA4
    ChPtr=&Analogico4;
    TipoPtr=&Tipo[Canal4];
    chProCanal();

    Page=4; // EA5
    ChPtr=&Analogico5;
    TipoPtr=&Tipo[Canal5];
    chProCanal();

    Page=5; // EA6
    ChPtr=&Analogico6;
    TipoPtr=&Tipo[Canal6];
    chProCanal();

    Page=6; // EA7
    ChPtr=&Analogico7;
    TipoPtr=&Tipo[Canal7];
    chProCanal();

    Page=7; // EA8
    ChPtr=&Analogico8;
    TipoPtr=&Tipo[Canal8];
    chProCanal();

    Page=8; // EA9
    ChPtr=&Analogico9;
    TipoPtr=&Tipo[Canal9];
    chProCanal();

    Page=9; // EA10
    ChPtr=&Analogico10;
    TipoPtr=&Tipo[Canal10];
    chProCanal();

    Page=0x0a; // EA11
    ChPtr=&Analogico11;
    TipoPtr=&Tipo[Canal11];
    chProCanal();

    Page=0x0b; // EA12
    ChPtr=&Analogico12;
    TipoPtr=&Tipo[Canal12];
    chProCanal();

    Page=0x0c; // EA13
    ChPtr=&Analogico13;
    TipoPtr=&Tipo[Canal13];
    chProCanal();

    Page=0x0d; // EA14
    ChPtr=&Analogico14;
    TipoPtr=&Tipo[Canal14];
    chProCanal();

    Page=0x15; // EA15
    ChPtr=&Analogico15;
    TipoPtr=&Tipo[Canal15];
    chProCanal();

    Page=0x16; // EA16
    ChPtr=&Analogico16;
    TipoPtr=&Tipo[Canal16];
    chProCanal();

    Page=0x0e; // Pluvi
    ChPtr=&Pluviometro;
    TipoPtr=&Tipo[CanalPluvi];
    chProCanal();

    Page=0x0f; // ED1
    DigPtr=&Digital1;
    TipoPtr=&Tipo[Digit1];
    chProDigital();

    Page=0x10; // ED2
    DigPtr=&Digital2;
    TipoPtr=&Tipo[Digit2];
    chProDigital();

    Page=0x11; // E5
    DigPtr=&Digital3;
    TipoPtr=&Tipo[Digit3];
    chProDigital();

    Page=0x12; // ED6
    DigPtr=&Digital4;
    TipoPtr=&Tipo[Digit4];
    chProDigital();

    Page=0x13; // ED7
    DigPtr=&Digital5;
    TipoPtr=&Tipo[Digit5];
    chProDigital();

    Page=0x14; // ED8
    DigPtr=&Digital6;
    TipoPtr=&Tipo[Digit6];
    chProDigital();
 }


 /* Funcion que sincroniza todos los contadores temporarios de todos los canales a las 24hs.
  ******************************************************************************************/
  void SyncAll(void){
	 //TODO ver si son las 24, extender a todos los canales
	 /*
     if (!__PORTGP_bit.PPD)BitValid.Sync=0;
     else if (!BitValid.Sync){
             Timing.Seconds=0;
             Timing.OlaTag=0;
             Timing.Tag=0;
             BitValid.Reinicio=0;
             IniAnalogicos();
             BitValid.Sync=1;

             Time=1;

             Analogico1.Flags.NoVal=0;
             Analogico2.Flags.NoVal=0;
             Analogico3.Flags.NoVal=0;
             Analogico4.Flags.NoVal=0;
             Analogico5.Flags.NoVal=0;
             Analogico6.Flags.NoVal=0;
             Analogico7.Flags.NoVal=0;
             Analogico8.Flags.NoVal=0;
             Analogico9.Flags.NoVal=0;
             Analogicoa.Flags.NoVal=0;
             Analogicob.Flags.NoVal=0;
             Analogicoc.Flags.NoVal=0;
             Analogicod.Flags.NoVal=0;
             Analogicoe.Flags.NoVal=0;
             Pluviometro.Flags.NoVal=0;
           };
          */
  }


/* Función para inicializar los canales cuando se reinicia o cuando se pone en hora la RTU
*****************************************************************************************/
void chIniEnHora(void){
	     chIniAnalogicos(); // Se lee la pag de config en Flash por cada canal A o D
	                         // Se invoca a chIniCanal o chIniDigit por cada canal A o D
	      Analogico1.Flags.NoVal=0;
	      Analogico2.Flags.NoVal=0;
	      Analogico3.Flags.NoVal=0;
	      Analogico4.Flags.NoVal=0;
	      Analogico5.Flags.NoVal=0;
	      Analogico6.Flags.NoVal=0;
	      Analogico7.Flags.NoVal=0;
	      Analogico8.Flags.NoVal=0;
	      Analogico9.Flags.NoVal=0;
	      Analogico10.Flags.NoVal=0;
	      Analogico11.Flags.NoVal=0;
	      Analogico12.Flags.NoVal=0;
	      Analogico13.Flags.NoVal=0;
	      Analogico14.Flags.NoVal=0;
	      Analogico15.Flags.NoVal=0;
	      Analogico16.Flags.NoVal=0;
	      Pluviometro.Flags.NoVal=0;
 }


/* Función que inicializa todas las variables después del reset
   Previamente se hizo un RdPage, por lo cual toda la estructura se encuentra cargada en "Buffer"
   *chPtr apunta a la estructura del canal en RAM
 **************************************************************/
 // Cuando se inicializa, se suma un TRead para evitar los resultados parciales. Comienza a leer en el próximo TRead.
 void chIniCanal(void){
	   *TipoPtr = Buffer.ChStruct.Tipo;  // Lee de la estructura de Config el "tipo" de canal
	    Buffer.ChStruct.Temporario.Flags = Buffer.ChStruct.Flags; // Lee los flags de la config
	    // MODIFICADO !!!  Se agrega inicializacion de los flags de status
	    Buffer.ChStruct.Temporario.Flags.Medir=0;
	    Buffer.ChStruct.Temporario.Flags.Apagar=1;
	    Buffer.ChStruct.Temporario.Flags.NoVal=0;

	    switch (*TipoPtr){
	        // Carga Buffer.ChStruct.Temporario a partir de procesar los datos de config
	        case Limnimetrico:
	                    Buffer.ChStruct.Temporario.TLimnimetrico.TMed = Buffer.ChStruct.TMed;
	                    Buffer.ChStruct.Temporario.TLimnimetrico.TRead = Buffer.ChStruct.TRead;
	                    Buffer.ChStruct.Temporario.TLimnimetrico.TStorage = Buffer.ChStruct.TStorage * Buffer.ChStruct.TRead;
	                    Buffer.ChStruct.Temporario.TLimnimetrico.TEval = Buffer.ChStruct.TEval * Buffer.ChStruct.Temporario.TLimnimetrico.TStorage;
	                    Buffer.ChStruct.Temporario.TLimnimetrico.TDiscret = Buffer.ChStruct.TDiscret * Buffer.ChStruct.Temporario.TLimnimetrico.TStorage;
	                    // Los demas Cnt en CERO
	                    Buffer.ChStruct.Temporario.TLimnimetrico.CntTResetAlarma = 0;
	                    Buffer.ChStruct.Temporario.TLimnimetrico.CntMed = 0;
	                    Buffer.ChStruct.Temporario.TLimnimetrico.MedAnt = *PtrInstAD;
	                    Buffer.ChStruct.Temporario.TLimnimetrico.MedEvalAnt = *PtrInstAD;
	                    Buffer.ChStruct.Temporario.TLimnimetrico.MedTxAnt = *PtrInstAD;
	                    Buffer.ChStruct.Temporario.TLimnimetrico.SumaMed = 0;
	                    Buffer.ChStruct.Temporario.TLimnimetrico.StorageAnt = 0; // Lo correcto seria leer el ultimo reg en memoria
	                    ChPtr->TLimnimetrico.SumaMed = 0;
	                    ChPtr->TLimnimetrico.CntMed = 0;
	                    break;
	        case Meteorologico: //Idem al Limnimetro, salvo la parte del TEval
	                    Buffer.ChStruct.Temporario.TMeteorologico.TMed = Buffer.ChStruct.TMed;
	                    Buffer.ChStruct.Temporario.TMeteorologico.TRead = Buffer.ChStruct.TRead;
	                    Buffer.ChStruct.Temporario.TMeteorologico.TStorage = Buffer.ChStruct.TStorage * Buffer.ChStruct.TRead;
	                    Buffer.ChStruct.Temporario.TMeteorologico.TDiscret = Buffer.ChStruct.TDiscret * Buffer.ChStruct.Temporario.TMeteorologico.TStorage;
	                    Buffer.ChStruct.Temporario.TMeteorologico.TEval = Buffer.ChStruct.TEval * Buffer.ChStruct.Temporario.TMeteorologico.TStorage;
	                    //En caso de que se quiera evaluar si hay datos almacenados sería éste el lugar para introducir la evaluación
	                    Buffer.ChStruct.Temporario.TMeteorologico.CntTResetAlarma=0;
	                    Buffer.ChStruct.Temporario.TMeteorologico.CntMed=0;
	                    Buffer.ChStruct.Temporario.TMeteorologico.SumaMed=0;
	                    Buffer.ChStruct.Temporario.TMeteorologico.MedMax=0;/// Idem meteorológico Buffer.ChStruct.MinValid;
	                    Buffer.ChStruct.Temporario.TMeteorologico.MedMin=0Xffff; ///Idem meteorológico Buffer.ChStruct.MaxValid;
	                    Buffer.ChStruct.Temporario.TMeteorologico.MedAnt=*PtrInstAD;
	                    Buffer.ChStruct.Temporario.TMeteorologico.SumaStorage=0;
	                    Buffer.ChStruct.Temporario.TMeteorologico.MedMed=0;
	                    ChPtr->TMeteorologico.SumaMed=0;  //Se acumula la medicion instantanea con las anteriores
	                    ChPtr->TMeteorologico.CntMed=0; //Y se incrementa el contador de mediciones instántaneas
	                    break;
	        case VelocidadViento:
	                    Buffer.ChStruct.Temporario.TVelocidad.TMed = Buffer.ChStruct.TMed;
	                    Buffer.ChStruct.Temporario.TVelocidad.TRead = Buffer.ChStruct.TRead;
	                    Buffer.ChStruct.Temporario.TVelocidad.TStorage = Buffer.ChStruct.TStorage * Buffer.ChStruct.TRead;
	                    Buffer.ChStruct.Temporario.TVelocidad.TDiscret = Buffer.ChStruct.TDiscret * Buffer.ChStruct.Temporario.TVelocidad.TStorage;
	                    Buffer.ChStruct.Temporario.TVelocidad.TEval = Buffer.ChStruct.TEval * Buffer.ChStruct.Temporario.TVelocidad.TStorage;

	                    Buffer.ChStruct.Temporario.TVelocidad.CntTResetAlarma=0;
	                    Buffer.ChStruct.Temporario.TVelocidad.CntMed=0;
	                    Buffer.ChStruct.Temporario.TVelocidad.SumaMed=0;
	                    Buffer.ChStruct.Temporario.TVelocidad.MedMax=0; // Idem meteorologico Buffer.ChStruct.MinValid;
	                    Buffer.ChStruct.Temporario.TVelocidad.MedMin=0Xffff; // Idem meteorológico Buffer.ChStruct.MaxValid;
	                    Buffer.ChStruct.Temporario.TVelocidad.MedAnt=*PtrInstAD;
	                    Buffer.ChStruct.Temporario.TVelocidad.SumaStorage=0;
	                    Buffer.ChStruct.Temporario.TVelocidad.MedMed=0;
	                    ChPtr->TVelocidad.SumaMed=0;  // Se acumula la medicion instantanea con las anteriores
	                    ChPtr->TVelocidad.CntMed=0; // Y se incrementa el contador de mediciones instántaneas
	                    break;

	        case DireccionViento: // Idem meteorolégico
	                    Buffer.ChStruct.Temporario.TDireccion.TMed = Buffer.ChStruct.TMed;
	                    Buffer.ChStruct.Temporario.TDireccion.TRead = Buffer.ChStruct.TRead;
	                    Buffer.ChStruct.Temporario.TDireccion.TStorage = Buffer.ChStruct.TStorage * Buffer.ChStruct.TRead;
	                    Buffer.ChStruct.Temporario.TDireccion.TDiscret = Buffer.ChStruct.TDiscret * Buffer.ChStruct.Temporario.TDireccion.TStorage;

	                    Buffer.ChStruct.Temporario.TDireccion.SumaStorage=0;
	                    Buffer.ChStruct.Temporario.TDireccion.MedMed=0;
	                    Buffer.ChStruct.Temporario.TDireccion.CntMed=0;
	                    Buffer.ChStruct.Temporario.TDireccion.MedAnt=*PtrInstAD;
	                    LastDireccion=Buffer.ChStruct.Temporario.TDireccion.MedAnt;
	                    Buffer.ChStruct.Temporario.TDireccion.CntVueltas=0;
	                    Buffer.ChStruct.Temporario.TDireccion.CntVueltas2=0;
	                    Buffer.ChStruct.Temporario.TDireccion.SumaDir=0;
	                    SD.SumaDir=0ull;
	                    CntMed=0;
	                    CntVueltas=0;
	                    CntVueltas2=0;
	                    break;

	        case SupervAnalog:  ///Idem meteorológico
	                    Buffer.ChStruct.Temporario.TSuperv.TMed = Buffer.ChStruct.TMed;
	                    Buffer.ChStruct.Temporario.TSuperv.TRead = Buffer.ChStruct.TRead;
	                    Buffer.ChStruct.Temporario.TSuperv.TEval = Buffer.ChStruct.TEval * Buffer.ChStruct.TRead;
	                    Buffer.ChStruct.Temporario.TSuperv.CntMed=0;
	                    Buffer.ChStruct.Temporario.TSuperv.SumaMed=0;
	                    Buffer.ChStruct.Temporario.TSuperv.CntTResetAlarma=0;
	                    break;
	        case Pluviometrico:
	                    Buffer.ChStruct.Temporario.TPluviometrico.TRead = Buffer.ChStruct.TRead;
	                    Buffer.ChStruct.Temporario.TPluviometrico.TStorage = Buffer.ChStruct.TStorage * Buffer.ChStruct.TRead;
	                    Buffer.ChStruct.Temporario.TPluviometrico.TDiscret = Buffer.ChStruct.TDiscret * Buffer.ChStruct.Temporario.TPluviometrico.TStorage;
	                    Buffer.ChStruct.Temporario.TPluviometrico.TCero = Buffer.ChStruct.TCero * Buffer.ChStruct.Temporario.TPluviometrico.TDiscret;

	                    Buffer.ChStruct.Temporario.TPluviometrico.VuelcosAnt=InstAD.Cangilones;
	                    Buffer.ChStruct.Temporario.TPluviometrico.StorageAnt=InstAD.Cangilones;

	                    Buffer.ChStruct.Temporario.TPluviometrico.CntTResetAlarma=0;

	                    break;
            case SDI12:
            case RS485:
                        Buffer.ChStruct.Temporario.TSDI12.SDI12_Add =  Buffer.ChStruct.TMed;
                        Buffer.ChStruct.Temporario.TSDI12.TRead = Buffer.ChStruct.TRead;
                        Buffer.ChStruct.Temporario.TSDI12.TEval = Buffer.ChStruct.TEval * Buffer.ChStruct.TRead;
                        //Buffer.ChStruct.Temporario.TSDI12.TStorage = Buffer.ChStruct.Temporario.TSDI12.TRead ;
                        Buffer.ChStruct.Temporario.TSDI12.TDiscret = Buffer.ChStruct.TDiscret *  Buffer.ChStruct.TRead;
                        Buffer.ChStruct.Temporario.TSDI12.SDI12comandoMed1 =  (uint8_t) (Buffer.ChStruct.TStorage / 256);
                        Buffer.ChStruct.Temporario.TSDI12.SDI12comandoMed2 =  (uint8_t) (Buffer.ChStruct.TStorage % 256);
                        Buffer.ChStruct.Temporario.TSDI12.SDI12comandoDat1 =  (uint8_t) (Buffer.ChStruct.TCero / 256);
                        Buffer.ChStruct.Temporario.TSDI12.SDI12comandoDatPos = (uint8_t) (Buffer.ChStruct.TCero % 256);
                        
                        //TODO ver que necesito de esto
                        Buffer.ChStruct.Temporario.TSDI12.CntTResetAlarma=0;
	                    Buffer.ChStruct.Temporario.TSDI12.CntMed=0;
	                    Buffer.ChStruct.Temporario.TSDI12.SumaMed=0;
	                    Buffer.ChStruct.Temporario.TSDI12.MedAnt=*PtrInstAD;
	                    Buffer.ChStruct.Temporario.TSDI12.SumaStorage=0;
                        break;
	    };

	    // Carga la estructura en RAM del canal con los datos procesados a partir de la config y "Time"
	    *ChPtr = Buffer.ChStruct.Temporario;
 }

/* Proceso segundero de cada canal general
 *****************************************/
  void chRdCanal(void){
  // chPtr: puntero a la Struct del canal -> analogico1 .. analogico16
  // PtrInstAD: valor instantaneo del canal
  // TipoPtr: tipo de canal, determina el procesamiento a realizar

    switch (*TipoPtr){
        case Limnimetrico:
             chMedLimnimetrico();
             break;

        case Meteorologico:
             chMedMeteorologico();
             break;

        case VelocidadViento:
             chMedVelocidad();
             break;

        case DireccionViento:
             chMedDireccion();
             break;

        case SupervAnalog:
             chMedSupervisionAnalog();
             break;
        //el SDI12 no entra en este bucle
    };
  }

/* Función que inicializa todas las variables después del reset
 **************************************************************/
 void chIniDigit(void){
	 //TODO ver que hace esto!
	    *TipoPtr=Buffer.ChStruct.Tipo;
	    Buffer.ChStruct.Temporario.TSupervDigital.Flags = Buffer.ChStruct.Flags;
	    Buffer.ChStruct.Temporario.TSupervDigital.TRead = Buffer.ChStruct.TRead;
	    Buffer.ChStruct.Temporario.TSupervDigital.CntTResetAlarma=0;
	    *DigPtr=Buffer.ChStruct.Temporario.TSupervDigital;
 }

 /* Inicia todos los canales analógicos
   si BitValid.Syn == 0 -> sincronizacion de las 0hs -> solo lo hace sobre aquellos canales con Tread divisor de 1440
  *************************************/
 void chIniAnalogicos (void){
	 IN_1_OFF; //me aseguro que canal 9 no tenga tension a la salida

    StatusIO.Alimentar=0;
    StatusIO.Alimentado=0;
    CntAlim=0;
    CntInstantaneo=0;

       Hay.Full=0;  // Borra Flags de Nuevo dato por Tmed en todos los canales (32 bits)
       Llego=Canal1;
       InstAD.CanalOla=0;
       InstAD.CntOlaMed=0;

       ChPtr = &Analogico1;  // Ptr a str con Flags, Contadores de Tiempos, Valores Temporales Anteriores
       PtrInstAD = &InstAD.Canal1; // El valor "Inst" se guarda en un campo de la str: ...MedAnt
       TipoPtr = &Tipo[Canal1];  // en chIniCanal carga el "Tipo" desde la estructura leida de Flash
       Page=0;
       lowRdPage(0);  // Lee el config de flash
       // Toma los valores de la estructura de config y los valores actuales de tiempo: "Time"
       // procesa los valores y actualiza la estructura "Analogico1" apuntada por ChPtr
       chIniCanal();
       // MODIFICADO !!!  Se evaluaba Ola_Dif antes de leer la config !!!
       if (ChPtr->Flags.Ola_Dif) OlaActiva = 1;
       else  OlaActiva = 0;

       ChPtr=&Analogico2;
       PtrInstAD=&InstAD.Canal2;
       TipoPtr=&Tipo[Canal2];
       Page=1;
       lowRdPage(1);          // Lee el config de flash
       chIniCanal();

       ChPtr=&Analogico3;
       PtrInstAD=&InstAD.Canal3;
       TipoPtr=&Tipo[Canal3];
       Page=2;
       lowRdPage(2);          // Lee el config de flash
       chIniCanal();

       ChPtr=&Analogico4;
       PtrInstAD=&InstAD.Canal4;
       TipoPtr=&Tipo[Canal4];
       Page=3;
       lowRdPage(3);          // Lee el config de flash
       chIniCanal();

       ChPtr=&Analogico5;
       PtrInstAD=&InstAD.Canal5;
       TipoPtr=&Tipo[Canal5];
       Page=4;
       lowRdPage(4);          // Lee el config de flash
       chIniCanal();

       ChPtr=&Analogico6;
       PtrInstAD=&InstAD.Canal6;
       TipoPtr=&Tipo[Canal6];
       Page=5;
       lowRdPage(5);          // Lee el config de flash
       chIniCanal();

       ChPtr=&Analogico7;
       PtrInstAD=&InstAD.Canal7;
       TipoPtr=&Tipo[Canal7];
       Page=6;
       lowRdPage(6);          // Lee el config de flash
       chIniCanal();

       ChPtr=&Analogico8;
       PtrInstAD=&InstAD.Canal8;
       TipoPtr=&Tipo[Canal8];
       Page=7;
       lowRdPage(7);          // Lee el config de flash
       chIniCanal();

       ChPtr=&Analogico9;
       PtrInstAD=&InstAD.Canal9;
       TipoPtr=&Tipo[Canal9];
       Page=8;
       lowRdPage(8);          // Lee el config de flash
       chIniCanal();

       ChPtr=&Analogico10;
       PtrInstAD=&InstAD.Canal10;
       TipoPtr=&Tipo[Canal10];
       Page=9;
       lowRdPage(9);          // Lee el config de flash
       chIniCanal();

       ChPtr=&Analogico11;
       PtrInstAD=&InstAD.Canal11;
       TipoPtr=&Tipo[Canal11];
       Page=0xA;
       lowRdPage(0xa);          // Lee el config de flash
       chIniCanal();

       ChPtr=&Analogico12;
       PtrInstAD=&InstAD.Canal12;
       TipoPtr=&Tipo[Canal12];
       Page=0xB;
       lowRdPage(0xb);          // Lee el config de flash
       chIniCanal();

       ChPtr=&Analogico13;
       PtrInstAD=&InstAD.Canal13;
       TipoPtr=&Tipo[Canal13];
       Page=0xC;
       lowRdPage(0xc);          // Lee el config de flash
       chIniCanal();

       ChPtr=&Analogico14;
       PtrInstAD=&InstAD.Canal14;
       TipoPtr=&Tipo[Canal14];
       Page=0xD;
       lowRdPage(0xd);          // Lee el config de flash
       chIniCanal();

       ChPtr=&Analogico15;
       PtrInstAD=&InstAD.Canal15;
       TipoPtr=&Tipo[Canal15];
       Page=0x15;
       lowRdPage(0x15);          // Lee el config de flash
       chIniCanal();

       ChPtr=&Analogico16;
       PtrInstAD=&InstAD.Canal16;
       TipoPtr=&Tipo[Canal16];
       Page=0x16;
       lowRdPage(0x16);          // Lee el config de flash
       chIniCanal();

       ChPtr=&Pluviometro;
       PtrInstAD=&InstAD.Cangilones;
       TipoPtr=&Tipo[CanalPluvi];
       Page=0xE;
       lowRdPage(0xe);          // Lee el config de flash
       chIniCanal();

       DigPtr=&Digital1;
       TipoPtr=&Tipo[Digit1];
       Page=0xF;
       lowRdPage(0xf);          // Lee el config de flash
       chIniDigit();

       DigPtr=&Digital2;
       TipoPtr=&Tipo[Digit2];
       Page=0x10;
       lowRdPage(0x10);          // Lee el config de flash
       chIniDigit();

       DigPtr=&Digital3;
       TipoPtr=&Tipo[Digit3];
       Page=0x11;
       lowRdPage(0x11);          // Lee el config de flash
       chIniDigit();

       DigPtr=&Digital4;
       TipoPtr=&Tipo[Digit4];
       Page=0x12;
       lowRdPage(0x12);          // Lee el config de flash
       chIniDigit();

       DigPtr=&Digital5;
       TipoPtr=&Tipo[Digit5];
       Page=0x13;
       lowRdPage(0x13);          // Lee el config de flash
       chIniDigit();

       DigPtr=&Digital6;
       TipoPtr=&Tipo[Digit6];
       Page=0x14;
       lowRdPage(0x14);          // Lee el config de flash
       chIniDigit();

 }

 /* Procesa el TRead del Canal Limnimetrico
       VARIABLES GLOBALES PREVIO A LA INVOCACION DE ESTA FUNCION
          Page = X
          ChPtr = &AnalogicoX;
          PtrInstAD = &InstAD.CanalX;
          TipoPtr = &Tipo[CanalX];
  *********************************************************/
  void chCalLimnimetrico(void)
  {
     uint8_t regDif=0;
     lowRdPage(Page);    // Lee Pag de Config
     Buffer.ChStruct.Temporario = *ChPtr; // Estructura __Analogico correspondiente
     Buffer.ChStruct.Temporario.Flags.On = Buffer.ChStruct.Flags.On;
     Buffer.ChStruct.Temporario.Flags.Ola_Dif = Buffer.ChStruct.Flags.Ola_Dif;
     *TipoPtr = Buffer.ChStruct.Tipo;

     // Verifica Ola Activa
     if(Page==0)
     {   if(Buffer.ChStruct.Flags.Ola_Dif)   OlaActiva = 1;
         else                                OlaActiva = 0;
     }

     // Mientras CntTResetAlarma sea !=0 inhibe la generacion de un Evento de Alarma
     if(Buffer.ChStruct.Temporario.TLimnimetrico.CntTResetAlarma!=0)
               Buffer.ChStruct.Temporario.TLimnimetrico.CntTResetAlarma--;

     // ******** Obtención del Promedio en TMed -> ValorAct *************
     if(Buffer.ChStruct.Temporario.TLimnimetrico.CntMed == 0) return;  // NO HAY DATOS ...
     ValorAct = Buffer.ChStruct.Temporario.TLimnimetrico.SumaMed / Buffer.ChStruct.Temporario.TLimnimetrico.CntMed;
     Buffer.ChStruct.Temporario.TLimnimetrico.SumaMed=0;
     Buffer.ChStruct.Temporario.TLimnimetrico.CntMed=0;
     // *************** Validación del DATO por Umbrales *****************
     Buffer.ChStruct.Temporario.Flags.NoVal = 0;
     if(ValorAct > Buffer.ChStruct.MaxValid) Buffer.ChStruct.Temporario.Flags.NoVal=1; // Validacion por ALTA
     if(ValorAct < Buffer.ChStruct.MinValid) Buffer.ChStruct.Temporario.Flags.NoVal=1; // Validacion por BAJA
     // *************** Validación del DATO por Pendientes *****************
     if(Page == 0) // Nuevo Cond
     {
       if(ValorAct >= Buffer.ChStruct.Temporario.TLimnimetrico.MedAnt) // Validacion por Pendiente(+)
       {   Diferencia = ValorAct - Buffer.ChStruct.Temporario.TLimnimetrico.MedAnt;
           if(Diferencia >= Buffer.ChStruct.MaxSubidaValid) Buffer.ChStruct.Temporario.Flags.NoVal=1;
       }
       else    // Validacion por Pendiente(-)
       {   Diferencia = Buffer.ChStruct.Temporario.TLimnimetrico.MedAnt - ValorAct;
           if (Diferencia >= Buffer.ChStruct.MaxBajadaValid) Buffer.ChStruct.Temporario.Flags.NoVal=1;
       }
     }

     if(Buffer.ChStruct.Temporario.Flags.NoVal)
     {   // Evento por dato No Valido
         if(Buffer.ChStruct.Temporario.TLimnimetrico.CntTResetAlarma==0) calcProcEvValid(ValorAct);
         Buffer.ChStruct.Temporario.TLimnimetrico.CntTResetAlarma = Buffer.ChStruct.TResetAlarma;
     }
     else// Calculos sujetos a validez del dato
     {   // ************** Proceso modo diferencial **********************
         if(Buffer.ChStruct.Flags.Red_Dif)
         {
           if(ValorAct >= Buffer.ChStruct.Temporario.TLimnimetrico.StorageAnt)
                     Diferencia = ValorAct - Buffer.ChStruct.Temporario.TLimnimetrico.StorageAnt;
           else      Diferencia = Buffer.ChStruct.Temporario.TLimnimetrico.StorageAnt - ValorAct;
           // ******* Registro por diferencia *********
           if(Diferencia >= Buffer.ChStruct.MaxSubidaTx)
           {
               // Pongo dato en pila del canal y pila de Tx
               calcMakeDiscretLimni(); // Almacena ValorAct
               regDif=1;
               // Guardo valor del ultimo registro/envio
               Buffer.ChStruct.Temporario.TLimnimetrico.StorageAnt = ValorAct;
           }
         }
     }
     Buffer.ChStruct.Temporario.TLimnimetrico.MedAnt = ValorAct;

     // *************** Proceso del TStorage ***************************
     if((Time % Buffer.ChStruct.Temporario.TLimnimetrico.TStorage) == 0)
     { // Si no esta operando en modo diferencial toma 1 registro
       if(!Buffer.ChStruct.Flags.Red_Dif)  calcMakeStorageLimni();

       // **************** Proceso del TDiscret ************************
       if((Time % Buffer.ChStruct.Temporario.TLimnimetrico.TDiscret) == 0)
       {
           // No invocarlo cuando se genera el registro diferencial en ese Tread
           if(!regDif)
           {   calcMakeDiscretLimni(); // Almacena ValorAct
               Buffer.ChStruct.Temporario.TLimnimetrico.StorageAnt = ValorAct;
           }
           // Evento por Variacion respecto de la ultima Tx: si es dato valido y no es modo diferencial
           if((Page==0) && (!Buffer.ChStruct.Flags.Red_Dif) && (!Buffer.ChStruct.Temporario.Flags.NoVal))
           {
             if(ValorAct >= Buffer.ChStruct.Temporario.TLimnimetrico.MedTxAnt)
             {   Diferencia = ValorAct-Buffer.ChStruct.Temporario.TLimnimetrico.MedTxAnt;
                 if(Diferencia >= Buffer.ChStruct.MaxSubidaTx) calcProcTxLimni(TxAscLimni,Diferencia); // Evento
             }
             else
             {   Diferencia = Buffer.ChStruct.Temporario.TLimnimetrico.MedTxAnt-ValorAct;
                 if(Diferencia >= Buffer.ChStruct.MaxBajadaTx) calcProcTxLimni(TxDesLimni,Diferencia); // Evento
             }
             Buffer.ChStruct.Temporario.TLimnimetrico.MedTxAnt = ValorAct;
           }
       }
       // ********************** Proceso del TEval **********************
       if((Time % Buffer.ChStruct.Temporario.TLimnimetrico.TEval) == 0)
       {
           // Evaluación de la alarma. Siempre y cuando sea un valor valido y la Alarma este activada
           if ((!Buffer.ChStruct.Temporario.Flags.NoVal) && (Buffer.ChStruct.Flags.AlarmaOn))
           {
               // Alarmas de Alta y Baja
               if (ValorAct >= Buffer.ChStruct.AlarmaMax) calcProcAlLimni(AlMaxLimni,ValorAct);
               if (ValorAct <= Buffer.ChStruct.AlarmaMin) calcProcAlLimni(AlMinLimni,ValorAct);
               // Alarmas Ascendente y Descendente
               if((Page==0) && (!Buffer.ChStruct.Flags.Red_Dif))
               {
                 if (ValorAct >= Buffer.ChStruct.Temporario.TLimnimetrico.MedEvalAnt)
                 {   Diferencia = ValorAct - Buffer.ChStruct.Temporario.TLimnimetrico.MedEvalAnt;
                     if (Diferencia >= Buffer.ChStruct.AlarmaSubida) calcProcAlLimni(AlAscLimni,Diferencia);
                 }
                 else
                 {   Diferencia = Buffer.ChStruct.Temporario.TLimnimetrico.MedEvalAnt - ValorAct;
                     if (Diferencia>=Buffer.ChStruct.AlarmaBajada) calcProcAlLimni(AlDesLimni,Diferencia);
                 }
               }
           }
           Buffer.ChStruct.Temporario.TLimnimetrico.MedEvalAnt = ValorAct;//Se guarda el valor como anterior
       }
     }
     // Agregado por GGB
     Buffer.ChStruct.Temporario.TLimnimetrico.TMed = Buffer.ChStruct.TMed;
     Buffer.ChStruct.Temporario.TLimnimetrico.TRead = Buffer.ChStruct.TRead;
     Buffer.ChStruct.Temporario.TLimnimetrico.TStorage = Buffer.ChStruct.TStorage * Buffer.ChStruct.TRead;
     Buffer.ChStruct.Temporario.TLimnimetrico.TEval = Buffer.ChStruct.TEval * Buffer.ChStruct.Temporario.TLimnimetrico.TStorage;
     Buffer.ChStruct.Temporario.TLimnimetrico.TDiscret = Buffer.ChStruct.TDiscret * Buffer.ChStruct.Temporario.TLimnimetrico.TStorage;
     // ... Fin Agregado
     *ChPtr = Buffer.ChStruct.Temporario;  //Una vez que se ha cambiado los campos, se devuelve el cambiado
  }


 /*  Procesa el TRead del Canal Meteorologico
  ********************************************/
  void chCalMeteorologico(void)
  {
     uint8_t regDif=0;
     lowRdPage(Page);
     *TipoPtr=Buffer.ChStruct.Tipo;
     Buffer.ChStruct.Temporario = *ChPtr; // Almacena la Struct AnalogicoXX en Temporario
     Buffer.ChStruct.Temporario.Flags.On = Buffer.ChStruct.Flags.On; // Flag de encendido, pasa de flash a struct en RAM

     // Mientras CntTResetAlarma sea !=0 inhibe la generacion de un Evento de Alarma
     if (Buffer.ChStruct.Temporario.TMeteorologico.CntTResetAlarma != 0)
               Buffer.ChStruct.Temporario.TMeteorologico.CntTResetAlarma--;

     // ******** Obtención del Promedio en TMed *************
     if(Buffer.ChStruct.Temporario.TMeteorologico.CntMed == 0) return;   // NO HAY DATOS ...
     ValorAct = Buffer.ChStruct.Temporario.TMeteorologico.SumaMed / Buffer.ChStruct.Temporario.TMeteorologico.CntMed;
     Buffer.ChStruct.Temporario.TMeteorologico.SumaMed = 0;
     Buffer.ChStruct.Temporario.TMeteorologico.CntMed = 0;

     // *************** Validación del DATO *****************
     Buffer.ChStruct.Temporario.Flags.NoVal = 0;
     if (ValorAct > Buffer.ChStruct.MaxValid)  Buffer.ChStruct.Temporario.Flags.NoVal = 1;
     if (ValorAct < Buffer.ChStruct.MinValid)  Buffer.ChStruct.Temporario.Flags.NoVal = 1;
     if (Buffer.ChStruct.Temporario.Flags.NoVal)
     { // Evento por dato no valido
       if (Buffer.ChStruct.Temporario.TMeteorologico.CntTResetAlarma==0)  calcProcEvValid(ValorAct);
       Buffer.ChStruct.Temporario.TMeteorologico.CntTResetAlarma = Buffer.ChStruct.TResetAlarma;
     }
     else // Calculos sujetos a validez del dato
     {   // ************ Calculo de MAXIMOs y MINIMOs **********************
         if (Buffer.ChStruct.Temporario.TMeteorologico.MedMax < ValorAct)
                   Buffer.ChStruct.Temporario.TMeteorologico.MedMax = ValorAct;
         if (Buffer.ChStruct.Temporario.TMeteorologico.MedMin > ValorAct)
                   Buffer.ChStruct.Temporario.TMeteorologico.MedMin = ValorAct;
         // ************* Proceso Registro Diferencial **********************
         if(Buffer.ChStruct.Flags.Red_Dif)
         {
           if(ValorAct >= Buffer.ChStruct.Temporario.TMeteorologico.MedMed)
                     Diferencia = ValorAct - Buffer.ChStruct.Temporario.TMeteorologico.MedMed;
           else      Diferencia = Buffer.ChStruct.Temporario.TMeteorologico.MedMed - ValorAct;
           // ******* Registro por diferencia *********
           if(Diferencia >= Buffer.ChStruct.MaxSubidaTx)
           {
               // Guardo valor del dato a registrar
               Buffer.ChStruct.Temporario.TMeteorologico.MedMed = ValorAct;
               // Pongo dato en pila del canal y pila de Tx
               calcMakeDiscretMete();
               regDif=1;
           }
         }
     }

     // Acumulado en los Tread para promediacion en Tstorage
     if(!Buffer.ChStruct.Flags.Red_Dif) Buffer.ChStruct.Temporario.TMeteorologico.SumaStorage += ValorAct;

     // ******************* Proceso del TStorage ************************
     if((Time % Buffer.ChStruct.Temporario.TMeteorologico.TStorage) == 0)
     {
         if(!Buffer.ChStruct.Flags.Red_Dif)
         { // Calcula Valor Medio en Tstorage
           Buffer.ChStruct.Temporario.TMeteorologico.MedMed = Buffer.ChStruct.Temporario.TMeteorologico.SumaStorage/Buffer.ChStruct.TStorage;
           // Esto corrige incoherencias en los datos
           // En el primer registro no se suman todos los Tread y al promediar MedMed divide por la cantidad teorica
           // Tb puede ser que se hayan sumado valores no validos
           if( (Buffer.ChStruct.Temporario.TMeteorologico.MedMed < Buffer.ChStruct.Temporario.TMeteorologico.MedMin)
               || (Buffer.ChStruct.Temporario.TMeteorologico.MedMed > Buffer.ChStruct.Temporario.TMeteorologico.MedMax))
           {
               if(Buffer.ChStruct.Temporario.TMeteorologico.MedMax >= Buffer.ChStruct.Temporario.TMeteorologico.MedMin)
               {
                   Buffer.ChStruct.Temporario.TMeteorologico.MedMed =
                       (Buffer.ChStruct.Temporario.TMeteorologico.MedMin>>1)+(Buffer.ChStruct.Temporario.TMeteorologico.MedMax>>1);
               }
               else
               {   Buffer.ChStruct.Temporario.TMeteorologico.MedMed = ValorAct;
                   Buffer.ChStruct.Temporario.TMeteorologico.MedMin = ValorAct;
                   Buffer.ChStruct.Temporario.TMeteorologico.MedMax = ValorAct;
               }
           }
           // registra Buffer.ChStruct.Temporario.TMeteorologico.MedMed
           calcMakeStorageMete();
         }
         // ************* Proceso del TDiscret ***************************
         if((Time % Buffer.ChStruct.Temporario.TMeteorologico.TDiscret) == 0)
         {    if(!regDif)
             {   Buffer.ChStruct.Temporario.TMeteorologico.MedMed = ValorAct;
                 calcMakeDiscretMete();    // pone Bit.TxToo en "1"
                 regDif=1;
             }
         }
         // ***************** Proceso TEval ****************************
         // siempre y cuando el dato sea valido y el flag de Alarma este On
         if((Time % Buffer.ChStruct.Temporario.TMeteorologico.TEval)==0)
         {
           if((!Buffer.ChStruct.Temporario.Flags.NoVal) && (Buffer.ChStruct.Flags.AlarmaOn))
           {
             // Alarmas de Alta y Baja
             if(Buffer.ChStruct.Temporario.TMeteorologico.MedMed >= Buffer.ChStruct.AlarmaMax)
                 calcProAlMete(AlMax, Buffer.ChStruct.Temporario.TMeteorologico.MedMed);
             if(Buffer.ChStruct.Temporario.TMeteorologico.MedMed <= Buffer.ChStruct.AlarmaMin)
                 calcProAlMete(AlMin, Buffer.ChStruct.Temporario.TMeteorologico.MedMed);
             // Alarmas Ascendente y Descendente
             if(!Buffer.ChStruct.Flags.Red_Dif)
             {   if(Buffer.ChStruct.Temporario.TMeteorologico.MedMed > Buffer.ChStruct.Temporario.TMeteorologico.MedAnt)
                 {   Diferencia = Buffer.ChStruct.Temporario.TMeteorologico.MedMed-Buffer.ChStruct.Temporario.TMeteorologico.MedAnt;
                     if(Diferencia >= Buffer.ChStruct.AlarmaSubida) calcProAlMete(AlAsc,Diferencia);
                 }
                 else
                 {   Diferencia = Buffer.ChStruct.Temporario.TMeteorologico.MedAnt-Buffer.ChStruct.Temporario.TMeteorologico.MedMed;
                     if(Diferencia >= Buffer.ChStruct.AlarmaBajada) calcProAlMete(AlDes,Diferencia);
                 }
                 Buffer.ChStruct.Temporario.TMeteorologico.MedAnt = Buffer.ChStruct.Temporario.TMeteorologico.MedMed;
             }
             // Alarmas de Pico Max y Min
             if (Buffer.ChStruct.Temporario.TMeteorologico.MedMax >= Buffer.ChStruct.AlarmaMaxPico)
                 calcProAlMete(AlPkMax,Buffer.ChStruct.Temporario.TMeteorologico.MedMax);
             if (Buffer.ChStruct.Temporario.TMeteorologico.MedMin <= Buffer.ChStruct.AlarmaMinPico)
                 calcProAlMete(AlPkMin,Buffer.ChStruct.Temporario.TMeteorologico.MedMin);
           }
         }
         // Puesta a cero p/calculos de Max, Min y Medio
         if(!Buffer.ChStruct.Flags.Red_Dif || regDif)
         { Buffer.ChStruct.Temporario.TMeteorologico.MedMax = 0;
           Buffer.ChStruct.Temporario.TMeteorologico.MedMin = 0xffff;
           Buffer.ChStruct.Temporario.TMeteorologico.SumaStorage = 0;
         }
     }

     // Agregado por GGB
     Buffer.ChStruct.Temporario.TMeteorologico.TMed = Buffer.ChStruct.TMed;
     Buffer.ChStruct.Temporario.TMeteorologico.TRead = Buffer.ChStruct.TRead;
     Buffer.ChStruct.Temporario.TMeteorologico.TStorage = Buffer.ChStruct.TStorage * Buffer.ChStruct.TRead;
     Buffer.ChStruct.Temporario.TMeteorologico.TEval = Buffer.ChStruct.TEval * Buffer.ChStruct.Temporario.TMeteorologico.TStorage;
     Buffer.ChStruct.Temporario.TMeteorologico.TDiscret = Buffer.ChStruct.TDiscret * Buffer.ChStruct.Temporario.TMeteorologico.TStorage;
     // ... Fin Agregado
     *ChPtr=Buffer.ChStruct.Temporario;
  }

 /*  Procesa el TRead del Canal de Velocidad de Viento
  ***************************************************/
  void chCalVelocidad(void)
  {
     lowRdPage(Page);
     Buffer.ChStruct.Temporario=*ChPtr;
     Buffer.ChStruct.Temporario.Flags.On = Buffer.ChStruct.Flags.On;
     *TipoPtr=Buffer.ChStruct.Tipo;

     // Mientras CntTResetAlarma sea !=0 inhibe la generacion de un Evento de Alarma
     if (Buffer.ChStruct.Temporario.TVelocidad.CntTResetAlarma!=0)
               Buffer.ChStruct.Temporario.TVelocidad.CntTResetAlarma--;

     // ************ Calculo del Promedio en TRead **************
     if(Buffer.ChStruct.Temporario.TVelocidad.CntMed == 0) return;   // NO HAY DATOS ...
     ValorAct = (uint16_t)(Buffer.ChStruct.Temporario.TVelocidad.SumaMed / (uint32_t)Buffer.ChStruct.Temporario.TVelocidad.CntMed);
     Buffer.ChStruct.Temporario.TVelocidad.SumaMed = 0;
     Buffer.ChStruct.Temporario.TVelocidad.CntMed = 0;

     // Evaluación de validez.
     Buffer.ChStruct.Temporario.Flags.NoVal=0;
     if (ValorAct > Buffer.ChStruct.MaxValid)  Buffer.ChStruct.Temporario.Flags.NoVal=1;
     if (ValorAct < Buffer.ChStruct.MinValid)  Buffer.ChStruct.Temporario.Flags.NoVal=1;
     if (Buffer.ChStruct.Temporario.Flags.NoVal)
     { // Evento por dato no valido
       if (Buffer.ChStruct.Temporario.TVelocidad.CntTResetAlarma==0)  calcProcEvValid(ValorAct);
       Buffer.ChStruct.Temporario.TVelocidad.CntTResetAlarma=Buffer.ChStruct.TResetAlarma;
     }

     // ************ Actualiza VMAXIMO y VMINIMO ***************
     if(Buffer.ChStruct.Temporario.TVelocidad.MedMax <= ValorAct)
     {   Buffer.ChStruct.Temporario.TVelocidad.MedMax = ValorAct;
         FlagsViento.AneMax = 1;
     }
     if(Buffer.ChStruct.Temporario.TVelocidad.MedMin >= ValorAct)
     {   Buffer.ChStruct.Temporario.TVelocidad.MedMin = ValorAct;
         FlagsViento.AneMin = 1;
     }

     // proceso del TStorage.
     Buffer.ChStruct.Temporario.TVelocidad.SumaStorage += ValorAct;
     if((Time % Buffer.ChStruct.Temporario.TVelocidad.TStorage)==0)
     {
         // Calcula Valor Medio en Tstorage, corrige el primer registro ya que no se suman todos los Tread
         Buffer.ChStruct.Temporario.TVelocidad.MedMed=Buffer.ChStruct.Temporario.TVelocidad.SumaStorage/Buffer.ChStruct.TStorage;
         if (Buffer.ChStruct.Temporario.TVelocidad.MedMed < Buffer.ChStruct.Temporario.TVelocidad.MedMin)
             Buffer.ChStruct.Temporario.TVelocidad.MedMed = (Buffer.ChStruct.Temporario.TVelocidad.MedMin>>1) + (Buffer.ChStruct.Temporario.TVelocidad.MedMax>>1);
         // Registro del DATO
         calcMakeStorageVelo();
         // ************** Proceso TDiscret *************************
         if((Time % Buffer.ChStruct.Temporario.TVelocidad.TDiscret) == 0)  calcMakeDiscretVelo();
         // ************** Proceso TEval ****************************
         if((Time % Buffer.ChStruct.Temporario.TVelocidad.TEval) == 0)
         {
           if ((!Buffer.ChStruct.Temporario.Flags.NoVal) && (Buffer.ChStruct.Flags.AlarmaOn))
           {
             // Alarmas de Alta y Baja
             if (Buffer.ChStruct.Temporario.TVelocidad.MedMed >= Buffer.ChStruct.AlarmaMax)
                 calcProAlVelo(AlMax, Buffer.ChStruct.Temporario.TVelocidad.MedMed);
             if (Buffer.ChStruct.Temporario.TVelocidad.MedMed <= Buffer.ChStruct.AlarmaMin)
                 calcProAlVelo(AlMin, Buffer.ChStruct.Temporario.TVelocidad.MedMed);
             // Alarmas Ascendente y Descendente
             if (Buffer.ChStruct.Temporario.TVelocidad.MedMed > Buffer.ChStruct.Temporario.TVelocidad.MedAnt)
             {   Diferencia = Buffer.ChStruct.Temporario.TVelocidad.MedMed-Buffer.ChStruct.Temporario.TVelocidad.MedAnt;
                 if (Diferencia >= Buffer.ChStruct.AlarmaSubida) calcProAlVelo(AlAsc, Diferencia);
             }
             else
             {   Diferencia = Buffer.ChStruct.Temporario.TVelocidad.MedAnt-Buffer.ChStruct.Temporario.TVelocidad.MedMed;
                 if (Diferencia >= Buffer.ChStruct.AlarmaBajada) calcProAlVelo(AlDes, Diferencia);
             }
             // Alarmas de Pico Max y Min
             if (Buffer.ChStruct.Temporario.TVelocidad.MedMax >= Buffer.ChStruct.AlarmaMaxPico)
                 calcProAlMete(AlPkMax, Buffer.ChStruct.Temporario.TVelocidad.MedMax);
             if (Buffer.ChStruct.Temporario.TVelocidad.MedMin <= Buffer.ChStruct.AlarmaMinPico)
                 calcProAlVelo(AlPkMin, Buffer.ChStruct.Temporario.TVelocidad.MedMin);
           }
         }

         Buffer.ChStruct.Temporario.TVelocidad.MedMax = 0;
         Buffer.ChStruct.Temporario.TVelocidad.MedMin = 0xffff;
         Buffer.ChStruct.Temporario.TVelocidad.SumaStorage = 0;
         Buffer.ChStruct.Temporario.TVelocidad.MedAnt = Buffer.ChStruct.Temporario.TVelocidad.MedMed;
     };

     // Agregado por GGB
     Buffer.ChStruct.Temporario.TVelocidad.TMed = Buffer.ChStruct.TMed;
     Buffer.ChStruct.Temporario.TVelocidad.TRead = Buffer.ChStruct.TRead;
     Buffer.ChStruct.Temporario.TVelocidad.TStorage = Buffer.ChStruct.TStorage * Buffer.ChStruct.TRead;
     Buffer.ChStruct.Temporario.TVelocidad.TEval = Buffer.ChStruct.TEval * Buffer.ChStruct.Temporario.TVelocidad.TStorage;
     Buffer.ChStruct.Temporario.TVelocidad.TDiscret = Buffer.ChStruct.TDiscret * Buffer.ChStruct.Temporario.TVelocidad.TStorage;
     // ... Fin Agregado
     *ChPtr=Buffer.ChStruct.Temporario;
  }


 /*  Procesa el TRead del Canal de Velocidad de Viento
  ***************************************************/
  void chCalDireccion(void)
  {
     struct{
         uint8_t  Temp: 1;  // Bit temporario para almacenar el signo en las opraciones intermedias
     } Signo;
     union{
         uint32_t Tempo;
         struct{uint16_t Lo,Hi;}__attribute__ ((packed)) Short;
     }SH;
     uint16_t Cambio;

     lowRdPage(Page);
     Buffer.ChStruct.Temporario = *ChPtr;
     Buffer.ChStruct.Temporario.Flags.On = Buffer.ChStruct.Flags.On;
     *TipoPtr = Buffer.ChStruct.Tipo;

     // Calcula el resultado de todos los samples del promedio vectorial
     Signo.Temp = 0;
     if (Buffer.ChStruct.Temporario.TDireccion.CntVueltas2 >= 0x8000)  Signo.Temp = 1;
     SH.Short.Hi = (Buffer.ChStruct.Temporario.TDireccion.CntVueltas2 & 0x7fff);
     SH.Short.Lo = 0;
     if (!Signo.Temp)
     { Buffer.ChStruct.Temporario.TDireccion.SumaDir += SH.Tempo; }
     else
     {   Buffer.ChStruct.Temporario.TDireccion.SumaDir -= SH.Tempo;
         Signo.Temp = 0;
         if (Buffer.ChStruct.Temporario.TDireccion.SumaDir > 0x80000000)
         {   Buffer.ChStruct.Temporario.TDireccion.SumaDir &= 0x7fffffff;
             Signo.Temp = 1;
         }
     }
     if(Buffer.ChStruct.Temporario.TDireccion.CntMed == 0) return;
     Buffer.ChStruct.Temporario.TDireccion.SumaDir = Buffer.ChStruct.Temporario.TDireccion.SumaDir/Buffer.ChStruct.Temporario.TDireccion.CntMed;
     Buffer.ChStruct.Temporario.TDireccion.SumaDir &= 0xffff;
     if (Signo.Temp)Buffer.ChStruct.Temporario.TDireccion.SumaDir = 0x10000-Buffer.ChStruct.Temporario.TDireccion.SumaDir;
     Buffer.ChStruct.Temporario.TDireccion.Suma.DirHi = 0;
     SH.Tempo = Buffer.ChStruct.Temporario.TDireccion.SumaDir * VSB.VeleSpan / 32768 + VCB.VeleCero;
     LastDireccion = (uint32_t)SH.Tempo;
     LastDirInter = Buffer.ChStruct.Temporario.TDireccion.Suma.DirLo;  // Esta es sin desescalar
     if (FlagsViento.AneMax)MaxDireccion = LastDireccion;
     if (FlagsViento.AneMin)MinDireccion = LastDireccion;
     FlagsViento.AneMax = 0;
     FlagsViento.AneMin = 0;

     // Reinicia todas las variables
     // ****************************
     Buffer.ChStruct.Temporario.TDireccion.SumaDir = 0;
     Buffer.ChStruct.Temporario.TDireccion.CntMed = 0;
     Buffer.ChStruct.Temporario.TDireccion.CntVueltas = 0;
     Buffer.ChStruct.Temporario.TDireccion.CntVueltas2 = 0;

     // Se realiza aqui la suma del promedio de promedio vectorial para procesarlo luego en el tstorage
     SD.SumaDir += LastDirInter;
     CntMed++;
     if(LastDirInter > MedAnt)
     {   Cambio = LastDirInter-MedAnt;
         if(Cambio >= 0x8000)  CntVueltas++;
     }
     else
     {   Cambio = MedAnt-LastDirInter;
         if(Cambio >= 0x8000)  CntVueltas--;
     }
     CntVueltas2 += CntVueltas;
     MedAnt = LastDirInter;

     // Indica que el buffer del Viento está full
     FlagsViento.VeleFull = 1; // Habilita la invocacion de vtoVientoProc() donde se procesa el Tsorage
                               // y se dispara el Registro de Veleta
     *ChPtr=Buffer.ChStruct.Temporario;
  }

 /* Procesa el TRead de los Canales de Supervision Analogico
  ***************************************************/
  void chCalSupervisionAnalog(void)
  {
     lowRdPage(Page);
     Buffer.ChStruct.Temporario = *ChPtr;
     Buffer.ChStruct.Temporario.Flags.On = Buffer.ChStruct.Flags.On;
     *TipoPtr=Buffer.ChStruct.Tipo;

     // ********** Decrementador del T de Alarma *****************
     if (Buffer.ChStruct.Temporario.TSuperv.CntTResetAlarma!=0)
               Buffer.ChStruct.Temporario.TSuperv.CntTResetAlarma--;

     // *********** Promediacion de los DATOS ********************
     if(Buffer.ChStruct.Temporario.TSuperv.CntMed == 0) return;
     ValorAct = Buffer.ChStruct.Temporario.TSuperv.SumaMed/Buffer.ChStruct.Temporario.TSuperv.CntMed;
     Buffer.ChStruct.Temporario.TSuperv.SumaMed = 0;
     Buffer.ChStruct.Temporario.TSuperv.CntMed = 0;

     // Evaluación de validez.
     Buffer.ChStruct.Temporario.Flags.NoVal = 0;
     if (ValorAct>Buffer.ChStruct.MaxValid)  Buffer.ChStruct.Temporario.Flags.NoVal=1;
     if (ValorAct<Buffer.ChStruct.MinValid)  Buffer.ChStruct.Temporario.Flags.NoVal=1;
     if (Buffer.ChStruct.Temporario.Flags.NoVal)
     {   // Evento por dato no valido
         if (Buffer.ChStruct.Temporario.TSuperv.CntTResetAlarma==0)  calcProcEvValid(ValorAct);
         Buffer.ChStruct.Temporario.TSuperv.CntTResetAlarma = Buffer.ChStruct.TResetAlarma;
     }

     // ************* Proceso del TEval ***********************
     // siempre y cuando el dato sea valido y las alarmas esten habilitadas
     if((Time % Buffer.ChStruct.Temporario.TSuperv.TEval) == 0)
     {
         if ((!Buffer.ChStruct.Temporario.Flags.NoVal) && (Buffer.ChStruct.Flags.AlarmaOn))
         {   if (ValorAct >= Buffer.ChStruct.AlarmaMax) calcProcAlSuperv(AlMax,ValorAct); // Generacion Evento
             if (ValorAct <= Buffer.ChStruct.AlarmaMin) calcProcAlSuperv(AlMin,ValorAct); // Generacion Evento
         }
     }

     // Agregado por GGB
     Buffer.ChStruct.Temporario.TSuperv.TMed = Buffer.ChStruct.TMed;
     Buffer.ChStruct.Temporario.TSuperv.TRead = Buffer.ChStruct.TRead;
     Buffer.ChStruct.Temporario.TSuperv.TEval = Buffer.ChStruct.TEval * Buffer.ChStruct.TStorage;

     *ChPtr=Buffer.ChStruct.Temporario;
  }


 /* Procesa el TRead del Canal Pluviometrico
  ***************************************************/
  void chCalPluviometrico(void)
  {  uint8_t reg=0;
     uint32_t prim;
     lowRdPage(Page);
     Buffer.ChStruct.Temporario = *ChPtr;
     Buffer.ChStruct.Temporario.Flags.On = Buffer.ChStruct.Flags.On; // Encendido
     Buffer.ChStruct.Temporario.Flags.Red_Dif = Buffer.ChStruct.Flags.Red_Dif; // Redundancia de Pluvi
     Buffer.ChStruct.Temporario.Flags.Ola_Dif = Buffer.ChStruct.Flags.Ola_Dif; // Modo Diferencial de Pluvi
     *TipoPtr = Buffer.ChStruct.Tipo;

     // ********** Decrementador del T de Alarma *****************
     if (Buffer.ChStruct.Temporario.TPluviometrico.CntTResetAlarma!=0)
               Buffer.ChStruct.Temporario.TPluviometrico.CntTResetAlarma--;

     // ***** Evaluación de validez *****
     prim = __get_PRIMASK();
     __disable_interrupt();
     ValorAct = InstAD.Cangilones;
     if(!prim){
    	 __enable_interrupt();
     	 }
     if (ValorAct>Buffer.ChStruct.MaxValid)  Buffer.ChStruct.Temporario.Flags.NoVal=1;
     if (Buffer.ChStruct.Temporario.Flags.NoVal)
     {   if(Buffer.ChStruct.Temporario.TPluviometrico.CntTResetAlarma==0)  calcProcEvValid(ValorAct);
         Buffer.ChStruct.Temporario.TPluviometrico.CntTResetAlarma = 6;
     }

     // ***** Procesamiento Registro en Modo Diferencial *****
     if(Buffer.ChStruct.Flags.Ola_Dif)
     {
        if(InstAD.Cangilones > Buffer.ChStruct.Temporario.TPluviometrico.StorageAnt)
           Diferencia = InstAD.Cangilones - Buffer.ChStruct.Temporario.TPluviometrico.StorageAnt;
        else
        {  // Corrijo inconsistencia
           Buffer.ChStruct.Temporario.TPluviometrico.StorageAnt = InstAD.Cangilones;
           Diferencia = 0;
        }
       // ******* Registro por diferencia *********
       if (Diferencia >= Buffer.ChStruct.MaxSubidaTx)
       {
           // Pongo dato en pila del canal y pila de Tx
           calcMakeDiscretPluvi();
           Buffer.ChStruct.Temporario.TPluviometrico.StorageAnt = InstAD.Cangilones;
           reg=1;
       }
       Buffer.ChStruct.Temporario.Flags.NoVal = 0;
     }

     // proceso del TStorage
     if((Time % Buffer.ChStruct.Temporario.TPluviometrico.TStorage) == 0)
     {
         if(!Buffer.ChStruct.Flags.Ola_Dif)
         {   calcMakeStoragePluvi();  // Registra ValorAct
             reg=2;
             Buffer.ChStruct.Temporario.Flags.NoVal = 0;
         }
     }

     // proceso del TDiscret
     if((Time % Buffer.ChStruct.Temporario.TPluviometrico.TDiscret) == 0)
     {
         if(reg != 1) // Aun no ejecuto el calcMakeDiscretPluvi()
         {   calcMakeDiscretPluvi();
             Buffer.ChStruct.Temporario.TPluviometrico.StorageAnt = InstAD.Cangilones;
         }
         // Evento de Variacion respecto de la ultima Tx
         if(!Buffer.ChStruct.Flags.Ola_Dif)
         { Diferencia = InstAD.Cangilones - Buffer.ChStruct.Temporario.TPluviometrico.VuelcosAnt;
           if (Diferencia >= Buffer.ChStruct.MaxSubidaTx) calcProcTxPluvi(TxPluvi,Diferencia);
           Buffer.ChStruct.Temporario.TPluviometrico.VuelcosAnt = InstAD.Cangilones;
         }
         // Proceso del TCero: Puesta a Cero del acumulador de Cangilones
         if((Time % Buffer.ChStruct.Temporario.TPluviometrico.TCero) == 0 )
         {   reg=2;
         	 prim = __get_PRIMASK();
             __disable_interrupt();
             InstAD.Cangilones = 0;
             if(!prim){
                 	 __enable_interrupt();
                  	 }
             // Evento de puesta a cero
             calcProcPluvi0();
         }
     }
     // Agregado por GGB
     Buffer.ChStruct.Temporario.TPluviometrico.TRead = Buffer.ChStruct.TRead;
     Buffer.ChStruct.Temporario.TPluviometrico.TStorage = Buffer.ChStruct.TStorage * Buffer.ChStruct.TRead;
     Buffer.ChStruct.Temporario.TPluviometrico.TDiscret = Buffer.ChStruct.TDiscret * Buffer.ChStruct.Temporario.TPluviometrico.TStorage;
     Buffer.ChStruct.Temporario.TPluviometrico.TCero = Buffer.ChStruct.TCero * Buffer.ChStruct.Temporario.TPluviometrico.TDiscret;
     // ... Fin Agregado
     *ChPtr = Buffer.ChStruct.Temporario;
     // Salvo en Pag 0x17 las cuentas de cangilon
     if(reg) calcSavePluvi();     // NUEVO
  }

  
   /*  Procesa el TRead del Canal SDI12
   // como si fuera limnimetro el dato leído, las alarmas se procesan como de limnímetro
  ********************************************/
  void chCalSDI12(void)
  {
     uint8_t regDif=0;
     lowRdPage(Page);
     *TipoPtr=Buffer.ChStruct.Tipo;
     Buffer.ChStruct.Temporario = *ChPtr; // Almacena la Struct AnalogicoXX en Temporario
     Buffer.ChStruct.Temporario.Flags.On = Buffer.ChStruct.Flags.On; // Flag de encendido, pasa de flash a struct en RAM

     // Mientras CntTResetAlarma sea !=0 inhibe la generacion de un Evento de Alarma
     if (Buffer.ChStruct.Temporario.TSDI12.CntTResetAlarma != 0)
               Buffer.ChStruct.Temporario.TSDI12.CntTResetAlarma--;

     // ******** Obtención del Promedio en TMed *************
     if(Buffer.ChStruct.Temporario.TSDI12.CntMed == 0) return;   // NO HAY DATOS ...
     ValorAct = Buffer.ChStruct.Temporario.TSDI12.SumaMed / Buffer.ChStruct.Temporario.TSDI12.CntMed;
     Buffer.ChStruct.Temporario.TSDI12.SumaMed = 0;
     Buffer.ChStruct.Temporario.TSDI12.CntMed = 0;

     // *************** Validación del DATO *****************
     Buffer.ChStruct.Temporario.Flags.NoVal = 0;
     if (ValorAct > Buffer.ChStruct.MaxValid)  Buffer.ChStruct.Temporario.Flags.NoVal = 1;
     if (ValorAct < Buffer.ChStruct.MinValid)  Buffer.ChStruct.Temporario.Flags.NoVal = 1;
     if (Buffer.ChStruct.Temporario.Flags.NoVal)
     { // Evento por dato no valido
       if (Buffer.ChStruct.Temporario.TSDI12.CntTResetAlarma==0)  calcProcEvValid(ValorAct);
       Buffer.ChStruct.Temporario.TSDI12.CntTResetAlarma = Buffer.ChStruct.TResetAlarma;
     }
     else // Calculos sujetos a validez del dato
     {   // ************ Calculo de MAXIMOs y MINIMOs **********************
         //if (Buffer.ChStruct.Temporario.TSDI12.MedMax < ValorAct)
         //          Buffer.ChStruct.Temporario.TSDI12.MedMax = ValorAct;
         //if (Buffer.ChStruct.Temporario.TSDI12.MedMin > ValorAct)
         //          Buffer.ChStruct.Temporario.TSDI12.MedMin = ValorAct;
         // ************* Proceso Registro Diferencial **********************
         if(Buffer.ChStruct.Flags.Red_Dif)
         {
           if(ValorAct >= Buffer.ChStruct.Temporario.TSDI12.MedMed)
                     Diferencia = ValorAct - Buffer.ChStruct.Temporario.TSDI12.MedMed;
           else      Diferencia = Buffer.ChStruct.Temporario.TSDI12.MedMed - ValorAct;
           // ******* Registro por diferencia *********
           if(Diferencia >= Buffer.ChStruct.MaxSubidaTx)
           {
               // Guardo valor del dato a registrar
               Buffer.ChStruct.Temporario.TSDI12.MedMed = ValorAct;
               // Pongo dato en pila del canal y pila de Tx
               calcMakeDiscretSDI12();
               regDif=1;
           }
         }
     }

     // Acumulado en los Tread para promediacion en Tstorage
     // NO en SDI-12
     //if(!Buffer.ChStruct.Flags.Red_Dif) Buffer.ChStruct.Temporario.TSDI12.SumaStorage += ValorAct;

     // ******************* Proceso del TStorage (En SDI12 ==TRead)************************
     if(1)  //(Time % Buffer.ChStruct.Temporario.TSDI12.TRead) == 0)
     {
         if(!Buffer.ChStruct.Flags.Red_Dif)
         { // Calcula Valor Medio en Tstorage
           //NO en SDI-12
           //Buffer.ChStruct.Temporario.TSDI12.MedMed = Buffer.ChStruct.Temporario.TSDI12.SumaStorage/Buffer.ChStruct.TRead;
        	 Buffer.ChStruct.Temporario.TSDI12.MedMed = ValorAct;
           // Esto corrige incoherencias en los datos
           // En el primer registro no se suman todos los Tread y al promediar MedMed divide por la cantidad teorica
           // Tb puede ser que se hayan sumado valores no validos
           /* no en SDI12
            * if( (Buffer.ChStruct.Temporario.TSDI12.MedMed < Buffer.ChStruct.Temporario.TSDI12.MedMin)
            *   || (Buffer.ChStruct.Temporario.TSDI12.MedMed > Buffer.ChStruct.Temporario.TSDI12.MedMax))
            *{
            *   if(Buffer.ChStruct.Temporario.TSDI12.MedMax >= Buffer.ChStruct.Temporario.TSDI12.MedMin)
            *   {
            *       Buffer.ChStruct.Temporario.TSDI12.MedMed =
            *           (Buffer.ChStruct.Temporario.TSDI12.MedMin>>1)+(Buffer.ChStruct.Temporario.TSDI12.MedMax>>1);
            *   }
            *   else
            *   {   Buffer.ChStruct.Temporario.TSDI12.MedMed = ValorAct;
            *       Buffer.ChStruct.Temporario.TSDI12.MedMin = ValorAct;
            *       Buffer.ChStruct.Temporario.TSDI12.MedMax = ValorAct;
            *   }
            * }
            */
           // registra Buffer.ChStruct.Temporario.TSDI12.MedMed
           calcMakeStorageSDI12();
         }
         // ************* Proceso del TDiscret ***************************
         // ___Para SDI12 siempre que adquiero discret____
         //if((Time % Buffer.ChStruct.Temporario.TSDI12.TDiscret) == 0)
         //{
        	 if(!regDif)
             {   Buffer.ChStruct.Temporario.TSDI12.MedMed = ValorAct;
                 calcMakeDiscretSDI12();    // pone Bit.TxToo en "1"
                 regDif=1;
             }
         //}
         // ***************** Proceso TEval ****************************
         // siempre y cuando el dato sea valido y el flag de Alarma este On
         if((Time % Buffer.ChStruct.Temporario.TSDI12.TEval)==0)
         {
           if((!Buffer.ChStruct.Temporario.Flags.NoVal) && (Buffer.ChStruct.Flags.AlarmaOn))
           {
             // Alarmas de Alta y Baja
             if(Buffer.ChStruct.Temporario.TSDI12.MedMed >= Buffer.ChStruct.AlarmaMax)
            	 calcProcAlSDI12(AlMax, Buffer.ChStruct.Temporario.TSDI12.MedMed);
             if(Buffer.ChStruct.Temporario.TSDI12.MedMed <= Buffer.ChStruct.AlarmaMin)
            	 calcProcAlSDI12(AlMin, Buffer.ChStruct.Temporario.TSDI12.MedMed);
             // Alarmas Ascendente y Descendente
             if(!Buffer.ChStruct.Flags.Red_Dif)
             {   if(Buffer.ChStruct.Temporario.TSDI12.MedMed > Buffer.ChStruct.Temporario.TSDI12.MedAnt)
                 {   Diferencia = Buffer.ChStruct.Temporario.TSDI12.MedMed-Buffer.ChStruct.Temporario.TSDI12.MedAnt;
                     if(Diferencia >= Buffer.ChStruct.AlarmaSubida) calcProcAlSDI12(AlAsc,Diferencia);
                 }
                 else
                 {   Diferencia = Buffer.ChStruct.Temporario.TSDI12.MedAnt-Buffer.ChStruct.Temporario.TSDI12.MedMed;
                     if(Diferencia >= Buffer.ChStruct.AlarmaBajada) calcProcAlSDI12(AlDes,Diferencia);
                 }
                 Buffer.ChStruct.Temporario.TSDI12.MedAnt = Buffer.ChStruct.Temporario.TSDI12.MedMed;
             }
             // Alarmas de Pico Max y Min --no en SDI12
             //if (Buffer.ChStruct.Temporario.TSDI12.MedMax >= Buffer.ChStruct.AlarmaMaxPico)
             //    calcProcAlLimni(AlPkMax,Buffer.ChStruct.Temporario.TSDI12.MedMax);
             //if (Buffer.ChStruct.Temporario.TSDI12.MedMin <= Buffer.ChStruct.AlarmaMinPico)
             //    calcProcAlLimni(AlPkMin,Buffer.ChStruct.Temporario.TSDI12.MedMin);
           }
         }
         // Puesta a cero p/calculos de Max, Min y Medio
         if(!Buffer.ChStruct.Flags.Red_Dif || regDif)
         {
           // Buffer.ChStruct.Temporario.TSDI12.MedMax = 0;
           // Buffer.ChStruct.Temporario.TSDI12.MedMin = 0xffff;
           Buffer.ChStruct.Temporario.TSDI12.SumaStorage = 0;
         }
     }

     // Agregado por GGB
     //Buffer.ChStruct.Temporario.TSDI12.TMed = Buffer.ChStruct.TMed;
     Buffer.ChStruct.Temporario.TSDI12.TRead = Buffer.ChStruct.TRead;
    // Buffer.ChStruct.Temporario.TSDI12.TStorage = Buffer.ChStruct.TStorage * Buffer.ChStruct.TRead;
     Buffer.ChStruct.Temporario.TSDI12.TEval = Buffer.ChStruct.TEval * Buffer.ChStruct.Temporario.TSDI12.TRead;
     Buffer.ChStruct.Temporario.TSDI12.TDiscret = Buffer.ChStruct.TDiscret * Buffer.ChStruct.Temporario.TSDI12.TRead;
     // ... Fin Agregado
     *ChPtr=Buffer.ChStruct.Temporario;
  }/////////////////////////////////// FIN SDI12
  
  
  
 /* Procesa el TRead de los Canales de Supervision Digital
  ***************************************************/
  void chCalSupervDigital(void)
  {
     lowRdPage(Page);
     Buffer.ChStruct.Temporario.TSupervDigital = *DigPtr;
     Buffer.ChStruct.Temporario.TSupervDigital.Flags.On = Buffer.ChStruct.Flags.On;
     *TipoPtr=Buffer.ChStruct.Tipo;

     // ************ Decrementador del T de Alarma ******************
     if(Buffer.ChStruct.Temporario.TSupervDigital.CntTResetAlarma!=0)
               Buffer.ChStruct.Temporario.TSupervDigital.CntTResetAlarma--;

     // ********* Proceso del TEval (coincide con TRead) ************
     // Evaluacion de Validez en caso de usar REDUNDANCIA
     Buffer.ChStruct.Flags.NoVal=0;
     /* TODO implementar
     switch (Page){
         case 0x0f:      // Canal digital 1, asociado a los pines Ps1 y redundancia Ps2
                         if ((Buffer.ChStruct.Flags.Red_Dif)&&(__PORTLP_bit.Ps1==__PORTLP_bit.Ps2))
                                 Buffer.ChStruct.Flags.NoVal=1;
                         break;

         case 0x10:      // Canal digital 2, asociado a los pines Ps1 y redundancia Ps2
                         break;

         case 0x11:      // Canal digital 3, asociado a los pines IN5 y redundancia IN6
                         if ((Buffer.ChStruct.Flags.Red_Dif)&&(__PORTAP_bit.IN5==__PORTAP_bit.IN6))
                                 Buffer.ChStruct.Flags.NoVal=1;
                         break;

         case 0x12:      // Canal digital 4, asociado a los pines IN5 y redundancia IN6
                         break;

         case 0x13:      // Canal digital 5, asociado a los pines IN7 y redundancia IN8
                         if ((Buffer.ChStruct.Flags.Red_Dif)&&(__PORTAP_bit.IN7==__PORTAP_bit.IN8))
                                 Buffer.ChStruct.Flags.NoVal=1;
                         break;

         case 0x14:      // Canal digital 6, asociado a los pines IN7 y redundancia IN8
                         break;
     }
     // Evento por dato no valido, aplica en CntTResetAlarma
     if (Buffer.ChStruct.Flags.NoVal) calcProcDgValid();

     // Evaluación de la alarma: siempre que el dato sea valido y la alarma este activada
     // ***********************
     if ((!Buffer.ChStruct.Flags.NoVal) && (Buffer.ChStruct.Flags.AlarmaOn))
     {
       switch (Page){
         case 0x0f:      // Canal digital 1
                         if (Buffer.ChStruct.Flags.Normal != __PORTLP_bit.Ps1) calcProcAlDigital();
                         break;

         case 0x10:      // Canal digital 2
                         if (Buffer.ChStruct.Flags.Normal != __PORTLP_bit.Ps2) calcProcAlDigital();
                         break;

         case 0x11:      // Canal digital 3
                         if (Buffer.ChStruct.Flags.Normal != __PORTAP_bit.IN5) calcProcAlDigital();
                         break;

         case 0x12:      // Canal digital 4
                         if (Buffer.ChStruct.Flags.Normal != __PORTAP_bit.IN6) calcProcAlDigital();
                         break;

         case 0x13:      // Canal digital 5
                         if (Buffer.ChStruct.Flags.Normal != __PORTAP_bit.IN7) calcProcAlDigital();
                         break;

         case 0x14:      // Canal digital 6
                         if (Buffer.ChStruct.Flags.Normal != __PORTAP_bit.IN8) calcProcAlDigital();
                         break;
       }
     }
     */

     Buffer.ChStruct.Temporario.TSupervDigital.Flags = Buffer.ChStruct.Flags;
     Buffer.ChStruct.Temporario.TSupervDigital.TRead = Buffer.ChStruct.TRead;
     *DigPtr = Buffer.ChStruct.Temporario.TSupervDigital;
  }

 /* Calcula los resultados de cada canal general
  **********************************************/
   void chCalCanal(void)
   {
     switch (*TipoPtr){  //Buffer.ChStruct.Temporario.Tipo){   //Cada canal se procesa segun el tipo, se genera el paquete(????REVISAR)
         case Limnimetrico:
                             chCalLimnimetrico();
                             break;
         case Meteorologico:
                             chCalMeteorologico();
                             break;
         case VelocidadViento:
                             chCalVelocidad();
                             break;
         case DireccionViento:
                             chCalDireccion();
                             break;
         case SupervAnalog:
                             chCalSupervisionAnalog();
                             break;
         case Pluviometrico:
                             chCalPluviometrico();
                             break;
         case SupervDigital:
                             chCalSupervDigital();
                             break;
        case SDI12:
        case RS485:
                             chCalSDI12();
                             break;
     }
  }

 /*  Se invoca permanentemente desde el main
     En cada llamada procesa 1 de los 23 canales, va secuenciando
     EA1 ... EA16, PLV, ED1 .. ED6
  **************************************/
  void chCalAll(void){

     if(StatusIO.Vacio)  // Estan disponible los buffers para mandar datos a la CPU
     {
       switch(Llego){  // Algun canal llego al Tread
         case Canal1:
             if (Hay.Bytes.Bits1.Ana1){ // Se cumplio un Tread en el Canal 1
               Page=0; //Se selecciona la Página 0
               ChPtr=&Analogico1;  //Se apunta Analógico1
               PtrInstAD=&InstAD.Canal1; //Se apunta a la medicion instantánea del canal 1
               TipoPtr=&Tipo[Canal1];  //Se apunta el tipo de canal 1
               chCalCanal(); // Lee la pagina 0 de Flash, procesa el dato segun el tipo de canal definido por TipoPtr
               chClrHay(); //Se borra el flag "Hay.Bytes.Bits1.Ana1"
             };
             Llego=Canal2; // Secuencia procesamiento de canal 2 p/el proximo llamado
             break;
         case Canal2:
             if (Hay.Bytes.Bits1.Ana2){
               Page=1;
               ChPtr=&Analogico2;
               PtrInstAD=&InstAD.Canal2;
               TipoPtr=&Tipo[Canal2];
               chCalCanal();
               chClrHay();
             };
             Llego=Canal3;
             break;
         case Canal3:
             if (Hay.Bytes.Bits1.Ana3){
               Page=2;
               ChPtr=&Analogico3;
               PtrInstAD=&InstAD.Canal3;
               TipoPtr=&Tipo[Canal3];
               chCalCanal();
               chClrHay();
             };
             Llego=Canal4;
             break;
         case Canal4:
             if (Hay.Bytes.Bits1.Ana4){
               Page=3;
               ChPtr=&Analogico4;
               PtrInstAD=&InstAD.Canal4;
               TipoPtr=&Tipo[Canal4];
               chCalCanal();
               chClrHay();
             };
             Llego=Canal5;
             break;
         case Canal5:
             if (Hay.Bytes.Bits1.Ana5){
               Page=4;
               ChPtr=&Analogico5;
               PtrInstAD=&InstAD.Canal5;
               TipoPtr=&Tipo[Canal5];
               chCalCanal();
               chClrHay();
             };
             Llego=Canal6;
             break;
         case Canal6:
             if (Hay.Bytes.Bits1.Ana6){
               Page=5;
               ChPtr=&Analogico6;
               PtrInstAD=&InstAD.Canal6;
               TipoPtr=&Tipo[Canal6];
               chCalCanal();
               chClrHay();
             };
             Llego=Canal7;
             break;
         case Canal7:
             if (Hay.Bytes.Bits1.Ana7){
               Page=6;
               ChPtr=&Analogico7;
               PtrInstAD=&InstAD.Canal7;
               TipoPtr=&Tipo[Canal7];
               chCalCanal();
               chClrHay();
             };
             Llego=Canal8;
             break;
         case Canal8:
             if (Hay.Bytes.Bits1.Ana8){
               Page=7;
               ChPtr=&Analogico8;
               PtrInstAD=&InstAD.Canal8;
               TipoPtr=&Tipo[Canal8];
               chCalCanal();
               chClrHay();
             };
             Llego=Canal9;
             break;
         case Canal9:
             if (Hay.Bytes.Bits2.Ana9){
               Page=8;
               ChPtr=&Analogico9;
               PtrInstAD=&InstAD.Canal9;
               TipoPtr=&Tipo[Canal9];
               chCalCanal();
               chClrHay();
             };
             Llego=Canal10;
             break;
         case Canal10:
             if (Hay.Bytes.Bits2.Anaa){
               Page=9;
               ChPtr=&Analogico10;
               PtrInstAD=&InstAD.Canal10;
               TipoPtr=&Tipo[Canal10];
               chCalCanal();
               chClrHay();
             };
             Llego=Canal11;
             break;
         case Canal11:
             if (Hay.Bytes.Bits2.Anab){
               Page=0xa;
               ChPtr=&Analogico11;
               PtrInstAD=&InstAD.Canal11;
               TipoPtr=&Tipo[Canal11];
               chCalCanal();
               chClrHay();
             };
             Llego=Canal12;
             break;
         case Canal12:
             if (Hay.Bytes.Bits2.Anac){
               Page=0xb;
               ChPtr=&Analogico12;
               PtrInstAD=&InstAD.Canal12;
               TipoPtr=&Tipo[Canal12];
               chCalCanal();
               chClrHay();
             };
             Llego=Canal13;
             break;
         case Canal13:
             if (Hay.Bytes.Bits2.Anad){
               Page=0xc;
               ChPtr=&Analogico13;
               PtrInstAD=&InstAD.Canal13;
               TipoPtr=&Tipo[Canal13];
               chCalCanal();
               chClrHay();
             };
             Llego=Canal14;
             break;
         case Canal14:
             if (Hay.Bytes.Bits2.Anae){
               Page=0xd;
               ChPtr=&Analogico14;
               PtrInstAD=&InstAD.Canal14;
               TipoPtr=&Tipo[Canal14];
               chCalCanal();
               chClrHay();
             };
             Llego=Canal15;
             break;
         case Canal15:
             if (Hay.Bytes.Bits3.Anaf){      // Estos bits se ponen en "1" por Nro de Pag
               Page=0x15;
               ChPtr=&Analogico15;
               PtrInstAD=&InstAD.Canal15;
               TipoPtr=&Tipo[Canal15];
               chCalCanal();
               chClrHay();
             };
             Llego=Canal16;
             break;
         case Canal16:
             if (Hay.Bytes.Bits3.Anag){
               Page=0x16;
               ChPtr=&Analogico16;
               PtrInstAD=&InstAD.Canal16;
               TipoPtr=&Tipo[Canal16];
               chCalCanal();
               chClrHay();
             };
             Llego=CanalPluvi;
             break;
         case CanalPluvi:
             if (Hay.Bytes.Bits2.Pluv){
               Page=0xe;
               ChPtr=&Pluviometro;
               PtrInstAD=&InstAD.Cangilones;
               TipoPtr=&Tipo[CanalPluvi];
               chCalCanal();
               chClrHay();
             };
             Llego=Digit1;
             break;
         case Digit1:
             if (Hay.Bytes.Bits2.Dig1){
               Page=0xf;
               DigPtr=&Digital1;
               TipoPtr=&Tipo[Digit1];
               chCalCanal();
               chClrHay();
             };
             Llego=Digit2;
             break;
         case Digit2:
             if (Hay.Bytes.Bits3.Dig2){
               Page=0x10;
               DigPtr=&Digital2;
               TipoPtr=&Tipo[Digit2];
               chCalCanal();
               chClrHay();
             };
             Llego=Digit3;
             break;
         case Digit3:
             if (Hay.Bytes.Bits3.Dig3){
               Page=0x11;
               DigPtr=&Digital3;
               TipoPtr=&Tipo[Digit3];
               chCalCanal();
               chClrHay();
             };
             Llego=Digit4;
             break;
         case Digit4:
             if (Hay.Bytes.Bits3.Dig4){
               Page=0x12;
               DigPtr=&Digital4;
               TipoPtr=&Tipo[Digit4];
               chCalCanal();
               chClrHay();
             };
             Llego=Digit5;
             break;
         case Digit5:
             if (Hay.Bytes.Bits3.Dig5){
               Page=0x13;
               DigPtr=&Digital5;
               TipoPtr=&Tipo[Digit5];
               chCalCanal();
               chClrHay();
             };
             Llego=Digit6;
             break;
         case Digit6:
             if (Hay.Bytes.Bits3.Dig6){
               Page=0x14;
               DigPtr=&Digital6;
               TipoPtr=&Tipo[Digit6];
               chCalCanal();
               chClrHay();
             };
             Llego=Canal1;
             break;
       } // End Switch

       // Si paso por el Canal de Veleta, aca se procesa el Tstorage
       if (FlagsViento.VeleFull) vtoVientoProc();
     } // End if
  }
