#include "fsl_common.h"
#include "fsl_iocon.h"
#include "pin_mux.h"

#define IOCON_PIO_FUNC0 (0x00u)
//#define IOCON_PIO_FUNC1 (0x01u)
//#define IOCON_PIO_FUNC2 (0x02u)
#define IOCON_PIO_FUNC3 (0x03u)
#define IOCON_PIO_FUNC4 (0x04u)
#define IOCON_PIO_FUNC5 (0x05u)

void BOARD_InitPins(void)
{
    /* Enables the clock for the IOCON block. 0 = Disable; 1 = Enable.: 0x01u */
    CLOCK_EnableClock(kCLOCK_Iocon);

    /* Para usar los pines del LCD */
    const uint32_t port2_pin11_config = ( /*Pin is configured as FC5_SCK*/
                                         IOCON_PIO_FUNC5 |
                                          /*Selects pull-up function*/
                                         IOCON_PIO_MODE_PULLUP |
                                          /*Input function is not inverted*/
                                         IOCON_PIO_INV_DI |
                                          /*Enables digital function*/
                                         IOCON_PIO_DIGITAL_EN |
                                          /*Input filter disabled*/
                                         IOCON_PIO_INPFILT_OFF |
                                          /*Standard mode, output slew rate control is enabled*/
                                         IOCON_PIO_SLEW_STANDARD |
                                          /*Open drain is disabled*/
                                         IOCON_PIO_OPENDRAIN_DI);
     /*PORT2 PIN11 (pin 43) is configured as FC5_SCK*/
    IOCON_PinMuxSet(IOCON, 2U, 11U, port2_pin11_config);

    const uint32_t port2_pin12_config = ( /*Pin is configured as FC5_RXD_SDA_MOSI*/
                                         IOCON_PIO_FUNC5 |
                                          /*Selects pull-up function*/
                                         IOCON_PIO_MODE_PULLUP |
                                          /*Input function is not inverted*/
                                         IOCON_PIO_INV_DI |
                                          /*Enables digital function*/
                                         IOCON_PIO_DIGITAL_EN |
                                          /*Input filter disabled*/
                                         IOCON_PIO_INPFILT_OFF |
                                          /*Open drain is disabled*/
                                         IOCON_PIO_OPENDRAIN_DI);
     /*PORT2 PIN12 (pin 45) is configured as FC5_RXD_SDA_MOSI*/
    IOCON_PinMuxSet(IOCON, 2U, 12U, port2_pin12_config);

    const uint32_t port2_pin13_config = ( /*Pin is configured as FC5_TXD_SCL_MISO*/
                                         IOCON_PIO_FUNC5 |
                                          /*Selects pull-up function*/
                                         IOCON_PIO_MODE_PULLUP |
                                          /*Input function is not inverted*/
                                         IOCON_PIO_INV_DI |
                                          /*Enables digital function*/
                                         IOCON_PIO_DIGITAL_EN |
                                          /*Input filter disabled*/
                                         IOCON_PIO_INPFILT_OFF |
                                          /*Open drain is disabled*/
                                         IOCON_PIO_OPENDRAIN_DI);
     /*PORT2 PIN13 (pin 70) is configured as FC5_TXD_SCL_MISO*/
    IOCON_PinMuxSet(IOCON, 2U, 13U, port2_pin13_config);

    const uint32_t port2_pin14_config = ( /*Pin is configured as GPIO*/
                                         IOCON_PIO_FUNC0 |
                                          /*Selects pull-up function*/
                                         IOCON_PIO_MODE_PULLUP |
                                          /*Input function is not inverted*/
                                         IOCON_PIO_INV_DI |
                                          /*Enables digital function*/
                                         IOCON_PIO_DIGITAL_EN |
                                          /*Input filter disabled*/
                                         IOCON_PIO_INPFILT_OFF |
                                          /*Standard mode, output slew rate control is enabled*/
                                         IOCON_PIO_SLEW_STANDARD |
                                          /*Open drain is disabled*/
                                         IOCON_PIO_OPENDRAIN_DI);
    /*PORT2 PIN14 (pin 77) is configured as GPIO for manual CS*/
    IOCON_PinMuxSet(IOCON, 2U, 14U, port2_pin14_config);
	
//************************************************************************************************

    /* Para usar desde Interfaz P2 ---> JTAG */
    const uint32_t port0_pin2_config = (/* Pin is configured as FC3_TXD_SCL_MISO */
                                             IOCON_PIO_FUNC1 |
                                             /* Selects pull-up function */
                                             IOCON_PIO_MODE_PULLUP |
                                             /* Input function is not inverted */
                                             IOCON_PIO_INV_DI |
                                             /* Enables digital function */
                                             IOCON_PIO_DIGITAL_EN |
                                             /* Input filter disabled */
                                             IOCON_PIO_INPFILT_OFF |
                                             /* Standard mode, output slew rate control is enabled */
                                             IOCON_PIO_SLEW_STANDARD |
                                             /* Open drain is disabled */
                                             IOCON_PIO_OPENDRAIN_DI);
        /* PORT0 PIN2 (pin 174) is configured as FC3_TXD_SCL_MISO */
        IOCON_PinMuxSet(IOCON, 0U, 2U, port0_pin2_config);

        const uint32_t port0_pin3_config = (/* Pin is configured as FC3_RXD_SDA_MOSI */
                                             IOCON_PIO_FUNC1 |
                                             /* Selects pull-up function */
                                             IOCON_PIO_MODE_PULLUP |
                                             /* Input function is not inverted */
                                             IOCON_PIO_INV_DI |
                                             /* Enables digital function */
                                             IOCON_PIO_DIGITAL_EN |
                                             /* Input filter disabled */
                                             IOCON_PIO_INPFILT_OFF |
                                             /* Open drain is disabled */
                                             IOCON_PIO_OPENDRAIN_DI);
        /* PORT0 PIN3 (pin 178) is configured as FC3_RXD_SDA_MOSI */
        IOCON_PinMuxSet(IOCON, 0U, 3U, port0_pin3_config);

        const uint32_t port0_pin4_config = (/* Pin is configured as GPIO */
                                             IOCON_PIO_FUNC0 |
                                             /* Selects pull-up function */
                                             IOCON_PIO_MODE_PULLUP |
                                             /* Input function is not inverted */
                                             IOCON_PIO_INV_DI |
                                             /* Enables digital function */
                                             IOCON_PIO_DIGITAL_EN |
                                             /* Input filter disabled */
                                             IOCON_PIO_INPFILT_OFF |
                                             /* Open drain is disabled */
                                             IOCON_PIO_OPENDRAIN_DI);
        /* PORT0 PIN4 (pin 185) is configured as GPIO for manual CS */
        IOCON_PinMuxSet(IOCON, 0U, 4U, port0_pin4_config);

        const uint32_t port0_pin6_config = (/* Pin is configured as FC3_SCK */
                                             IOCON_PIO_FUNC1 |
                                             /* Selects pull-up function */
                                             IOCON_PIO_MODE_PULLUP |
                                             /* Input function is not inverted */
                                             IOCON_PIO_INV_DI |
                                             /* Enables digital function */
                                             IOCON_PIO_DIGITAL_EN |
                                             /* Input filter disabled */
                                             IOCON_PIO_INPFILT_OFF |
                                             /* Standard mode, output slew rate control is enabled */
                                             IOCON_PIO_SLEW_STANDARD |
                                             /* Open drain is disabled */
                                             IOCON_PIO_OPENDRAIN_DI);
        /* PORT0 PIN6 (pin 191) is configured as FC3_SCK*/
        IOCON_PinMuxSet(IOCON, 0U, 6U, port0_pin6_config);
}
/***********************************************************************************************************************
 * EOF
 **********************************************************************************************************************/
