#include "fsl_spi.h"
#include "board.h"
#include "fsl_debug_console.h"
#include "pin_mux.h"
#include <stdbool.h>

/*******************************************************************************
 * Definitions
 ******************************************************************************/
/*
#define EXAMPLE_SPI_MASTER SPI5
#define EXAMPLE_SPI_MASTER_CLK_SRC kCLOCK_Flexcomm5
#define EXAMPLE_SPI_MASTER_CLK_FREQ CLOCK_GetFlexCommClkFreq(5)
#define EXAMPLE_SPI_SSEL 0
#define EXAMPLE_SPI_SPOL kSPI_SpolActiveAllLow
*/

#define EXAMPLE_SPI_MASTER SPI3
#define EXAMPLE_SPI_MASTER_CLK_SRC kCLOCK_Flexcomm3
#define EXAMPLE_SPI_MASTER_CLK_FREQ CLOCK_GetFlexCommClkFreq(3)
#define EXAMPLE_SPI_SSEL 0
#define EXAMPLE_SPI_SPOL kSPI_SpolActiveAllLow

/*******************************************************************************
 * Variables
 ******************************************************************************/
#define BUFFER_SIZE (4)
static uint8_t srcBuff[BUFFER_SIZE] = { 0xAA, 0xBB, 0xCC, 0xDD }; // Datos a enviar
static uint8_t destBuff[BUFFER_SIZE] = { 0 };                     // Datos recibidos

#define CMD0   (0x40 | 0)    // GO_IDLE_STATE
#define CMD8   (0x40 | 8)    // SEND_IF_COND
#define CMD55  (0x40 | 55)   // APP_CMD (siempre antes de a ACMD)
#define ACMD41 (0x40 | 41)   // SD_SEND_OP_COND (después de ACMD)
#define CMD58  (0x40 | 58)   // READ_OCR (verificar CCS)

#define DUMMY_BYTE 0xFF
#define SD_START_TOKEN 0xFE

/*
#define CS_LOW()  GPIO->CLR[2] = (1 << 14)
#define CS_HIGH() GPIO->SET[2] = (1 << 14)
*/

#define CS_LOW()  GPIO->CLR[0] = (1 << 4)
#define CS_HIGH() GPIO->SET[0] = (1 << 4)

uint8_t response = 0xFF;
uint32_t tiempo_inicio, tiempo_fin, tiempo_total_ms;

uint8_t spi_send(uint8_t data) {
    while (!(SPI_GetStatusFlags(EXAMPLE_SPI_MASTER) & kSPI_TxNotFullFlag)) {
    }
    SPI_WriteData(EXAMPLE_SPI_MASTER, data, 0);

    while (!(SPI_GetStatusFlags(EXAMPLE_SPI_MASTER) & kSPI_RxNotEmptyFlag)) {
    }
    return (uint8_t) SPI_ReadData(EXAMPLE_SPI_MASTER); // Devolver dato recibido
}

static uint8_t spi_receive(void) {
    while (!(SPI_GetStatusFlags(EXAMPLE_SPI_MASTER) & kSPI_TxNotFullFlag)) {
    }
    SPI_WriteData(EXAMPLE_SPI_MASTER, DUMMY_BYTE, 0);
    while (!(SPI_GetStatusFlags(EXAMPLE_SPI_MASTER) & kSPI_RxNotEmptyFlag)) {
    }
    return (uint8_t) SPI_ReadData(EXAMPLE_SPI_MASTER);
}

/* -----------------------------------------------------------------------------
 * sd_send_command()
 * Envía comando y lee respuesta R1. DESELECCIONA la tarjeta (CS_HIGH) al salir.
 * Para comandos que NO devuelven bytes extra inmediatamente.
 * ---------------------------------------------------------------------------*/
static uint8_t sd_send_command(uint8_t cmd, uint32_t arg, uint8_t crc) {
    CS_LOW();
    spi_send(cmd);
    spi_send((arg >> 24) & 0xFF);
    spi_send((arg >> 16) & 0xFF);
    spi_send((arg >> 8) & 0xFF);
    spi_send(arg & 0xFF);
    spi_send(crc);

    for (int i = 0; i < 10; i++) {
        uint8_t resp = spi_receive();
        if ((resp & 0x80) == 0) {
            CS_HIGH();
            spi_receive(); // Dummy clock
            return resp;
        }
    }

    CS_HIGH();
    spi_receive(); // Dummy clock
    return 0xFF;
}

/* -----------------------------------------------------------------------------
 * sd_send_command_holdcs()
 * Igual a sd_send_command() PERO **NO** levanta CS ni manda dummy final.
 * Se usa cuando el comando devuelve bytes adicionales (ej: CMD8, CMD58, etc.).
 * Hay que llamar luego a CS_HIGH() manualmente tras leer los bytes extra.
 * ---------------------------------------------------------------------------*/
// ***
static uint8_t sd_send_command_holdcs(uint8_t cmd, uint32_t arg, uint8_t crc) {
    uint8_t resp = 0xFF;

    CS_LOW();
    spi_send(cmd);
    spi_send((arg >> 24) & 0xFF);
    spi_send((arg >> 16) & 0xFF);
    spi_send((arg >> 8) & 0xFF);
    spi_send(arg & 0xFF);
    spi_send(crc);

    for (int i = 0; i < 10; i++) {
        resp = spi_receive();
        if ((resp & 0x80) == 0) {
            return resp; // CS sigue LOW
        }
    }
    return 0xFF; // CS sigue LOW; caller decide
}
/*******************************************************************************
 * Main
 ******************************************************************************/
int main(void) {
    spi_master_config_t masterConfig = { 0 };
    spi_transfer_t xfer = { 0 };
    uint32_t sourceClock = 0U;
    status_t result;
    uint32_t i;

    /* Inicialización básica */
    CLOCK_AttachClk(BOARD_DEBUG_UART_CLK_ATTACH);
    //CLOCK_AttachClk(kFRO12M_to_FLEXCOMM5); //Para Interfaz SPI5
    CLOCK_AttachClk(kFRO12M_to_FLEXCOMM3);   //Para Interfaz SPI3
    BOARD_InitPins();

/*
    CLOCK_EnableClock(kCLOCK_Gpio2); //Para Interfaz SPI5
    GPIO->DIR[2] |= (1 << 14);
    GPIO->SET[2] = (1 << 14);   // CS alto
*/

    CLOCK_EnableClock(kCLOCK_Gpio0); //Para Interfaz SPI3
    GPIO->DIR[0] |= (1 << 4);
    GPIO->SET[0] = (1 << 4);   // CS alto

    BOARD_BootClockPLL180M();
    BOARD_InitDebugConsole();

    PRINTF("\r\nSPI test iniciado\r\n");

    /* Configuración SPI como master */
    SPI_MasterGetDefaultConfig(&masterConfig);
    sourceClock = EXAMPLE_SPI_MASTER_CLK_FREQ;
    masterConfig.sselNum = kSPI_Ssel0;                // Obligatorio por API, aunque CS se maneja por GPIO
    masterConfig.sselPol = kSPI_SpolActiveAllLow;
    masterConfig.baudRate_Bps = 400000U; // 100 ~ 400 kHz en inicialización

    SPI_MasterInit(EXAMPLE_SPI_MASTER, &masterConfig, sourceClock);

    /* Llenar struct de transferencia */
    xfer.txData = srcBuff;
    xfer.rxData = destBuff;
    xfer.dataSize = BUFFER_SIZE;
    xfer.configFlags = kSPI_FrameDelay;  // CS manual. NO USAR kSPI_FrameAssert

    /* Realizar transferencia bloqueante */
    result = SPI_MasterTransferBlocking(EXAMPLE_SPI_MASTER, &xfer);

    if (result == kStatus_Success) {
        PRINTF("Transferencia SPI exitosa\r\nDatos recibidos: ");
        for (i = 0; i < BUFFER_SIZE; i++) {
            PRINTF("0x%02X ", destBuff[i]);
        }
        PRINTF("\r\n");

        // ---------- Prueba de comandos SD ----------
        // Enviar 80 ciclos de reloj con CS alto (10 x 8 bits)
        CS_HIGH();
        for (int j = 0; j < 10; j++) {
            spi_send(DUMMY_BYTE);
        }

        SDK_DelayAtLeastUs(1000, CLOCK_GetFreq(kCLOCK_CoreSysClk)); // 1 ms, por si acaso

        // CMD0 - GO_IDLE_STATE
        uint8_t r;
        int intento = 0;
        do {
        	CS_LOW(); // por las dudas
            r = sd_send_command(CMD0, 0, 0x95);
            PRINTF("Respuesta CMD0: 0x%02X\r\n", r);
            SDK_DelayAtLeastUs(1000, CLOCK_GetFreq(kCLOCK_CoreSysClk)); // opcional
        } while (r != 0x01 && r != 0xFF && intento < 100); // repetir hasta Idle o timeout simple

        // CMD8 - SEND_IF_COND (para SD v2.0)
        r = sd_send_command_holdcs(CMD8, 0x000001AA, 0x87); // *** mantener CS
        PRINTF("Respuesta CMD8: 0x%02X\r\n", r);


        uint8_t ocr[4] = {0};
        if (r == 0x01) {  // si hubo respuesta válida
            for (int k = 0; k < 4; k++) {
                ocr[k] = spi_receive(); // *** leer con CS LOW
            }
        }

        CS_HIGH();          // *** cerrar transacción CMD8
        spi_receive();      // Dummy clock después de CS_HIGH (obligatorio para SD)

        if (r == 0x01) {
            PRINTF("OCR CMD8: 0x%02X 0x%02X 0x%02X 0x%02X\r\n",
                   ocr[0], ocr[1], ocr[2], ocr[3]);
        }
    }

    // ==== Inicialización con ACMD41 ====
    // Loop usando sd_send_command() (respuestas R1 simple)

    int retry = 0;
    uint8_t acmd_resp;

    do {
        response = sd_send_command(CMD55, 0x00000000, 0x65);  // CRC dummy
        PRINTF("Respuesta CMD55: 0x%02X\r\n", response);
        if (response > 1 && response != 0x01) {
            break; // error
        }

        acmd_resp = sd_send_command(ACMD41, 0x40000000, 0x77); // HCS = 1
        PRINTF("Intento %d - Respuesta ACMD41: 0x%02X\r\n", retry, acmd_resp);
        SDK_DelayAtLeastUs(1000, CLOCK_GetFreq(kCLOCK_CoreSysClk)); // opcional
        retry++;

    } while (acmd_resp != 0x00 && retry < 50); //normalmente en el segundo intento ya sale

    if (acmd_resp == 0x00 && response == 0x01) {
        PRINTF("Inicialización exitosa\r\n");

        // === CMD58: Leer OCR y verificar CCS ===
        response = sd_send_command_holdcs(CMD58, 0x00000000, 0x00);
        PRINTF("Respuesta CMD58: 0x%02X\r\n", response);

        if (response == 0x00) {
            uint8_t ocr58[4];
            for (int i = 0; i < 4; i++) {
                ocr58[i] = spi_receive();
            }
            CS_HIGH();
            spi_receive(); // dummy clock

            PRINTF("OCR CMD58: 0x%02X 0x%02X 0x%02X 0x%02X\r\n",
                   ocr58[0], ocr58[1], ocr58[2], ocr58[3]);

            if (ocr58[0] & 0x40) {
                PRINTF("Tarjeta SDHC/SDXC detectada (CCS = 1)\r\n");
            } else {
                PRINTF("Tarjeta SDSC detectada (CCS = 0)\r\n");
            }
        } else {
            CS_HIGH();
            spi_receive();
            PRINTF("Error al leer CMD58\r\n");
        }
    } else {
        PRINTF("Fallo en inicialización (ACMD41)\r\n");
    }

    while (1) {
    }
}
