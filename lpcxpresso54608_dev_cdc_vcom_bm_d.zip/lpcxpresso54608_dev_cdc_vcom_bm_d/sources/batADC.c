/*
 * batADC.c
 *
 *  Created on: 20 nov. 2018
 *      Author: Marcelo.Caamaño
 */

#include "fsl_adc.h"
#include "fsl_power.h"
#include "CPU_def.h"
#include <stdbool.h>
/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define DEMO_ADC_BASE ADC0
#define DEMO_ADC_SAMPLE_CHANNEL_NUMBER 0U

/*******************************************************************************
 * Prototypes
 ******************************************************************************/
//static void ADC_Configuration(void);
/*******************************************************************************
 * Variables
 ******************************************************************************/
adc_result_info_t adcResultInfoStruct;

/*******************************************************************************
 * Code
 ******************************************************************************/
static void ADC_Configuration(void) {
	adc_config_t adcConfigStruct;
	adc_conv_seq_config_t adcConvSeqConfigStruct;

	/* Configure the converter. */
#if defined(FSL_FEATURE_ADC_HAS_CTRL_ASYNMODE) & FSL_FEATURE_ADC_HAS_CTRL_ASYNMODE
	adcConfigStruct.clockMode = kADC_ClockSynchronousMode; /* Using sync clock source. */
#endif                                                     /* FSL_FEATURE_ADC_HAS_CTRL_ASYNMODE */
	adcConfigStruct.clockDividerNumber = 1; /* The divider for sync clock is 2. */
#if defined(FSL_FEATURE_ADC_HAS_CTRL_RESOL) & FSL_FEATURE_ADC_HAS_CTRL_RESOL
	adcConfigStruct.resolution = kADC_Resolution12bit;
#endif /* FSL_FEATURE_ADC_HAS_CTRL_RESOL */
#if defined(FSL_FEATURE_ADC_HAS_CTRL_BYPASSCAL) & FSL_FEATURE_ADC_HAS_CTRL_BYPASSCAL
	adcConfigStruct.enableBypassCalibration = false;
#endif /* FSL_FEATURE_ADC_HAS_CTRL_BYPASSCAL */
#if defined(FSL_FEATURE_ADC_HAS_CTRL_TSAMP) & FSL_FEATURE_ADC_HAS_CTRL_TSAMP
	adcConfigStruct.sampleTimeNumber = 0U;
#endif /* FSL_FEATURE_ADC_HAS_CTRL_TSAMP */
#if defined(FSL_FEATURE_ADC_HAS_CTRL_LPWRMODE) & FSL_FEATURE_ADC_HAS_CTRL_LPWRMODE
    adcConfigStruct.enableLowPowerMode = false;
#endif /* FSL_FEATURE_ADC_HAS_CTRL_LPWRMODE */
#if defined(FSL_FEATURE_ADC_HAS_TRIM_REG) & FSL_FEATURE_ADC_HAS_TRIM_REG
    adcConfigStruct.voltageRange = kADC_HighVoltageRange;
#endif /* FSL_FEATURE_ADC_HAS_TRIM_REG */
	ADC_Init(DEMO_ADC_BASE, &adcConfigStruct);

//#if !(defined(FSL_FEATURE_ADC_HAS_NO_INSEL) && FSL_FEATURE_ADC_HAS_NO_INSEL)
	/* Use the temperature sensor input to channel 0. */
	//ADC_EnableTemperatureSensor(DEMO_ADC_BASE, true);
	//si habilito sensor de temperatura el canal 0 queda inhabilitado
//#endif /* FSL_FEATURE_ADC_HAS_NO_INSEL. */
	/* Enable channel DEMO_ADC_SAMPLE_CHANNEL_NUMBER's conversion in Sequence A. */
	adcConvSeqConfigStruct.channelMask = (1U << DEMO_ADC_SAMPLE_CHANNEL_NUMBER); /* Includes channel DEMO_ADC_SAMPLE_CHANNEL_NUMBER. */
	adcConvSeqConfigStruct.triggerMask = 0U;
	adcConvSeqConfigStruct.triggerPolarity = kADC_TriggerPolarityPositiveEdge;
	adcConvSeqConfigStruct.enableSingleStep = false;
	adcConvSeqConfigStruct.enableSyncBypass = false;
	adcConvSeqConfigStruct.interruptMode = kADC_InterruptForEachSequence;
	ADC_SetConvSeqAConfig(DEMO_ADC_BASE, &adcConvSeqConfigStruct);
	ADC_EnableConvSeqA(DEMO_ADC_BASE, true); /* Enable the conversion sequence A. */
	/* Clear the result register. */
	ADC_DoSoftwareTriggerConvSeqA(DEMO_ADC_BASE);
	while (!ADC_GetChannelConversionResult(DEMO_ADC_BASE,
			DEMO_ADC_SAMPLE_CHANNEL_NUMBER, &adcResultInfoStruct)) {
	}
	ADC_GetConvSeqAGlobalConversionResult(DEMO_ADC_BASE, &adcResultInfoStruct);
}

void batADC_ClockPower_Configuration(void) {
	/* SYSCON power. */
	POWER_DisablePD(kPDRUNCFG_PD_VDDA); /* Power on VDDA. */
	POWER_DisablePD(kPDRUNCFG_PD_ADC0); /* Power on the ADC converter. */
	POWER_DisablePD(kPDRUNCFG_PD_VD2_ANA); /* Power on the analog power supply. */
	POWER_DisablePD(kPDRUNCFG_PD_VREFP); /* Power on the reference voltage source. */
	POWER_DisablePD(kPDRUNCFG_PD_TS); /* Power on the temperature sensor. */

	/* Enable the clock. */
	//CLOCK_AttachClk(kFRO12M_to_MAIN_CLK);
	/* CLOCK_AttachClk(kMAIN_CLK_to_ADC_CLK); */
	/* Sync clock source is not used. Using sync clock source and would be divided by 2.
	 * The divider would be set when configuring the converter.
	 */

	CLOCK_EnableClock(kCLOCK_Adc0); /* SYSCON->AHBCLKCTRL[0] |= SYSCON_AHBCLKCTRL_ADC0_MASK; */

#if !(defined(FSL_FEATURE_ADC_HAS_NO_CALIB_FUNC) && FSL_FEATURE_ADC_HAS_NO_CALIB_FUNC)
#if defined(FSL_FEATURE_ADC_HAS_CALIB_REG) && FSL_FEATURE_ADC_HAS_CALIB_REG
	/* Calibration after power up. */
	if (ADC_DoSelfCalibration(
			DEMO_ADC_BASE))
#else
    uint32_t frequency;
#if defined(SYSCON_ADCCLKDIV_DIV_MASK)
    frequency = CLOCK_GetFreq(DEMO_ADC_CLOCK_SOURCE) / CLOCK_GetClkDivider(kCLOCK_DivAdcClk);
#else
    frequency = CLOCK_GetFreq(DEMO_ADC_CLOCK_SOURCE);
#endif /* SYSCON_ADCCLKDIV_DIV_MASK */
    /* Calibration after power up. */
    if (ADC_DoSelfCalibration(DEMO_ADC_BASE, frequency))
#endif /* FSL_FEATURE_ADC_HAS_CALIB_REG */
			{
#ifdef DEBUG
		printf("ADC_DoSelfCalibration() Done.\r\n");
#endif
	} else {
#ifdef DEBUG
		printf("ADC_DoSelfCalibration() Failed.\r\n");
#endif
	}
#endif /* FSL_FEATURE_ADC_HAS_NO_CALIB_FUNC */
	ADC_Configuration();

}

//True: BAT OK, flase: BAT NO OK
bool batADC_ADQ_OK(void) {
	//uint32_t resultado;

	ADC_DoSoftwareTriggerConvSeqA(DEMO_ADC_BASE);
	/* Wait for the converter to be done. */
	while (!ADC_GetChannelConversionResult(DEMO_ADC_BASE,
			DEMO_ADC_SAMPLE_CHANNEL_NUMBER, &adcResultInfoStruct)) {
	}
	// printf("adcResultInfoStruct.result        = %d\r\n", adcResultInfoStruct.result);
	// printf("adcResultInfoStruct.channelNumber = %d\r\n", adcResultInfoStruct.channelNumber);
	// printf("adcResultInfoStruct.overrunFlag   = %d\r\n", adcResultInfoStruct.overrunFlag ? 1U : 0U);

	if ((!adcResultInfoStruct.overrunFlag)
			&& (adcResultInfoStruct.result < 800))
		return false; //todo ver valor!

	return true;
}

uint32_t batADC_ADQ(void) {
	//uint32_t resultado;

	ADC_DoSoftwareTriggerConvSeqA(DEMO_ADC_BASE);
	/* Wait for the converter to be done. */
	while (!ADC_GetChannelConversionResult(DEMO_ADC_BASE,
			DEMO_ADC_SAMPLE_CHANNEL_NUMBER, &adcResultInfoStruct)) {
	}
	// printf("adcResultInfoStruct.result        = %d\r\n", adcResultInfoStruct.result);
	// printf("adcResultInfoStruct.channelNumber = %d\r\n", adcResultInfoStruct.channelNumber);
	// printf("adcResultInfoStruct.overrunFlag   = %d\r\n", adcResultInfoStruct.overrunFlag ? 1U : 0U);

	if (!adcResultInfoStruct.overrunFlag)
		return (adcResultInfoStruct.result << 12); //todo adquiero con 12 bits, y lo paso a 24
	// if(!adcResultInfoStruct.overrunFlag) return  (adcResultInfoStruct.result<<8); //todo adquiero con 12 bits, y lo paso a 23

	return 0;
}

