/*
 * lowcntrl.c
 *
 *  Created on: 2 ago. 2018
 *      Author: Marcelo.Caamaño
 */
#include "CPU_def.h"

#include "core_cm4.h" //reset?
#include "fsl_device_registers.h" //eeprom
#include "fsl_eeprom.h"
#include "fsl_wwdt.h"
#include "fsl_power.h"
/*******************************************************************************
 * Prototypes
 ******************************************************************************/
#define FSL_FEATURE_EEPROM_PAGE_SIZE (FSL_FEATURE_EEPROM_SIZE/FSL_FEATURE_EEPROM_PAGE_COUNT)
#define EEPROM_SOURCE_CLOCK kCLOCK_BusClk
#define EEPROM_CLK_FREQ CLOCK_GetFreq(kCLOCK_BusClk)

//extern __Timing Timing;
extern volatile uint32_t delay; //para el timer de 1mSeg

void __disable_interrupt(void) {
	__disable_irq();
}
;
//TODO implementar
void __enable_interrupt(void) {
	__enable_irq();
}
;
//TODO implementar

/* Copia en el main el estado de los bits de control de la int periódica
 ***********************************************************************/
void lowRtcUpDate(void) {
	__disable_interrupt(); // TODO definirla MAC!
	if (Timing.Bits.Pps)
		Timing.Bits.PpsCopy = 1;
	if (Timing.Bits.Ppm)
		Timing.Bits.PpmCopy = 1;
	Timing.Bits.Pps = 0;
	Timing.Bits.Ppm = 0;
	__enable_interrupt();
}

/* Lee una página de Flash y la salva en el banco 7 de ram. Son páginas de 64 bytes.
 * Se ingresa con el número de página que puede ser de 0 a 3f. -- ahora podria ser mas
 * Para config de IO
 ***********************************************************************/
void lowRdPage(uint32_t PageNum) {
	uint32_t j;
	uint32_t eepromData;
	PageNum += 64u; //offset para direccionar a seccion de memoria de IO
	for (j = 0; j < 32; j++) //FSL_FEATURE_EEPROM_PAGE_SIZE/4
			{
		eepromData = *((uint32_t*) (FSL_FEATURE_EEPROM_BASE_ADDRESS
				+ PageNum * FSL_FEATURE_EEPROM_PAGE_SIZE + j * 4));
		Buffer.Variable[j].Value = eepromData;
	}
	/*  TODO implementar, leer pagina de la flash
	 *
	 char Cnt;
	 unsigned short FlashAd;
	 __psw_bits PswTmp;
	 FlashAd=(PageNum<<7)+ConfigIni;
	 if (__PSW_bit.gie)PswTmp.gie=1;
	 __disable_interrupt();
	 __read_flash_block ((unsigned short)&Buffer.Variable[0], FlashAd, 64);

	 for (Cnt=0; Cnt<200; Cnt++){};
	 if(PswTmp.gie)__PSW_bit.gie=1;
	 */
}
;

/* Lee una página de Flash del uC (CPU) y la salva en Variable.
 Se leen 64 bytes, las paginas en realidad son de 128 bytes
 Se ingresa con el número de página que puede ser de 0 a f.
 Dir Pag Inicial: 0x6000
 Para cnfig de CPU
 ***********************************************************************/
void lowRdPageC(uint32_t PageNum) {
	//TODO implementar (ver si es lo mismo que en IO o cambia)
	uint32_t j;
	uint32_t eepromData;
	if (PageNum <= 64u) {

		for (j = 0; j < 32; j++) //FSL_FEATURE_EEPROM_PAGE_SIZE/4
				{
			//Variable[j].Value=*((uint32_t *)(FSL_FEATURE_EEPROM_BASE_ADDRESS + PageNum * FSL_FEATURE_EEPROM_PAGE_SIZE + j * 4));
			eepromData = *((uint32_t*) (FSL_FEATURE_EEPROM_BASE_ADDRESS
					+ PageNum * FSL_FEATURE_EEPROM_PAGE_SIZE + j * 4));
			Variable[j].Value = eepromData;
		}
	} else {
#ifdef DEBUG
		printf("error lowRdPageC");
#endif
	}
	//unsigned short FlashAd;
	//FlashAd=(PageNum<<7)+ConfigIni;

	//__disable_interrupt();
	//__read_flash_block ((unsigned short)&Variable[0], FlashAd, 64);
	//__enable_interrupt();

	/*   if(PageNum == 2)
	 {
	 Variable[4].Value = (unsigned short)PtrTxTxed.page;
	 Variable[5].Value = (unsigned short)PtrTxTxed.offset;
	 Variable[6].Value = (unsigned short)PtrEvTxed.page;
	 Variable[7].Value = (unsigned short)PtrEvTxed.offset;
	 memRdCfgFlash(18);   // Cfg Pag Eventos
	 Variable[8].Value = (unsigned short)cfgReg.pageIni;
	 Variable[9].Value = (unsigned short)cfgReg.pageFin;
	 Variable[10].Value = (unsigned short)cfgReg.pagePast;
	 Variable[11].Value = (unsigned short)cfgReg.offsetPast;
	 Variable[12].Value = (unsigned short)cfgReg.offsetFin;
	 Variable[13].Value = (unsigned short)cfgReg.offsetTime;
	 }
	 */
}

/* Calcula el checksum del buffer de flash interna.
 **************************************************
 * Se suman los primeros 63 bytes y se compara con el 64.
 * Si el 64 es igual a la suma, sale con un ok. Si es distinto sale con error.
 *****************************************************************************/
uint8_t lowVfyBuf(void) {
	uint8_t *PtrTmp;
	uint8_t CheckSum;
	uint8_t Resultado = Ok, cnt;

	cnt = 0;
	CheckSum = 0;
	//TODO implementar

	for (PtrTmp = &Buffer.Variable[0].Byte.Lo;
			PtrTmp < &Buffer.Variable[31].Byte.Hi; PtrTmp++) {
		CheckSum += *PtrTmp;
		if (*PtrTmp == 0)
			cnt++;
	}
	if (CheckSum != *PtrTmp)
		Resultado = Bad; // Compara el byte 64 contra la suma de los primeros 63
	else if (cnt > 62)
		Resultado = 0xff;

	return (Resultado);
}

/* Salva una página en EEPROM: cada page tiene 128 bytes (32 palabras de 32 bits, uso sólo 16LSB por palabra)
 -PageNum: 0..63 -> se usa para armar la direccion inicial de Flash = PageNum * 128 + 0x6000
 +PageNum: 0..63 -> se usa para armar la direccion inicial de EEPROM = PageNum * 128 + 0x4010800
 Los datos de origen se encuentra en "Buffer"
 Pagina de IO (0x40 a 0x7e)en eeprom
 ***************************************************************************************/
void lowWrPage(uint32_t PageNum) {
	uint8_t *ptr, CheckTmp;
	uint32_t Cnt;

	ptr = &Buffer.Variable[0].Byte.Lo;
	CheckTmp = 0;
	for (Cnt = 0; Cnt < 63; Cnt++)
		CheckTmp += ptr[Cnt];
	Buffer.Variable[31].Byte.Hi = CheckTmp;
	//__psw_bits PswTmp;
	if (PageNum < 64u) {
		PageNum += 64u;
		EEPROM_WritePage16(EEPROM, PageNum, (uint16_t*) Buffer.Variable);
	} else {
#ifdef DEBUG
		printf("error EEP page: %d", PageNum);
#endif
	}
	/*unsigned short FlashAd;   // Flash Address
	 unsigned short Temp;
	 char CheckTmp;
	 char Cnt, *ptr;
	 //TODO implementar

	 ptr = &Buffer.Variable[0].Byte.Lo;
	 CheckTmp = 0;
	 for(Cnt=0; Cnt<63; Cnt++)   CheckTmp += ptr[Cnt];
	 Buffer.Variable[31].Byte.Hi = CheckTmp;

	 FlashAd=(PageNum<<7)+ConfigIni; // PageNum * 128 + 0x6000 = direccion de inicio de la pagina
	 PswTmp.gie=__PSW_bit.gie;
	 __disable_interrupt();
	 __page_flash_erase(FlashAd);  // borra los 128 bytes de la pagina
	 for (Cnt=0; Cnt<250; Cnt++){}; // Para que el WD no joda al salir del boot rom
	 // Escribe 4 paquetes de 8 words a partir de FlashAd: total 64 bytes
	 for (CheckTmp=0; CheckTmp<4; CheckTmp++)
	 {
	 Temp=CheckTmp<<4;  // Temp = 16 * CheckTmp
	 FlashPtr = &Buffer.Variable[Temp].Value;  // Datos Origen
	 // Escribe 1 paquete de 8 Words, 16 bytes
	 __write_flash_block(FlashAd, (unsigned short)&Buffer.Variable[CheckTmp<<3].Value, 16);
	 for (Cnt=0; Cnt<250; Cnt++){};
	 FlashAd = FlashAd+16;
	 for (Cnt=0; Cnt<250; Cnt++){};
	 }
	 __PSW_bit.gie = PswTmp.gie;
	 */
}

/* Salva una página en EEPROM: cada page tiene 128 bytes (32 palabras de 32 bits, uso sólo 16LSB por palabra)
 * Se ingresa con el número de página de 0 a f.
 *  Pagina de CPU (0 a 0x40) en EEPROM
 ***************************************************************************************/
void lowWrPageC(uint32_t PageNum) {
	//TODO implementar (es la del CPU)
	if (PageNum <= 64u) {

		EEPROM_WritePage16(EEPROM, PageNum, (uint16_t*) Variable);
	} else {
#ifdef DEBUG
		printf("error lowWrPageC");
#endif
	}
	/* unsigned short FlashAd;
	 unsigned short Temp;
	 char CheckTmp;

	 FlashAd=(PageNum<<7)+ConfigIni; // FlashAd=0X6000+PageNum*128

	 __page_flash_erase(FlashAd);
	 for (CheckTmp=0; CheckTmp<4; CheckTmp++){
	 Temp=CheckTmp<<4; // Temp=CheckTemp *16
	 FlashPtr=&Variable[Temp].Value; // ¿Por qué se necesita esta información?
	 __disable_interrupt();
	 __write_flash_block(FlashAd, (unsigned short)&Variable[CheckTmp<<3].Value, 16); // es por 8 xq son words
	 __enable_interrupt();
	 FlashAd=FlashAd+16;
	 }
	 */
}

/* Funciones de bajo nivel de interface con el AD
 ************************************************/
/* Pequeña función que permite set cada entrada analógica
 enum tipo __canal:   Canal1,Canal2,Canal3,Canal4,Canal5,Canal6,Canal7,Canal8,
 Canal9,Canala,Canalb,Canalc,Canald,Canale,Canal0v,Canal4v,
 CanalOla,CanalPluvi,
 Digit1,Digit2,Digit3,Digit4,Digit5,Digit6,Digit7
 */
void lowSetCanal(__canal Canal) {
	// MX0, MX1, MX2 controlan los canales de los MUX 8:1
	// INEL, INEH: Habilitan los MUX de la placa de Expansion -> no existe mas en la version 2.0
	// INHL=0: Habilita los canales 1 a 8
	// INHH=0: Habilita los canales 15 a 16
	//TODO implementar
	switch (Canal) {
	/*
	 * case Canal1:
	 //__PORTCD_bit.MX0=0;
	 //__PORTBD_bit.MX1=0;
	 //__PORTBD_bit.MX2=0;
	 //__PORTCD_bit.INHH=1;
	 //__PORTCD_bit.INHL=0;
	 break;
	 case Canal2:
	 break;
	 case Canal3:
	 break;
	 case Canal4:
	 break;
	 case Canal5:
	 break;
	 case Canal6:
	 break;
	 case Canal7:
	 break;
	 case Canal8:
	 break;
	 case Canal9:
	 break;
	 case Canal10:
	 break;
	 case Canal11:
	 break;
	 case Canal12:
	 break;
	 */
	case Canal12:
		//todo seleccionar
		CS_AIN_13_Set;
		break;
	case Canal14:
		//todo seleccionar
		CS_AIN_14_Set;
		break;
	case Canal15:
		//todo seleccionar
		CS_AIN_13_Clr;
		break;
	case Canal16:
		//todo seleccionar
		CS_AIN_14_Clr;
		break;
	default:
		break;

	};
}

/* Inicia la UART con los parámetros recibidos
 *********************************************
 * Se declaran las contantes para cada velocidad todas seguidas
 *  según la estructura de BD_300  BAUD PSR
 * Los parámetros seteados en ROM son para 300, 1200, 2400, 4800, 9600, y 19200.
 */
const uint8_t BD_300[] = { 0x01, 0x2C,    //  300
		0x04, 0xB0,    // 1200
		0x09, 0x60,    // 2400
		0x12, 0xc0,    // 4800
		0x25, 0x80,    // 9600
		0x4B, 0x00 };   //19200

/* función para procesar los errores de la UART
 **********************************************
 * Los flags de error, no generan interrupción,
 *  por lo que se miran constantemente y procesan
 ************************************************/
void lowUartError(void) {
	uint32_t Temp;
	uint8_t PSR_tmp, ENU_tmp;
	//TODO procesar bits de error de UART
	/*  if(__ENU_bit.err)
	 {
	 PSR_tmp=__PSR;
	 ENU_tmp=__ENU;

	 __ENU=0x18;
	 __ENUI_bit.ssel=1;
	 for (Temp=0; Temp<0x69; Temp++){};
	 Temp=__ENUR;
	 Temp=__RBUF;
	 __ENUI_bit.ssel=0;
	 __PSR=0;
	 __ENU=ENU_tmp;
	 __PSR=PSR_tmp;
	 BufUart.BufState=HeaderAst;
	 }*/
}

/* UART user callback */
void USART_UserCallback(USART_Type *base, usart_handle_t *handle,
		status_t status, void *userData) {
	userData = userData;

	if (kStatus_USART_TxIdle == status) {
		txBufferFull = false;
		txOnGoing = false;
	}

	if (kStatus_USART_RxIdle == status) {
		rxBufferEmpty = false;
		rxOnGoing = false;
	}
}

void lowUartIni(void) {
	//TODO implementar

	lowUartError();
	//__disable_interrupt();
	//Lee parámetros del puerto Com desde la dir ConfigIni=0X6000, pag 0
	//__read_flash_block((unsigned short)&Com, ConfigIni, 5); //Guarda los primeros 5 bytes en la estructura Com
	//__enable_interrupt();
	lowRdPageC(0); //lee pagina 0, Variable[0].value
	Com.DelayHandShake = (uint8_t) Variable[0].Byte.Hi;
	Com.PunteroBaudRate = (uint8_t) Variable[0].Byte.Lo;
	Com.SinUso = (uint8_t) Variable[1].Value;
	Com.RtuID_hi = (uint8_t) Variable[1].Value >> 8;
	Com.RtuID_lo = (uint8_t) Variable[2].Value;

	//__ENU=0x00;
	//__ENUR=0x00;
	//__ENUI=0x22;  // Alternate Function for L.2 (Tx), Enable Rx Int
// GGB31 - Si se configuro BR distinto a 1200, 9600, 19200 se ajusta 19200
	if ((Com.PunteroBaudRate != 1) && (Com.PunteroBaudRate != 4)
			&& (Com.PunteroBaudRate != 5))
		Com.PunteroBaudRate = 5;

	Com.PunteroBaudRate = Com.PunteroBaudRate << 1;
	//__BAUD = BD_300[Com.PunteroBaudRate];
	//__PSR = BD_300[Com.PunteroBaudRate+1];
	BufUart.BufState = HeaderAst;

	usart_config_t config;
	USART_GetDefaultConfig(&config);
	config.baudRate_Bps = (BD_300[Com.PunteroBaudRate] << 8)
			+ BD_300[Com.PunteroBaudRate + 1];
	config.loopback = false;
	config.parityMode = kUSART_ParityDisabled;
	config.stopBitCount = kUSART_OneStopBit;
	config.bitCountPerChar = kUSART_8BitsPerChar;
	config.enableTx = true;
	config.enableRx = true;

	uint32_t frec = USART_RTU_CLK_FREQ;
	USART_Init(USART_RTU, &config, frec);

	USART_TransferCreateHandle(USART_RTU, &g_uartHandle, USART_UserCallback,
			NULL);
	USART_TransferStartRingBuffer(USART_RTU, &g_uartHandle, g_rx_ring_buffer,
			128);    //USART Receive using the ringbuffer feature
	// USART_TransferStartRingBuffer(USART_RTU, &g_uartHandle, NULL, 14);

	receiveXfer.data = g_rxBuffer;
	receiveXfer.dataSize = 1; //13

	//USART_Init(USART1, &config, frec); //202012 - lo habilito pero no lo estoy usando?

	//TODO habilitar interrupcion de RX
	/* Enable RX interrupt. */
	// USART_EnableInterrupts(USART_RTU, kUSART_RxLevelInterruptEnable | kUSART_RxErrorInterruptEnable);
	// EnableIRQ(USART_RTU_IRQn);
	/* Configure DMA.
	 DMA_Init(EXAMPLE_UART_DMA_BASEADDR);
	 DMA_EnableChannel(EXAMPLE_UART_DMA_BASEADDR, USART_TX_DMA_CHANNEL);
	 DMA_EnableChannel(EXAMPLE_UART_DMA_BASEADDR, USART_RX_DMA_CHANNEL);

	 DMA_CreateHandle(&g_uartTxDmaHandle, EXAMPLE_UART_DMA_BASEADDR, USART_TX_DMA_CHANNEL);
	 DMA_CreateHandle(&g_uartRxDmaHandle, EXAMPLE_UART_DMA_BASEADDR, USART_RX_DMA_CHANNEL);

	 // Create UART DMA handle.
	 USART_TransferCreateHandleDMA(USART_RTU, &g_uartDmaHandle, USART_UserCallback, NULL, &g_uartTxDmaHandle,
	 &g_uartRxDmaHandle);
	 txOnGoing=false;
	 rxOnGoing=false;

	 receiveXfer.data = g_rxBuffer;
	 receiveXfer.dataSize = 13;
	 */
	// __PORTCD_bit.RTS=0;  // RTS off
}

/* Función que inicializa el COM2
 * Set el hard, reinicializa la UART.
 ************************************/
// TODO ver como hacer, ahora no tenemos ese pin de sensado de com conectado. Además tenemos un COM y USB
void lowCom2Proc(void) {
	//if(!__PORTCP_bit.Com2Ack){                  // Cable conectado en COM2 !!!
	/*
	 * if(!UART0_CTS){                  // Cable conectado en COM2 !!!
	 // if (!Status.Com2On) //intraWrSD(0,1);     // La primera vez apaga el Orbcomm
	 // { __PORTED_bit.Ctl_01=1;}  TODO ver, reo que no hace falta
	 Status.Com2On=1;                        // Flag de Com 2 en 1
	 BufUart.TimeOut = 5;                    // TimeOut para apagar el COM2 luego de su desconexion
	 }
	 else */
	if (BufUart.TimeOut)
		BufUart.TimeOut--;
	else if (Status.Com2On) //Luego de un tiempo de inactividad en USB, vuelve a activar el COM2
	{
		Status.Com2On = 0;
		FlagGral.InhTxEvent = 0;
	}
}

/* Funciones que encienden la UART y la apagan
 *********************************************
 * Para bajar el consumo, los drivers de hard, y los pines involucrados,
 *  son seteados en un estado definido, tanto al encenderse como apagarse.
 * La prioridad de comunicación, la tiene el COMM2 que es el utilizado por
 *  la comunicación local. Si hay una agenda activa, y aparece una conexión
 *  en el com2, se pasa al 2. Cuando el 2 termina, vuelve al 1. LA ventana
 *  de comunicación, no se modifica, cuando termina, termina aunque el com2
 *  haya utilizado tod.o el tiempo la UART.
 Los puertos COM se apagan por separado, las señales de control se desactivan
 cuando ambos puertos estan apagados
 Ver si no aumenta el consumo el hecho de tener el MAX232 apagado con entradas en 5V !!!!
 **************************************************************************/
void lowOnOffCom(void) {
	// Acciona alimentaciones y MUX para los puertos COM
	/*    if(Status.Com2On)  // El COM 2 tiene prioridad de encendido
	 {
	 //        __PORTCD_bit.Com1Dis=1; // Power Off COM1, MUX=COM2
	 //        __PORTLD_bit.Com2Dis=0; // Power ON COM2
	 }
	 else if(Status.Com1On) // Enciendo COM 1
	 {
	 //      __PORTCD_bit.Com1Dis=0; // Power on COM1, MUX=COM1
	 //      __PORTLD_bit.Com2Dis=1; // Power off COM2
	 }*/
	//if(Status.Com2On ||Status.Com1On){
	if (Status.Com1On) {
		//no hace nada porque no hay encendido de uart, todo VER
	} else {
		//      __PORTCD_bit.Com1Dis=1; // Power off COM1, MUX=COM2
		//      __PORTLD_bit.Com2Dis=1; // Power off COM2
		//DisableIRQ(USART_RTU_IRQn); //TODO ver: apagar UART
		//USART_EnableRxDMA(USART_RTU,false);
		//LED_R_OFF;
	}

	if (Status.UartOn)  // Verifica APAGADO
	{
		if (!Status.Com1On)  //!Status.Com2On &&
		{
			// __ENU=0x00;
			// __ENUR=0x00;
			// __ENUI = 0;
			// __PORTCD_bit.CTS=0; // es una Entrada ¿?
			// __PORTCD_bit.RTS=0;
			// __ENUI_bit.brk=1;
			// __PORTLD_bit.Rx=0;
			Status.UartOn = 0;

		};
	} else    // Verifica ENCENDIDO
	{
		if (Status.Com1On)    //|| (Status.Com2On)
		{    // Inicializa la UART
			 //   __PORTCD_bit.CTS=0;
			 //   __PORTCD_bit.RTS=1;
			 //   __ENUI_bit.brk=0;
			 //   __PORTLD_bit.Rx=1;
			 //    lowTimer(2);  // Espera 2 milisegundos
			 //  lowUartIni();
			 //USART_EnableRxDMA(USART_RTU,true);
			 //  LED_R_ON;
			Status.UartOn = 1;
			//    __ENUR;          // NO TOCAR ESTA LINEA !!!
			BufUart.BufState = HeaderAst;
		};
	};
}

/*
 * Inicializa La EEPROM
 */
void lowEEPInternaInit(void) {
	/* Init EEPROM */
	eeprom_config_t config;
	EEPROM_GetDefaultConfig(&config);
	EEPROM_Init(EEPROM, &config, (uint32_t) EEPROM_CLK_FREQ);
}

/*
 * Reinicia el CPU escribiendo 0x5FA en VECTKEY (clave para que atienda al pedido) +  SYSRESETREQ
 * */
void lowUCReset(void) {
	SCB->AIRCR = (0x5FA << SCB_AIRCR_VECTKEY_Pos) | SCB_AIRCR_SYSRESETREQ_Msk;
	while (1) {
		//espera hasta el RESET
	};
}

/* Función que espera un tiempo definido usando el TMR2
 ******************************************************/
void lowTimer(uint32_t miliseg) {
	delay = miliseg;
	while (delay) {
	}; //espera delay mseg; delay es decrementado en ctimer_callback_1ms (timer2)
}

void COMTask(void) {
	//uint32_t cuent;
	//status_t estatus;
	size_t receivedBytes;
	/* If RX is idle and g_rxBuffer is empty, start to read data to g_rxBuffer. */
	if (Status.UartOn && (Status.Com2On == 0) //Com2On se pone en 1 con la transferencia por USB. Deshabilitando comunicacion por COM, por un rato.
			//&&StatusIO.Vacio //(StatusIO.Alimentar==0)  //MAC2019 probando si asi deja de borrar datos duarnate adquisicion \\MAC2020 creo que impedia transmision en ciertos casos
			) {
		//if(Status.UartOn){
		if ((!rxOnGoing) && rxBufferEmpty) {
			rxOnGoing = true;
			//receiveXfer.dataSize=128;
			//estatus=USART_TransferGetReceiveCountDMA(USART_RTU, &g_uartDmaHandle,&cuent);
			// memset(g_rxBuffer, 0, 13);
			//receiveXfer.dataSize=cuent;

			//USART_TransferReceiveDMA(USART_RTU, &g_uartDmaHandle, &receiveXfer);
			//if (cuent>13){
			//	rxOnGoing = false;
			//	USART_TransferAbortReceiveDMA(USART_RTU, &g_uartDmaHandle);}

			USART_TransferReceiveNonBlocking(USART_RTU, &g_uartHandle,
					&receiveXfer, &receivedBytes);

			if (1 == receivedBytes) {
				rxBufferEmpty = false;
				rxOnGoing = false;
			} else
				contadorUART = 3; //MAC2020 encontre que no se determinaba nunca su valor.
			// else if (receivedBytes && (13 > receivedBytes))
			//contadorUART=3;
			// 	   {
			//	               printf("recvd: %d \r\n",receivedBytes);
			//	   	   	   	   rxBufferEmpty = false;
			//	               rxOnGoing = false;
			//	               USART_TransferStopRingBuffer(USART_RTU, &g_uartHandle);
			//	               USART_TransferStartRingBuffer(USART_RTU, &g_uartHandle, g_rx_ring_buffer, 256);
			//	            }

		}

		/* If TX is idle and g_txBuffer is full, start to send data.
		 if ((!txOnGoing) && txBufferFull)
		 {
		 txOnGoing = true;
		 USART_TransferSendDMA(USART_RTU, &g_uartDmaHandle, &sendXfer);
		 }*/

		/* If g_txBuffer is empty and g_rxBuffer is full, copy g_rxBuffer to g_txBuffer. */
		if (!rxBufferEmpty)	          // && (!txBufferFull))
		{

			//int32_t i;
			//estatus=USART_TransferGetReceiveCountDMA(USART_RTU, &g_uartDmaHandle,&cuent);
			/* Copy Buffer to Send Buff */
			intProcUART(g_rxBuffer[0]);
			/*	        	if(g_rxBuffer[0]!='*'){
			 printf("* \r\n");
			 rxBufferEmpty = true;
			 g_uartHandle.rxRingBufferHead=0U;
			 g_uartHandle.rxRingBufferTail=0U;
			 return;
			 }

			 for (i = 0; i < 13 ; i++)
			 {

			 intProcUART(g_rxBuffer[i]);
			 //  if(i && BufUart.BufState==HeaderAst){
			 //	  USART_TransferAbortReceiveDMA(USART_RTU, &g_uartDmaHandle);
			 //	  break;
			 //     }
			 }
			 */
			//memcpy(g_txBuffer, g_rxBuffer, ECHO_BUFFER_LENGTH);
			// memset(g_rxBuffer, 0, 13);
			rxBufferEmpty = true;
			//txBufferFull = true;
		}
	} else { //descarta los datos
			 //USART_TransferAbortReceiveDMA(USART_RTU, &g_uartDmaHandle);
		rxBufferEmpty = true;
		rxOnGoing = false;
		txOnGoing = false;
		txBufferFull = false;
	}

}

uint32_t lowWatchDogInit(void) {

	uint32_t wdtFreq, huboReset;
	huboReset = 0;

	// CLOCK_EnableClock(kCLOCK_Gpio0);
	// CLOCK_EnableClock(kCLOCK_Gpio2);

#if !defined (FSL_FEATURE_WWDT_HAS_NO_PDCFG) || (!FSL_FEATURE_WWDT_HAS_NO_PDCFG)
	POWER_DisablePD(kPDRUNCFG_PD_WDT_OSC);
#endif
	/* The WDT divides the input frequency into it by 4 */
	wdtFreq = CLOCK_GetFreq(kCLOCK_WdtOsc) / 4;

	WWDT_GetDefaultConfig(&configWWDT);
	/* Check if reset is due to Watchdog */
	if (WWDT_GetStatusFlags(WWDT) & kWWDT_TimeoutFlag) {
		//LED_RED_ON();
		huboReset = 1;
#ifdef DEBUG
		printf("hubo reset por WatchDogr\n");
#endif
		LED_R_TOGGLE;
	}
	/*
	 * Set watchdog feed time constant to approximately 10s
	 * Set watchdog warning time to 512 ticks after feed time constant
	 * Set watchdog window time to 1s
	 */
	configWWDT.timeoutValue = wdtFreq * 30;
	configWWDT.warningValue = 0;	//512;
	configWWDT.windowValue = 0xFFFFFF;	// wdtFreq * 1;
	/* Configure WWDT to reset on timeout */
#ifndef DEBUG
	 configWWDT.enableWatchdogReset = true;
	#else
	configWWDT.enableWatchdogReset = false;
#endif
	/* wdog refresh test in window mode */
#ifdef DEBUG
	printf("\r\n-inicia WD-\r\n");
#endif
	WWDT_Init(WWDT, &configWWDT);
	NVIC_EnableIRQ(WDT_BOD_IRQn);
	/* First feed will start the watchdog */
	WWDT_Refresh(WWDT);

	return huboReset;
}
