/*
 * SDI12.c
 *
 *  Created on: 20 ene. 2021
 *      Author: Marcelo.Caamaño
 */
//#include "core_cm4.h" //reset?
#include "CPU_def.h"

enum {
	search_, measure_, waiting_, data_, wait_, clean_
};
//estados para el SDI12
extern uint32_t TMR_SDI;
extern void chCalcHay(void);
//extern void  chCalcHay(void);
void SDI_12procesar(uint8_t *recv, uint8_t cant);

#define RING_BUFFER_SDI_SIZE 64
#define RX_SDI_DATA_SIZE     4  //era4

usart_handle_t g_SDIusartHandle;
usart_transfer_t receiveSDIXfer;
usart_transfer_t sendSDIXfer;

volatile bool rxSDIOnGoing = false;
volatile bool rxSDIBufferEmpty = true;
volatile bool txSDIFinished;

uint8_t receiveDataSDI[RX_SDI_DATA_SIZE];
uint8_t ringBufferSDI[RING_BUFFER_SDI_SIZE];
#define COLA_SIZE 64
uint8_t colaSdi[COLA_SIZE];  //ojo que si usara comandos R el máximo es 75
volatile uint32_t indiceCola = 0;

uint32_t indiceSDI12; //hacerlo global
__Tipo *TipoPtrSDI;  //ver si global
__Analogico *ChPtrSDI; //ver si global
uint32_t SDI12status;
uint32_t SDIReintentar = 2;

//uint16_t Pagina[16]={0,1,2,3,4,5,6,7,8,9,10,11,12,13,0x15,0x16}; //valor de Page para cada canal
//uint32_t pPagina; //puntero a Pagina

void USART_SDI_UserCallback(USART_Type *base, usart_handle_t *handle,
		status_t status, void *userData) {
	userData = userData;
	// ver https://community.nxp.com/t5/Kinetis-Microcontrollers/MKL26Z256-UART-RX-callback-get-ring-buffer-overflow-but-not-RX/td-p/959833

	if (kStatus_USART_RxIdle == status) {
		rxSDIOnGoing = false;
		rxSDIBufferEmpty = false;
	}
	if (kStatus_USART_TxIdle == status) {
		txSDIFinished = true;
	}
}

void SDIUSART_SendBreak(USART_Type *base) {

	/*para pruebas*/
	// WWDT_Deinit(WWDT);
	// configWWDT.enableWatchdogReset=false;
	// WWDT_Init(WWDT,&configWWDT);
	// WWDT_Refresh(WWDT);
	uint32_t tem_p;
	tem_p = base->CFG;
	base->CFG &= ~(USART_CFG_ENABLE_MASK);
	base->CFG |= ((1 << USART_CFG_TXPOL_SHIFT) | USART_CFG_ENABLE_MASK); //pone CFG->TXPOL=1 invertido
	WWDT_Refresh(WWDT);
	lowTimer(12);
	base->CFG &= ~(USART_CFG_ENABLE_MASK);
	base->CFG &= ~(1 << USART_CFG_TXPOL_SHIFT); //pone CFG->TXPOL=1 invertido
	base->CFG |= USART_CFG_ENABLE_MASK;
	lowTimer(9);
}

void SDIUSART_RXset(USART_Type *base, bool ENABLE_) {
	/*
	 * Para silenciar RX mientras transmito. Perdia la RTTA. Lo deshabilté
	 * if(ENABLE_){
	 printf("H");
	 base->FIFOCFG |= USART_FIFOCFG_EMPTYRX_MASK | USART_FIFOCFG_ENABLERX_MASK;
	 // setup trigger level
	 base->FIFOTRIG &= ~(USART_FIFOTRIG_RXLVL_MASK);
	 base->FIFOTRIG |= USART_FIFOTRIG_RXLVL(0);
	 // enable trigger interrupt
	 base->FIFOTRIG |= USART_FIFOTRIG_RXLVLENA_MASK;
	 }
	 else{
	 printf("D");
	 base->FIFOCFG |= USART_FIFOCFG_EMPTYRX_MASK;
	 base->FIFOCFG &= ~USART_FIFOCFG_ENABLERX_MASK;
	 }
	 */
}

void SDI_lowUartIni(void) { //llamarla al inicio 

	usart_config_t config;
	USART_GetDefaultConfig(&config);
	config.baudRate_Bps = 1200;
//  config.loopback=false;
	config.parityMode = kUSART_ParityEven;
	config.stopBitCount = kUSART_OneStopBit;
	config.bitCountPerChar = kUSART_7BitsPerChar;
	config.enableTx = true;
	config.enableRx = true;

	uint32_t frec = USART_SDI_CLK_FREQ;
	USART_Init(USART_SDI, &config, frec);

	USART_TransferCreateHandle(USART_SDI, &g_SDIusartHandle,
			USART_SDI_UserCallback, NULL);
	USART_TransferStartRingBuffer(USART_SDI, &g_SDIusartHandle, ringBufferSDI,
			RING_BUFFER_SDI_SIZE);
	// Now the RX is working in background, receive in to ring buffer.

	receiveSDIXfer.data = receiveDataSDI;
	receiveSDIXfer.dataSize = 1; //RX_SDI_DATA_SIZE; //13
	// rxSDIFinished=false;
	SDIUSART_RXset(USART_SDI, 1);
//     uint8_t ch=0x33;
//     while(1){
//      USART_WriteBlocking(USART_SDI, &ch, 1);
//      WWDT_Refresh(WWDT);
//     }
}

void SDI_Task(void) {  //llamarla periodicamente en main
	size_t receivedBytes;

	if ((!rxSDIOnGoing) && rxSDIBufferEmpty) {
		rxSDIOnGoing = true;
		//printf("rx");
		USART_TransferReceiveNonBlocking(USART_SDI, &g_SDIusartHandle,
				&receiveSDIXfer, &receivedBytes);
		if (receivedBytes) {
			//printf("rx ");
			//printf("%s",receiveDataSDI);
			rxSDIBufferEmpty = false;
			rxSDIOnGoing = false;
			//rxSDIFinished=false;
		}
	}
	if (!rxSDIBufferEmpty) {
		if (indiceCola < COLA_SIZE) {
			colaSdi[indiceCola] = receiveDataSDI[0];
			indiceCola++;
			//printf("R_%c",receiveDataSDI[0]);
			if (indiceCola > 1)
				if ((0x0A == receiveDataSDI[0])
						&& (0x0D == colaSdi[indiceCola - 2])) {
					//printf("S_ %s , %d ",colaSdi,indiceCola);
					if (indiceCola > 3)
						SDI_12procesar(colaSdi, indiceCola);
					indiceCola = 0;
				}
			//if((indiceCola>3) && (0x0A == receiveDataSDI[0])&& (0x0D == colaSdi[indiceCola-2]))
			//{
			//	printf("\n %s",colaSdi);
			//	SDI_12procesar(colaSdi,indiceCola);
			//	indiceCola=0;
			//}
		}
		//SDI_12procesar(receiveDataSDI,receivedBytes);
		rxSDIBufferEmpty = true;
	}
}

void SDI_12sendCommand(uint8_t address, uint8_t command, uint8_t command1)
/*
 * address command command1(optional) ! 
 */
{
	uint32_t i = 0;
	uint8_t sendDataSDI[4]; //aCn!<CR><LF>
	SDIUSART_RXset(USART_SDI, 0);
	sendDataSDI[i] = address;
	sendDataSDI[++i] = command;
	if (0 != command1)
		sendDataSDI[++i] = command1;
	sendDataSDI[++i] = '!';
	//sendDataSDI[++i]=0x0D; NO!
	//sendDataSDI[++i]=0x0A; NO!
	// Prepare to send.
	sendSDIXfer.data = sendDataSDI;
	sendSDIXfer.dataSize = ++i;    //sizeof(sendData);
	txSDIFinished = false;

	indiceCola = 0; //preparo el inidce para recibir
	// Send out.
	CS_SDI12_txENA;
	SDIUSART_SendBreak(USART_SDI);
	//USART_TransferSendNonBlocking(USART_SDI, &g_SDIusartHandle, &sendSDIXfer);
	//while(!txSDIFinished){}; //espera que termine de transmitir
	USART_WriteBlocking(USART_SDI, &sendDataSDI[0], i);
	SDIUSART_RXset(USART_SDI, 1);

	// Prepare to receive.
	CS_SDI12_txDIS;
	printf(" %s, ", sendDataSDI);
	// receiveSDIXfer.data = receiveDataSDI;
	// receiveSDIXfer.dataSize = 1;//sizeof(receiveData);

	//rxSDIFinished = false;
//    uint8_t ch;
//    while(1){
//    	USART_ReadBlocking(USART_SDI, &ch, 1);
//    	printf("%c",ch);
//    	WWDT_Refresh(WWDT);
//    }
}

void SDI_12procesar(uint8_t *recv, uint8_t cant) {
	uint32_t i = 0;
	int32_t dato = 0, signo = 1;
	uint8_t cuenta = 0;
	ChPtr = ChPtrSDI;

	switch (SDI12status) {
	case (measure_):
		//printf("measure_");
		if (ChPtr->TSDI12.SDI12_Add == recv[0]) {
			if (cant > 6) {
				//printf("TMR: %d, %d, %d, %d",recv[cant-6]-0x30,recv[cant-5]-0x30,recv[cant-4]-0x30,recv[cant-3]-0x30);
				TMR_SDI = 1000 * (recv[cant - 6] - 0x30)
						+ 100 * (recv[cant - 5] - 0x30)
						+ 10 * (recv[cant - 4] - 0x30)
						+ (recv[cant - 3] - 0x30);
				//n=recv[4]; no se usa
				if (TMR_SDI > 9999)
					TMR_SDI = 999; //error
				//TMR_SDI++;
				SDI12status = wait_;
			}
		}
		break;
	case (data_):
		printf("d_");
		if (ChPtr->TSDI12.SDI12_Add == recv[0]) {
			for (i = 1; i < cant; i++) {
				//busco en la cadena el comienzo del dato que necesito
				if ((recv[i] == '+') || (recv[i] == '-')) {
					cuenta++;
					if (cuenta == ChPtr->TSDI12.SDI12comandoDatPos)
						break;
				}
			}
			if (i == cant)
				return; //error, sale como si no hubiera llegado dato
			//i++;
			if (recv[i] == '-')
				signo = -1;
			i++;
			//convierto de string a int
			for (; (recv[i] > 0x2D) && (recv[i] < 0x3A); i++) //solo numeros, no debería haber drama con el último dato porque SDI12 vienr con \cr \lf
					{
				if (i > cant)
					return; //error, sale como si no hubiera llegado dato
				if (recv[i] < 0x30)
					continue; //saltea punto decimal
				dato = (dato * 10) + (int32_t) (recv[i] - 0x30);
			}
			//if(signo == -1) dato=-dato;
			dato = dato * signo;
			printf("r: %d \n", dato);

			if (dato < 0)
				dato = 32768 + dato; //dato = 65535 + dato; //conversion a negativo¿?

			i = Canal1;
			InstAD.Ptr = &InstAD.Canal1;
			for (; i < indiceSDI12; i++)
				InstAD.Ptr++;

			*InstAD.Ptr = dato;
			// Se acumula la ultima medicion ( chMedSDI12() )

			ChPtr->TSDI12.SumaMed += *InstAD.Ptr;  //HACER un TSDI12
			ChPtr->TSDI12.CntMed++;

			if (i <= 0x0d)
				Page = i; //Paginas  0 a 13 : EA1-EA14  TODO ver, creo que no hace falta
			else
				Page = i + 0x08;  //Paginas 21 y 22 : EA15-EA16

			chCalcHay();

			ChPtr->Flags.Apagar = 1;
			HAB_5V_OpAmp_OFF; //apaga conversor SDI12
			SDIUSART_RXset(USART_SDI, 1);
			SDIReintentar = 0;
			SDI12status = clean_;
			//printf("s");
		}
		break;
	default:
		//printf("err");
		break;

	}
}

void SDI12_motor(void) {

	static __Analogico *AnaPtr[16] = { &Analogico1, &Analogico2, &Analogico3,
			&Analogico4, &Analogico5, &Analogico6, &Analogico7, &Analogico8,
			&Analogico9, &Analogico10, &Analogico11, &Analogico12, &Analogico13,
			&Analogico14, &Analogico15, &Analogico16 };   // Puntero a canal

	// printf("SDI: %04d \r\n", SDI12status);
	// HAB_5V_OpAmp_ON; //enciende conversor de nivel
	// SDI_12sendCommand('1','M','0');
	// lowTimer(2000);
	// return;

	switch (SDI12status) {
	case (search_):
		//pPagina=0;
		//printf("s_");
		for (indiceSDI12 = Canal1; indiceSDI12 <= Canal16; indiceSDI12++) //recorre los canales buscando SDI12
				{
			TipoPtrSDI = &Tipo[indiceSDI12];
			ChPtrSDI = AnaPtr[indiceSDI12];
			//pPagina++;

			if (ChPtrSDI->Flags.On) //canal habilitado
				if ((*TipoPtrSDI) == SDI12) //canal es SDI12
						{
					if (ChPtrSDI->Flags.Medir) {
						printf("SDI_m %d", indiceSDI12);
						HAB_5V_OpAmp_ON; //enciende conversor de nivel
						// CS_SDI12_txENA; // habilita TX
						//enviar el comando Medir   aM! ó aMx!
						SDI_12sendCommand(ChPtrSDI->TSDI12.SDI12_Add,
								ChPtrSDI->TSDI12.SDI12comandoMed1,
								ChPtrSDI->TSDI12.SDI12comandoMed2); //TODO implementar<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
						//ChPtrSDI->Flags.Medir=0;
						SDIReintentar = 2;
						SDI12status = measure_;
						TMR_SDI = 5;
						break; //sale del for
					}
				}
		}
		break;
	case (measure_):
	case (data_):
		//printf("mOd_");
		if (0 == TMR_SDI) //no recibio respuesta
				{
			printf("SDI_no Rtta \n");
			SDIReintentar--;

			//TODO: Grabar error en canal
			SDI12status = clean_;
		}
		break;
	case (wait_):
		//printf("w");
		if (0 == TMR_SDI) {
			printf("SDI_d");
			//enviar el comando pedir DATO  aDx!
			SDI_12sendCommand(ChPtrSDI->TSDI12.SDI12_Add, 'D',
					ChPtrSDI->TSDI12.SDI12comandoDat1);
			TMR_SDI = 5;
			SDI12status = data_;
		}
		break;
	case (clean_):
		//printf("R_");
		if (0 == SDIReintentar) {
			//printf("clean_");
			ChPtrSDI->Flags.Medir = 0;
			ChPtrSDI->Flags.Apagar = 1;
			HAB_5V_OpAmp_OFF; //apaga conversor SDI12
			SDIUSART_RXset(USART_SDI, 1);
		}
		SDI12status = search_;
		break;
	default:
		//printf("E_%d",SDI12status);
		break;
	}

}

