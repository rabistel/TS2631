/*
 * Copyright (c) 2016, Freescale Semiconductor, Inc.
 * Copyright 2016-2019 NXP
 * All rights reserved.
 *
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

/*******************************************************************************
 * Includes
 ******************************************************************************/

#include "lwip/src/include/lwip/opt.h"

#if LWIP_IPV4 && LWIP_RAW

#include "lwip/contrib/apps/ping/ping.h"
#include "lwip/src/include/lwip/timeouts.h"
#include "lwip/src/include/lwip/init.h"
#include "lwip/src/include/netif/ethernet.h"
#include "lwip/port/enet_ethernetif.h"

#include "board.h"

#include "pin_mux.h"
#include <stdbool.h>
/*******************************************************************************
 * Definitions
 ******************************************************************************/

/* IP address configuration. */
#define configIP_ADDR0 10
#define configIP_ADDR1 0
#define configIP_ADDR2 10
#define configIP_ADDR3 200

/* Netmask configuration. */
#define configNET_MASK0 255
#define configNET_MASK1 255
#define configNET_MASK2 255
#define configNET_MASK3 0

/* Gateway address configuration. */
#define configGW_ADDR0 10
#define configGW_ADDR1 0
#define configGW_ADDR2 10
#define configGW_ADDR3 1

/* MAC address configuration. */
#define configMAC_ADDR                     \
		{                                      \
	0x02, 0x12, 0x13, 0x10, 0x15, 0x11 \
		}

/* Address of PHY interface. */
#ifndef EXAMPLE_PHY_ADDRESS
#ifndef BOARD_ENET0_PHY_ADDRESS
#define BOARD_ENET0_PHY_ADDRESS (0x00U)
#endif
#define EXAMPLE_PHY_ADDRESS BOARD_ENET0_PHY_ADDRESS
#endif

/* System clock name. */
#define EXAMPLE_CLOCK_NAME kCLOCK_CoreSysClk

/* Memory not usable by ENET DMA. */
#define NON_DMA_MEMORY_ARRAY \
		{                        \
	{0x0U, 0x80000U},    \
	{                    \
		0x0U, 0x0U       \
	}                    \
		}

#ifndef EXAMPLE_NETIF_INIT_FN
/*! @brief Network interface initialization function. */
#define EXAMPLE_NETIF_INIT_FN ethernetif0_init
#endif /* EXAMPLE_NETIF_INIT_FN */

/*!
 * @brief Interrupt service for SysTick timer.
 */
//void SysTick_Handler(void) {
//	time_isr();
//}
void comunicacion_rj45(void) {
	static struct netif netif;
#if defined(FSL_FEATURE_SOC_LPC_ENET_COUNT) && (FSL_FEATURE_SOC_LPC_ENET_COUNT > 0)
	static mem_range_t non_dma_memory[] = NON_DMA_MEMORY_ARRAY;
#endif /* FSL_FEATURE_SOC_LPC_ENET_COUNT */
	ip4_addr_t netif_ipaddr,
	netif_netmask, netif_gw;
	ethernetif_config_t enet_config = { .phyAddress = EXAMPLE_PHY_ADDRESS,
			.clockName = EXAMPLE_CLOCK_NAME, .macAddress = configMAC_ADDR,
#if defined(FSL_FEATURE_SOC_LPC_ENET_COUNT) && (FSL_FEATURE_SOC_LPC_ENET_COUNT > 0)
			.non_dma_memory = non_dma_memory,
#endif /* FSL_FEATURE_SOC_LPC_ENET_COUNT */
	};

	//CLOCK_EnableClock(kCLOCK_InputMux);

	/* attach 12 MHz clock to FLEXCOMM0 (debug console) */
	//CLOCK_AttachClk(BOARD_DEBUG_UART_CLK_ATTACH);
	//BOARD_InitPins();
	//BOARD_BootClockPLL180M();
	//BOARD_InitDebugConsole();
	//time_init();
	IP4_ADDR(&netif_ipaddr, configIP_ADDR0, configIP_ADDR1, configIP_ADDR2,
			configIP_ADDR3);
	IP4_ADDR(&netif_netmask, configNET_MASK0, configNET_MASK1, configNET_MASK2,
			configNET_MASK3);
	IP4_ADDR(&netif_gw, configGW_ADDR0, configGW_ADDR1, configGW_ADDR2,
			configGW_ADDR3);

	lwip_init();

	netif_add(&netif, &netif_ipaddr, &netif_netmask, &netif_gw, &enet_config,
			EXAMPLE_NETIF_INIT_FN, ethernet_input);
	netif_set_default(&netif);
	netif_set_up(&netif);

	//ping_init(&netif_gw);

	//PRINTF("\r\n************************************************\r\n");
	//PRINTF(" PING example\r\n");
	//PRINTF("************************************************\r\n");
	PRINTF(" IPv4 Address     : %u.%u.%u.%u\r\n", ((u8_t*) &netif_ipaddr)[0],
			((u8_t*) &netif_ipaddr)[1], ((u8_t*) &netif_ipaddr)[2],
			((u8_t*) &netif_ipaddr)[3]);
	PRINTF(" IPv4 Subnet mask : %u.%u.%u.%u\r\n", ((u8_t*) &netif_netmask)[0],
			((u8_t*) &netif_netmask)[1], ((u8_t*) &netif_netmask)[2],
			((u8_t*) &netif_netmask)[3]);
	PRINTF(" IPv4 Gateway     : %u.%u.%u.%u\r\n", ((u8_t*) &netif_gw)[0],
			((u8_t*) &netif_gw)[1], ((u8_t*) &netif_gw)[2],
			((u8_t*) &netif_gw)[3]);
	PRINTF("************************************************\r\n");

	while (1) {
		/* Poll the driver, get any outstanding frames */
		ethernetif_input(&netif);
		//sys_check_timeouts(); /* Handle all system timeouts for all core protocols */
	}
}
#endif
