/*
 * Exec1.c
 *
 *  Created on: 15 ago. 2018
 *      Author: Marcelo.Caamaño
 */

#include "CPU_def.h"
//#include "core_cm4.h" //reset?
#include "fsl_device_registers.h" //eeprom
#include "fsl_eeprom.h"

/* Funciones que procesan la agenda.
 ***********************************/
/* En la flash, las entradas de la agenda comienzan en AgendIni.
 * Se organizan según una estructura que indican la hora de la comunicación,
 *  y en los bits más significativos, se indican que tipo de comunicación es
 *  (ventana, obligatoria o condicional).
 * Hay 640 bytes máximo de diacdos a la agenda. -> 320 entradas = 10 paginas !!!
 * Cuando ocupan menos, se indica con un ffff, e inmediatamente después
 *  el checksum completo de toda la agenda en 16 bits.
 */

/* execRdNExtComm()
 * Lee la próxima entrada en la agenda.
 * Se leen paquetes de 32 entradas.
 * Cuando debe seguirse, se incrementa el número de pag y reset el contador de entrada.
 * Sale con la estructura completa de info en la variable NextAgend
 **************************************************************************************/
void execRdNextComm(void) {
	uint32_t PageTmp;
	uint32_t OffsetTmp;
	uint32_t NextAddress;

	NextAddress = NextAgend.Order << 1; // Numero de la proxima entrada de agenda: 1..320 (o 0..319) ??
	PageTmp = 0;
	while (NextAddress >= 0x40) {  // 64 addres = 32 entradas por pagina
		PageTmp++;
		NextAddress -= 0x40;
	}

	OffsetTmp = NextAddress & 0x003f; // Address dentro de la pagina actual: 0..63
	lowRdPageC(PageTmp + 8); // La agenda se guarda desde la pagina 8 en adelante
	OffsetTmp = OffsetTmp >> 1; // Indice de entrada
	NextAgend.Time = Variable[OffsetTmp].Value;

	NextAgend.Order++;
}
;

/* Funciones que arman los eventos generados por la CPU
 ******************************************************
 * Estas funciones arman los eventos en la variable PackTemp.
 * Luego la funcon execExePack lo mueve a Pck y lo procesa.
 ************************************************************/
/* Esta funcion arma el evento de reinicio.
 Se invoca cuando hay reinicio por:
 Power up, watchdog, Error de RTC, Error de CHKSUM, Falla de IO ?, comando en puerto com
 */
void execMakeReini(uint8_t Motivo) {
	PackTemp.Ev.Config = Evento;
	PackTemp.Ev.Channel = Event;
	PackTemp.Ev.Bite.CodeHi = 0;
	PackTemp.Ev.Bite.CodeLo = Motivo;
	PackTemp.Ev.Value1 = 0;
	PackTemp.Ev.Value2 = 0;
}

/* Inserta un registro de Dato o Evento en la pila que corresponde / Ademas en la pila de Tx
 Parametro  PtrSource: datos origen a registrar y flags q determinan tipo de dato
 * Mira los flags pendientes, y ejecuta.
 * Los flags pueden ser datos llegados desde la IO, flags del RTC, etc.
 * Se ingresa con el puntero a la dirección de datos que debe procesarse.
 * Los datos pueden estar en el buffer del uW+, de la uart, del rtc, etc.
 ****************************************************************************/
void execExePack(uint8_t *PtrSource) { //TODO ver tamaño de datos, ver como maneja los punteros
#ifdef DEBUG
	printf("exceExePack\r\n");
#endif
	uint8_t *PtrDest;
	uint32_t i;
	uint32_t bytesReg;
	uint8_t pila; // 0..18 Nro de pila de registro. Canales 0..15, Plu, Tx, Ev
	union {
		uint16_t d16_t[8];
		uint8_t d8_t[16];
	} __attribute__ ((packed)) datos; // El dato mas largo va en la pila Tx, 16 bytes //TODO ver size of datos!

	// Lee el primer byte: config/flags
	Pack.Var.Config = *PtrSource;
	// Tamaño del registro: limni o pluvi: 4 bytes, Meteo o eventos: 8 bytes
	if ((Pack.Bit.Long) || (Pack.Bit.Evnt))
		bytesReg = 8; // Meteo y Eventos
	else
		bytesReg = 4; // Limni y Pluvi
	// ... Va a cargar los datos fuentes a Pack
	PtrDest = &Pack.Var.Config;
	// Copia los datos desde PtrSource a Pack
	for (i = 0; i < bytesReg; i++)
		PtrDest[i] = PtrSource[i];

	// Si intenta registrar un dato luego de reiniciar la CPU o la IO no le damos bola
	if ((cpuInicio || Status.ReiniIO) && (Pack.Bit.Evnt == 0)) {
#ifdef DEBUG
		printf("descarto por Reini\r\n");
#endif
		return;
	}

	// Determina en que pila se almacena el nuevo dato o evento
	if (Pack.Var.CanalFisico < 14)
		pila = Pack.Var.CanalFisico; // Pilas 0..13
	else if (Pack.Var.CanalFisico == 14)
		pila = 16;  // Pluvio
	else if ((Pack.Var.CanalFisico == 0x15) || (Pack.Var.CanalFisico == 0x16))
		pila = Pack.Var.CanalFisico - 7; // Pilas 14 y 15

	//  Escribe el tiempo del registro: 0..1439
	// El minuto se redondea con +/- 55 segundos
	datos.d16_t[0] = Rtc.Time;
	if (Rtc.Seconds > 55) {
		datos.d16_t[0]++;
		if (datos.d16_t[0] >= 1440)
			datos.d16_t[0] = 0;
	}
	datos.d16_t[0] = (datos.d16_t[0] & 0x07ff)
			+ (((uint16_t) Pack.Var.Config << 8) & 0xf800);
	/****************** Se trata de un registro de EVENTO  ******************************/
	if (Pack.Bit.Evnt) { // Set flag de transmision condicional por limni o pluvi
		if ((Pack.Ev.Code == TxAscLimni) || (Pack.Ev.Code == TxDesLimni)
				|| (Pack.Ev.Code == TxPluvi))
			Status.HayCond = 1;
		// Tambien set TxEvent cuando la PC escribe un evento de param sensores.
		// Activa el sistema de comunicaciones para comunicarlo a la Estacion Central
		if (Pack.Ev.Code == ParamSnsrPC)
			Status.TxEvent = 1;
		// Se escribe el CODIGO, VALOR 1 y 2 de evento
		datos.d16_t[1] = (uint16_t) Pack.Ev.Code;
		datos.d16_t[2] = (uint16_t) Pack.Ev.Value1;
		datos.d16_t[3] = (uint16_t) Pack.Ev.Value2;
		if (Pack.Ev.Code == ReiniIOOK)
			Status.ReiniIO = 1; // Flag de reinicio de IO
		//memWrReg(18, (unsigned char*)&datos, 8);  // REG de 8 bytes en pila 18
#ifdef DEBUG
		printf("EV_\r\n");
#endif
		memWrReg(18, (uint8_t*) &datos, 8);  // REG de 8 bytes en pila 18
	} else
	/******************* Se trata de un registro de DATO  *******************************/
	{
		// Se escribe el VALOR del DATO
		datos.d16_t[1] = Pack.Var.Value;
		/********************** Registro de un DATO METEO ***********************************/
		if (Pack.Bit.Long) {
			// Se escribe el MAXIMO y MINIMO
			datos.d16_t[2] = Pack.Var.Max;
			datos.d16_t[3] = Pack.Var.Min;
#ifdef DEBUG
			printf("datL_\r\n");
#endif
			memWrReg(pila, (uint8_t*) &datos, 8); // REG de 8 bytes en pila 1..15
		} else {
#ifdef DEBUG
			printf("dat_\r\n");
#endif
			memWrReg(pila, (uint8_t*) &datos, 4); // REG de 4 bytes en pila 0 o 16
		}
		/*********** El DATO registrado se agrega en la cola de TX *************************/
		if (Pack.Bit.TxToo == 1) {
			datos.d16_t[1] = Rtc.Date;    // Guarda la Fecha
			datos.d16_t[2] = Pack.Var.CanalFisico;  // Guarda el Canal
			datos.d16_t[3] = Pack.Var.Value;  // Guarda el Valor
			// Si corresponde -> guarda maximo y minimo
			if (Pack.Bit.Long) {
				datos.d16_t[4] = Pack.Var.Max;
				datos.d16_t[5] = Pack.Var.Min;
			} else {
				datos.d16_t[4] = 0;
				datos.d16_t[5] = 0;
			}
			datos.d16_t[6] = 0;
			datos.d16_t[7] = 0;
#ifdef DEBUG
			printf("TX_\r\n");
#endif
			memWrReg(17, (uint8_t*) &datos, 16);   // REG de 16 bytes en pila 17
		}
	}
}

/* execProcMinuto()
 Chequea presencia de la placa IO
 Chequea estado de la Bateria
 ************************************/
void execProcMinuto(void) {
	// Evalua estado de la Alimentacion Externa
	//if(!__PORTCP_bit.BatOK)
	//TODO ver estado de bateria
	if (!batADC_ADQ_OK()) {
		if (cntMalBAT < 20)
			cntMalBAT++;
		if (cntMalBAT == 5) // A los 5 minutos  genera evento e inhibe operacion
				{
			PackTemp.Ev.Config = Evento;
			PackTemp.Ev.Channel = Event;
			PackTemp.Ev.Bite.CodeHi = 0;
			PackTemp.Ev.Bite.CodeLo = LowBAT;
			PackTemp.Ev.Value1 = 0;
			PackTemp.Ev.Value2 = 0;
			execExePack(&PackTemp.Ev.Config);
			Status.BatOK = 0;   // Inhabilita procesamientos
		}
	}
}

/* Función que procesa e inicia una comunicación por Evento y el storage
 ***********************************************************************
 Activa el COM1 ante un evento q debe comunicarse inmediatamente a la Estacion Central
 por ej: parametrizacion local de sensores
 TODO-- ver como resolverlo
 **********************************************************************/
void execEventProc(void) {
	if ((Status.TxEvent) && (!Status.Com1On) && (!FlagGral.InhTxEvent)) {
		if (!Status.Com1On) {
			Status.Com1On = 1;
			if (!Status.Com2On) //intraWrSD(0,0);  // Activa Orbcomm
			{ //OUT_1_OFF;
			}
		}
		// Inicializa contador de ventana, Pag 0, Variable[3].value
		//__disable_interrupt();
		//__read_flash_block((unsigned short)&NextAgend.Long, ConfigIni+6, 2); TODO implementar algo asi!
		//__enable_interrupt();
		lowRdPageC(0); //lee pagina 0, Variable[3].value
		NextAgend.Long = (uint16_t) Variable[3].Value;
	}
}

/* execProcDia()
 * Función que almacena la fecha actual en todas las pilas(c/sensor, tx y ev).
 * La fecha actual se lee del RTC. El puntero a fecha anterior, se lee del buf temp.

 0x4000  FECHA  0X2000+Track  Offset
 Track y Offset definen el comienzo del dia de ayer
 ***********************************************************************************/
void execProcDia(void) {
	uint8_t pila;

	// Se guarda en cada pila un registro "Time" de cambio de dia
	// 0x4000  FECHA  0X2000+pagina  offset
	// Pagina y Offset definen el comienzo del dia de ayer
	for (pila = 0; pila < 19; pila++) {
		// if(!__PORTAP_bit.MemAusente)
		// { Status.MemExt = 1;
		//  memWrRegTime(pila);
		// }
		Status.MemExt = 0;
		memWrRegTime(pila);
	}
}

/* Función que inicializa el sistema para una ventana de agenda
 **************************************************************/
/* Arma el paquete de error de OrbComm
 *************************************/
void execErrOrb(void) {
	FlagGral.InhTxEvent = 1;
	PackTemp.Ev.Config = Evento;
	PackTemp.Ev.Channel = Event;
	PackTemp.Ev.Bite.CodeLo = ErrOrbCom;
	PackTemp.Ev.Bite.CodeHi = 0;
	PackTemp.Ev.Value1 = 0;
	PackTemp.Ev.Value2 = 0;
	execExePack(&PackTemp.Ev.Config);
}

/* Controla Encendido y Apagado de la Agenda
 Se asume que se la invoca 1 vez por minuto !!!
 */
void execAgendProc(void) {
	uint16_t window, startTime;
	uint32_t leer;
	//TODO implementar (falta la lectura de flash, y habilitacion de orbcomm)
	//__disable_interrupt();
	//__read_flash_block((unsigned short)&window, ConfigIni+6, 2); // Pag 0, Variable[3].value
	//	leer = *((uint32_t *)(FSL_FEATURE_EEPROM_BASE_ADDRESS + /*PageNum * FSL_FEATURE_EEPROM_PAGE_SIZE*/ + 6 * 4));
	// 	window = (leer>>16);
	// __enable_interrupt();
	lowRdPageC(0); //lee pagina 0, Variable[3].value
	window = (uint16_t) Variable[3].Value;

	startTime = NextAgend.Time & 0x0fff;

	// Comienzo de la ventana de comunicaciones
	if ((Rtc.Time >= startTime) && (Rtc.Time < (startTime + window))) { // Estoy dentro de la ventana
		Status.Com1On = 1;
		NextAgend.Long = startTime + window - Rtc.Time - 1;
		Status.TxMand = NextAgend.Ctrl.Mand;
		Status.TxWndw = NextAgend.Ctrl.Wndw;
		// Avanzo una posicion en la agenda, NextAgend.Time queda apuntando a la proxima entrada
		execRdNextComm();
		if (NextAgend.Time == 0xffff) {
			NextAgend.Order = 0;
			execRdNextComm();
		};
	} else  // Evaluo cierre de la ventana o espero proxima entrada
	{
		if (NextAgend.Long)
			NextAgend.Long--; // Decrementa contador de agenda
		else {
			if (Status.Com1On) {
				Status.Com1On = 0;
				FlagGral.InhTxEvent = 0;
				// TxEvent se genera ante una parametriz de sensores
				// HayCond se genera ante delta pluvi o delta Asc o Desc de Limni
				// TxMand, TxWndw se cargan desde la agenda al inicio de la ventana
				// Todos estos se ponen en CERO mediante el comando writeCoreState
				if ((Status.TxMand) || (Status.TxWndw) || (Status.TxEvent)
						|| (Status.HayCond))
					if (++cntMalOrbcomm == 2)
						execErrOrb();   // Graba evento de Error de Orbcomm
			}
		}
	}
	// Encendido / Apagado de la SD1: Orbcomm
	//if(Status.Com1On && !Status.Com2On) OUT_1_OFF;//intraWrSD(0,0); // Activa Orbcomm
	//else                                OUT_1_ON; //intraWrSD(0,1); // Desactiva Orbcomm
}
