/*
 * RS485.c
 *
 *  Created on: 20 ene. 2021
 *      Author: Marcelo.Caamaño
 */
//#include "core_cm4.h" //reset?
#include "CPU_def.h"

//declarar 
//SHUTDOWN_RS485 // RS485_RE (PIO4[08]) receiver enable: 0en 1dis  
//CS_RS485 // RS485_DE (PIO4[12]) driver enable: 0dis 1en
//HAB_3V3ONOFF habilitar alimentacion (PIO1[22])

enum {
	search_, measure_, waiting_, data_, wait_, clean_
};
//estados para el RS485 compartido con SDI12
extern uint32_t TMR_485;
extern void chCalcHay(void);
//extern void  chCalcHay(void);
void RS48512procesar(uint8_t *recv, uint8_t cant);

#define RING_BUFFER_485_SIZE 96
#define RX_485_DATA_SIZE     4  //era4

usart_handle_t g_485usartHandle;
usart_transfer_t receive485Xfer;
usart_transfer_t send485Xfer;

volatile bool rx485OnGoing = false;
volatile bool rx485BufferEmpty = true;
volatile bool tx485Finished;

uint8_t receiveData485[RX_485_DATA_SIZE];
uint8_t ringBuffer485[RING_BUFFER_485_SIZE];
#define COLA_SIZE 128
uint8_t cola485[COLA_SIZE];  //ojo que si usara comandos R el máximo es 75
static volatile uint32_t indiceCola = 0; //Ojo ver que funcione MAC----------------------

uint32_t indice485; //hacerlo global
__Tipo *TipoPtr485;  //ver si global
__Analogico *ChPtr485; //ver si global
uint32_t RS485status;
uint32_t RS485Reintentar = 2;

volatile bool comandoenviado = false;

//uint16_t Pagina[16]={0,1,2,3,4,5,6,7,8,9,10,11,12,13,0x15,0x16}; //valor de Page para cada canal
//uint32_t pPagina; //puntero a Pagina

void USART_485_UserCallback(USART_Type *base, usart_handle_t *handle,
		status_t status, void *userData) {
	userData = userData;
	// ver https://community.nxp.com/t5/Kinetis-Microcontrollers/MKL26Z256-UART-RX-callback-get-ring-buffer-overflow-but-not-RX/td-p/959833

	if (kStatus_USART_RxIdle == status) {
		rx485OnGoing = false;
		rx485BufferEmpty = false;
	}
	if (kStatus_USART_TxIdle == status) {
		tx485Finished = true;
	}
}

/*
 void  SDIUSART_SendBreak(USART_Type *base){

 // para pruebas
 // WWDT_Deinit(WWDT);
 // configWWDT.enableWatchdogReset=false;
 // WWDT_Init(WWDT,&configWWDT);
 // WWDT_Refresh(WWDT);

 uint32_t tem_p;
 tem_p=base->CFG;
 base->CFG &= ~(USART_CFG_ENABLE_MASK);
 base->CFG |= ((1<<USART_CFG_TXPOL_SHIFT) |  USART_CFG_ENABLE_MASK); //pone CFG->TXPOL=1 invertido
 WWDT_Refresh(WWDT);
 lowTimer(12);
 base->CFG &= ~(USART_CFG_ENABLE_MASK);
 base->CFG &= ~(1<<USART_CFG_TXPOL_SHIFT); //pone CFG->TXPOL=1 invertido
 base->CFG |=  USART_CFG_ENABLE_MASK;
 lowTimer(9);
 }

 void SDIUSART_RXset(USART_Type *base, bool ENABLE_)
 {
 *
 * Para silenciar RX mientras transmito. Perdia la RTTA. Lo deshabilté
 * if(ENABLE_){
 printf("H");
 base->FIFOCFG |= USART_FIFOCFG_EMPTYRX_MASK | USART_FIFOCFG_ENABLERX_MASK;
 // setup trigger level
 base->FIFOTRIG &= ~(USART_FIFOTRIG_RXLVL_MASK);
 base->FIFOTRIG |= USART_FIFOTRIG_RXLVL(0);
 // enable trigger interrupt
 base->FIFOTRIG |= USART_FIFOTRIG_RXLVLENA_MASK;
 }
 else{
 printf("D");
 base->FIFOCFG |= USART_FIFOCFG_EMPTYRX_MASK;
 base->FIFOCFG &= ~USART_FIFOCFG_ENABLERX_MASK;
 }
 /
 }
 */

void RS485_lowUartIni(void) { //llamarla al inicio 

	usart_config_t config;
	USART_GetDefaultConfig(&config);
	config.baudRate_Bps = 9600;
//  config.loopback=false;
	config.parityMode = kUSART_ParityDisabled;
	config.stopBitCount = kUSART_OneStopBit;
	config.bitCountPerChar = kUSART_8BitsPerChar;
	config.enableTx = true;
	config.enableRx = true;

	uint32_t frec = USART_485_CLK_FREQ;
	USART_Init(USART_485, &config, frec);

	USART_TransferCreateHandle(USART_485, &g_485usartHandle,
			USART_485_UserCallback, NULL);
	USART_TransferStartRingBuffer(USART_485, &g_485usartHandle, ringBuffer485,
			RING_BUFFER_485_SIZE);
	// Now the RX is working in background, receive in to ring buffer.

	receive485Xfer.data = receiveData485;
	receive485Xfer.dataSize = 1; //RX_485_DATA_SIZE; //13
	// rxSDIFinished=false;
	//SDIUSART_RXset(USART_485,1);
//     uint8_t ch=0x33;
//     while(1){
//      USART_WriteBlocking(USART_485, &ch, 1);
//      WWDT_Refresh(WWDT);
//     }
	HAB_3V3ON; //enciende RS485
	RS485_DE_dis;
	RS485_RE_dis;

}

void RS485_Task(uint8_t inst) {  //llamarla periodicamente en main
	size_t receivedBytes;

	if ((!rx485OnGoing) && rx485BufferEmpty) {
		rx485OnGoing = true;
		//printf("rx");
		USART_TransferReceiveNonBlocking(USART_485, &g_485usartHandle,
				&receive485Xfer, &receivedBytes);
		if (receivedBytes) {
			//printf("rx ");
			//printf("%s",receiveData485);
			rx485BufferEmpty = false;
			rx485OnGoing = false;
			//rxSDIFinished=false;
		}
	}
	if (!rx485BufferEmpty) {
		if (indiceCola < COLA_SIZE) {
			cola485[indiceCola] = receiveData485[0];
			indiceCola++;
			//printf("R_%c",receiveData485[0]);
			if (indiceCola > 1)
				if ((0x0A == receiveData485[0])
						&& (0x0D == cola485[indiceCola - 2])) {
					//printf("S_ %s , %d ",cola485,indiceCola);
					if (indiceCola > 7) {
						RS485_procesar(cola485, indiceCola, inst);
						//indiceCola=0;
					}
					indiceCola = 0;
				}
			//if((indiceCola>3) && (0x0A == receiveData485[0])&& (0x0D == cola485[indiceCola-2]))
			//{
			//	printf("\n %s",cola485);
			//	RS48512procesar(cola485,indiceCola);
			//	indiceCola=0;
			//}
		}
		//RS48512procesar(receiveData485,receivedBytes);
		rx485BufferEmpty = true;
	}
}

void RS485sendCommand(uint8_t address, uint8_t command, uint8_t command1)
/*
 * address command command1(optional) ! 
 */
{
	uint32_t i = 2;
	uint8_t sendData485[7]; //00aCn<CR><LF>
	RS485_DE_en; //enciende driver
	RS485_RE_dis;
	//SDIUSART_RXset(USART_485,0);
	sendData485[0] = '0';
	sendData485[1] = '0';
	sendData485[i] = address;
	sendData485[++i] = command;
	if (0 != command1)
		sendData485[++i] = command1;
	//sendData485[++i]='!';
	sendData485[++i] = 0x0D; //<CR>
	sendData485[++i] = 0x0A; //<LF>
	// Prepare to send.
	send485Xfer.data = sendData485;
	send485Xfer.dataSize = ++i;    //sizeof(sendData);
	tx485Finished = false;

	indiceCola = 0; //preparo el inidce para recibir
	RS485_RE_en;  //enciende receptor ----------------------ver
	// Send out.
	//CS_SDI12_txENA;
	//SDIUSART_SendBreak(USART_485);
	//USART_TransferSendNonBlocking(USART_485, &g_485usartHandle, &send485Xfer);
	//while(!tx485Finished){}; //espera que termine de transmitir
	USART_WriteBlocking(USART_485, &sendData485[0], i);

	//SDIUSART_RXset(USART_485,1);

	// Prepare to receive.
	//CS_SDI12_txDIS;

	RS485_DE_dis; //apaga driver

	// printf(" %s, ",sendData485);
	// receive485Xfer.data = receiveData485;
	// receive485Xfer.dataSize = 1;//sizeof(receiveData);

	//rxSDIFinished = false;
//    uint8_t ch;
//    while(1){
//    	USART_ReadBlocking(USART_485, &ch, 1);
//    	printf("%c",ch);
//    	WWDT_Refresh(WWDT);
//    }
}

void RS485_procesar(uint8_t *recv, uint8_t cant, uint8_t inst) {
	//si inst=0 -> guarda ; si inst=1 -> no guarda
	uint32_t i = 0;
	int32_t dato = 0, signo = 1, datoqb = 0;
	uint8_t cuenta = 0;
	ChPtr = ChPtr485;
	int32_t digitos = 0;

	switch (RS485status) {
	case (measure_):
		//---------------------------------RS485 no responde a measure------------------------
		TMR_485 = 2;
		RS485status = wait_;
		/*
		 //printf("measure_");
		 if(ChPtr->TSDI12.SDI12_Add == recv[2]){
		 if (cant > 6 ){
		 //printf("TMR: %d, %d, %d, %d",recv[cant-6]-0x30,recv[cant-5]-0x30,recv[cant-4]-0x30,recv[cant-3]-0x30);
		 TMR_485 = 1000*(recv[cant-6]-0x30) + 100*(recv[cant-5]-0x30) + 10*(recv[cant-4]-0x30) + (recv[cant-3]-0x30);
		 //n=recv[4]; no se usa
		 if(TMR_485>9999)TMR_485=999; //error
		 //TMR_485++;
		 RS485status=wait_;
		 }
		 }
		 */
		break;
	case (data_):
		//printf("d_%s",recv);
		if (ChPtr->TSDI12.SDI12_Add == recv[2]) {
			for (i = 1; i < cant; i++) {
				//busco en la cadena el comienzo del dato que necesito
				if ((recv[i] == '+') || (recv[i] == '-')) {
					cuenta++;
					if (cuenta == ChPtr->TSDI12.SDI12comandoDatPos)
						break;
				}
			}
			if (i == cant)
				return; //error, sale como si no hubiera llegado dato
			//i++;
			if (recv[i] == '-')
				signo = -1;
			i++;
			//convierto de string a int

			for (; (recv[i] > 0x2D) && (recv[i] < 0x3A); i++) //- < recv[i] < : solo numeros, no debería haber drama con el último dato porque SDI12 vienr con \cr \lf
					{
				if (i > cant)
					return; //error, sale como si no hubiera llegado dato
				if (ChPtr->TSDI12.SDI12comandoDatPos == 6
						|| ChPtr->TSDI12.SDI12comandoDatPos == 8) {
					if (++digitos > 6) {
						//datoqb=10*datoqb+(int32_t)(recv[i]- 0x30);
						continue;//almacena numeros de 5 digitos
					}
				} else if (++digitos > 5) {
					continue; //almacena numeros de 4 digitos
				}
				if (recv[i] < 0x30)
					continue; //saltea punto decimal
				dato = (dato * 10) + (int32_t) (recv[i] - 0x30);
			}
			//if(signo == -1) dato=-dato;
			//ver como vienen los datos y si hace falta truncar!!

			dato = dato * signo;
			printf("r_: %d \n", dato);

			//estos datos van de 1 a 80000. lo divido por 10
			if (ChPtr->TSDI12.SDI12comandoDatPos == 6
					|| ChPtr->TSDI12.SDI12comandoDatPos == 8)
				dato = dato / 10;

			if (dato < 0)
				dato = 16383 - dato; //conversion a negativo¿?
			//printf("rc_: %d \n",dato);

			i = Canal1;
			InstAD.Ptr = &InstAD.Canal1;
			for (; i < indice485; i++)
				InstAD.Ptr++;

			*InstAD.Ptr = dato;
			// Se acumula la ultima medicion ( chMedSDI12() )

			//ChPtr->TSDI12.SumaMed += *InstAD.Ptr;  //HACER un TSDI12
			ChPtr->TSDI12.SumaMed = *InstAD.Ptr;  //HACER un TSDI12
			ChPtr->TSDI12.quintobith = 0; //por defecto transmite solo 4bits
			/*	//si fuera sensor stevens hydraprobe, y leemos canales 6 (permitividad real) o 8(pore water EC)
			 if(ChPtr->TSDI12.SDI12comandoDatPos==6 ||ChPtr->TSDI12.SDI12comandoDatPos==8)
			 {
			 ChPtr->TSDI12.quintobith =1;
			 ChPtr->TSDI12.quintobitv=datoqb;
			 }
			 ChPtr->TSDI12.CntMed++;*/
			ChPtr->TSDI12.CntMed = 1;

			if (i <= 0x0d)
				Page = i; //Paginas  0 a 13 : EA1-EA14  TODO ver, creo que no hace falta
			else
				Page = i + 0x08;  //Paginas 21 y 22 : EA15-EA16

			if (!inst) { //si no es instantaneo entonces aaviso que hay dato para guardar
				chCalcHay();
			}
			ChPtr->Flags.Apagar = 1;
			//HAB_5V_OpAmp_OFF; //apaga conversor SDI12
			HAB_3V3OFF; //apaga RS485
			RS485_DE_dis;
			RS485_RE_dis;
			//SDIUSART_RXset(USART_485,1);
			RS485Reintentar = 0;
			RS485status = clean_;
			//printf("s");
		}
		break;
	default:
		//printf("err");
		break;

	}
}

void RS485_motor(void) {

	static __Analogico *AnaPtr[16] = { &Analogico1, &Analogico2, &Analogico3,
			&Analogico4, &Analogico5, &Analogico6, &Analogico7, &Analogico8,
			&Analogico9, &Analogico10, &Analogico11, &Analogico12, &Analogico13,
			&Analogico14, &Analogico15, &Analogico16 };   // Puntero a canal

	// printf("SDI: %04d \r\n", RS485status);
	// HAB_5V_OpAmp_ON; //enciende conversor de nivel
	// RS485sendCommand('1','M','0');
	// lowTimer(2000);
	// return;

	switch (RS485status) {
	case (search_):
		//pPagina=0;
		//printf("s_");
		for (indice485 = Canal1; indice485 <= Canal16; indice485++) //recorre los canales buscando SDI12
				{
			if (indice485 == 0)
				comandoenviado = false;
			TipoPtr485 = &Tipo[indice485];
			ChPtr485 = AnaPtr[indice485];
			//pPagina++;

			if (ChPtr485->Flags.On) //canal habilitado
				if ((*TipoPtr485) == RS485) //canal es SDI12
						{
					if (ChPtr485->Flags.Medir) {
						//printf("485_m %d",indice485);
						//HAB_5V_OpAmp_ON; //enciende conversor de nivel
						//Status.Com2On=1; //202208 deshabilita puerto com para que no moleste
						HAB_3V3ON; //enciende conversor RS485
						RS485_DE_dis; //
						RS485_RE_dis;
						// CS_SDI12_txENA; // habilita TX
						//enviar el comando Medir   00aTR<CR><LF>
						//202208 no envio comando medir, probando
						//if (!comandoenviado){
						RS485sendCommand(ChPtr485->TSDI12.SDI12_Add,
								ChPtr485->TSDI12.SDI12comandoMed1,
								ChPtr485->TSDI12.SDI12comandoMed2); //TODO implementar<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
						comandoenviado = true;
						TMR_485 = 8;
						//}
						RS485Reintentar = 2;
						//RS485status=measure_;  //RS485 no responde al comando medir
						RS485status = wait_; //lo mando a esperar 1 segundos
						break; //sale del for
					}
				}
		}
		break;
	case (measure_):
	case (data_):
		//printf("mOd_");
		if (0 == TMR_485) //no recibio respuesta
				{
			printf("485_no Rtta \n");
			if (RS485Reintentar > 0)
				RS485Reintentar--;

			//TODO: Grabar error en canal
			RS485status = clean_;
		}
		break;
	case (wait_):
		//printf("w");
		if (0 == TMR_485) {
			printf("485_d");
			//enviar el comando pedir DATO  00aTx<CR><LF>
			RS485sendCommand(ChPtr485->TSDI12.SDI12_Add, 'T',
					ChPtr485->TSDI12.SDI12comandoDat1);
			TMR_485 = 5;
			RS485status = data_;
		}
		break;
	case (clean_):
		//printf("R_");
		if (0 == RS485Reintentar) {
			//printf("clean_");
			ChPtr485->Flags.Medir = 0;
			ChPtr485->Flags.Apagar = 1;
			//Status.Com2On=0; //202208 vuelve a habilitar puerto com para que no moleste
			//HAB_5V_OpAmp_OFF; //apaga conversor SDI12
			HAB_3V3OFF; //apaga RS485
			RS485_DE_dis;
			RS485_RE_dis;

			//SDIUSART_RXset(USART_485,1);
		}
		RS485status = search_;
		break;
	default:
		printf("E_%d", RS485status);
		break;
	}

}

void RS485_instantaneos(void) {
	static __Analogico *AnaPtr[16] = { &Analogico1, &Analogico2, &Analogico3,
			&Analogico4, &Analogico5, &Analogico6, &Analogico7, &Analogico8,
			&Analogico9, &Analogico10, &Analogico11, &Analogico12, &Analogico13,
			&Analogico14, &Analogico15, &Analogico16 };   // Puntero a canal
	for (indice485 = Canal1; indice485 <= Canal16; indice485++) //recorre los canales buscando RS485
			{
		TipoPtr485 = &Tipo[indice485];
		ChPtr485 = AnaPtr[indice485];
		//if(ChPtr485->Flags.On) //canal habilitado
		if ((*TipoPtr485) == RS485) //canal es RS485
				{
			RS485sendCommand(ChPtr485->TSDI12.SDI12_Add, 'T',
					ChPtr485->TSDI12.SDI12comandoDat1);
			delay = 2000;
			RS485status = data_;
			while (delay && RS485status == data_) {
				RS485_Task(1);
			}
			delay = 200;
			while (delay)
				;
		}

	}
}
