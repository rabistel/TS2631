#ifndef ETHERNET_RJ45_H
#define ETHERNET_RJ45_H

#ifdef __cplusplus
extern "C" {
#endif

void comunicacion_rj45(void);

#ifdef __cplusplus
}
#endif

#endif /* ETHERNET_RJ45_H */
