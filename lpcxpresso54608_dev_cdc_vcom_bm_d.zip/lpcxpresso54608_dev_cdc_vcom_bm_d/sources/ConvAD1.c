/*
 * ConvAD1.c
 *
 *  Created on: 7 ago. 2018
 *      Author: Marcelo.Caamaño
 */
#include "CPU_def.h"
#include "AD7124\AD7124.h"

// extern  __Status Status;
/// extern volatile __FlagsAD FlagsAD;
extern __InstAD InstAD;
// extern  __InstAD	InstADprom;//para promediar la medicion instantanea
extern __BitValid BitValid;

const uint32_t canalplaca[16] = { 13, 11, 9, 5, 0, 12, 10, 8, 6, 7, 4, 2, 3, 1,
		2, 1 }; // i: canal logico, canalplaca[i]: canal fisico en CAD para convertir i
//modificada asignacion canales 12 y 13, estaban al reves

/* Funciones de mayor nivel del manejo del AD
 ********************************************
 * Son 3:
 *      CalAD(): Calibra al AD--self-zero-fullscale
 *      Conv(): Convierte un solo canal. Se ingresa con la entrada puesta.
 *      ConvAll(): Convierte todos los canales en forma secuencial, incluyendo el filtro de ola.
 ********************************************************************************************/

/* Función que convierte un canal
 ********************************
 * Primero se set el canal.
 * Luego se convierte 4 veces que es el tiempo de estabilización del AD.
 * Sale con el resultado que es un uint32_t (del cual los 24LSB tienen el dato)
 ***********************************************************************/
uint32_t cadConv(__canal Canales) {
	//la mantengo, pero no se llama en ningun lado
	/*
	 char Cnt;
	 char ResADhi;
	 char ResADlo;
	 if (!BitValid.MalAD){
	 for (Cnt=0; Cnt<4; Cnt++){
	 while (__PORTBP_bit.DRAD);
	 __PORTBD_bit.CSAD=0;   // On AD
	 Spi(0x38);             // Accede al setup, sale de standby y ganancia=1
	 __PORTBD_bit.CSAD=1;   // Off AD
	 __PORTBD_bit.CSAD=1;   // Off AD
	 __PORTBD_bit.CSAD=1;   // Off AD
	 while (__PORTBP_bit.DRAD);
	 __PORTBD_bit.CSAD=0;   // On AD
	 ResADhi=Spi(0x00);             // Calibración de FS del sistema. Maxima update. Sin buffer sin sync. Unipolar.
	 ResADlo=Spi(0x00);
	 __PORTBD_bit.CSAD=1;   // Off AD
	 };
	 };
	 return ((ResADhi<<8)+ResADlo);*/

	//acá debo truncar el dato a 16 bits: >>8
	int32_t resultado;

	int32_t ret;

	ret = leerCanal(canalplaca[Canales], &resultado);
	if (ret < 0) {
		/*error*/
		return 0xffffffff;
	}
	return resultado;
}

/* Setting el modo de funcionamiento del AD
 ************************************************/
void cadCalAD(void) {
	//uint8_t ResADlo=0;
	BitValid.MalAD = 0;

	/*
	 char ResADlo, cnt;
	 unsigned int tmp=0;

	 // Rutina que verifica si el A/D funciona OK, escribo un dato al reg de setup
	 //luego lo leo y comparo p/evaluar si fue bien guardado
	 BitValid.MalAD=1;
	 cnt=0;
	 while( (++cnt<4) && BitValid.MalAD )
	 {
	 // Pulso de Reset en el Conversor A/D
	 __PORTBD_bit.RTAD=0;
	 __PORTBD_bit.RTAD=0;
	 __PORTBD_bit.RTAD=0;
	 __PORTBD_bit.RTAD=1;
	 // Saco A/D del standby, preparo acceso de escritura al registro de setup
	 __PORTBD_bit.CSAD=0;
	 Spi(0x10);             // escribo comunications register
	 __PORTBD_bit.CSAD=1;
	 //  Setea modo Normal de operacion: update rate=20Hz, sin In buffer, sin filtro, unipolar
	 __PORTBD_bit.CSAD=0;
	 Spi(0x05);             // escribo setup reg
	 __PORTBD_bit.CSAD=1;
	 // Saco A/D del standby, preparo acceso de lectura al registro de setup
	 __PORTBD_bit.CSAD=0;
	 Spi(0x18);             // escribo comunications register
	 __PORTBD_bit.CSAD=1;
	 // Leo el registro de Setup y comparo p/ver si se programo correctamente el valor 0x05 del paso anterior
	 __PORTBD_bit.CSAD=0;
	 ResADlo=Spi(0x00);     // leo setup reg
	 __PORTBD_bit.CSAD=1;
	 if (ResADlo==0x05)  BitValid.MalAD=0;
	 //        while (__PORTBP_bit.DRAD);
	 }

	 // SELF CALIBRATION DEL A/D,  mide internamente CERO y VREF
	 if (!BitValid.MalAD)
	 {
	 // Saco A/D del standby, preparo acceso de escritura al registro de setup
	 __PORTBD_bit.CSAD=0;
	 Spi(0x10);
	 __PORTBD_bit.CSAD=1;
	 // Modo Self Calibration, CLK=2.4Mhz, update rate=25Hz, unipolar, input buffer, filter sync
	 __PORTBD_bit.CSAD=0;
	 Spi(0x6e);      // update rate = 25 Hz, tarda 5 seg en medir los 14 canales: +/- 1 cuenta
	 /// Spi(0x76);      // update rate = 100 Hz,  tarda 2.5 seg en medir los 14 canales: +/- 8 cuentas
	 __PORTBD_bit.CSAD=1;
	 while(__PORTBP_bit.DRAD && (++tmp<60000));  // Espera q finalice la self cal, pasa a modo normal de medicion
	 }

	 };*/
}

/* Sincroniza el AD
 ******************/
void cadSincAD(void) {
	if (!BitValid.MalAD) {
		// Sincroniza con un flanco de bajada en /DRDY: new output word available
		//tmp=0;
		//while (!__PORTBP_bit.DRAD && (++tmp<60000));
		//tmp=0;
		//while (__PORTBP_bit.DRAD && (++tmp<60000));
		//TODO espera a que el AD termine
	};

}

/* Convierte todos los canales en forma secuencial
 *************************************************
 * Se mira un flag para saber si convierte todos los canales o no.
 * Se convierte 4 veces cada canal y se almacena el resultado.
 * Mira un flag que indica si llegó el momento de convertir el canal del filtro de ola o no
 * El canal con el filtro, deja el resultado y la suma.
 ******************************************************************************************/

void cadConvAll(void) {
	__canal Canales;
	int32_t ret;
	int32_t resultado;

#ifdef DEBUG
	uint32_t cycles; /* number of cycles */

	KIN1_InitCycleCounter(); /* enable DWT hardware */
	KIN1_ResetCycleCounter(); /* reset cycle counter */
	KIN1_EnableCycleCounter(); /* start counting */
#endif

	if (FlagsAD.MeterAll)  // Para Med Instant. se pone en "1"
	{
		inicializarADC(); //todo ver si aca o en otro lado
		InstAD.Ptr = &InstAD.Canal1; // Para dejar indexado todos los canales
		// Secuencia medicion en todos los canales 1..16, va de 0 a 15
		for (Canales = Canal1; Canales < CanalOla; Canales++) { // Mide los 16 canales analogicos
			lowSetCanal(Canales); // Eleccion del MUX q corresponde
			//cadSincAD();          // Sincroniza con nuevo dato en el CAD
			//*InstAD.Ptr= cadConv(); // Guarda el resultado de la conversión en InstAD.CanalXX

			if (SDI12 >= *(&Tipo[Canales])) // Se apunta el arreglo donde se indica el tipo del canal
					{
				//si el canl no es SDI12, carga el resultado en *InstAD.Ptr; si es SDI12, pasa al siguiente.
				//los canales analogicos tienen id < a SDI12
				if (Canal10 == Canales)
					resultado = batADC_ADQ(); //todo ver, en esta version se descarta lo leido en canal 10 y se reemplaza por lectura interna
				else
					ret = leerCanal(canalplaca[Canales], &resultado);
				//todo verificar que ret sea >=0

				*InstAD.Ptr = (uint16_t) (resultado >> 8); //TODO ver convierte de 24 a 16Bits // Guarda el resultado de la conversión en InstAD.CanalXX
			}
			InstAD.Ptr++;           // Apunta al proximo Canal
		}
		//Si está encendido el indicador de MeterOla, acumula una medicion
		if (FlagsAD.MeterOla) {
			lowSetCanal(Canal1); // Setea el canal 0, limni
			//cadSincAD();  // Sincroniza con nuevo dato en el CAD
			ret = leerCanal(canalplaca[Canal1], &resultado);
			//todo verificar que ret sea >=
			InstAD.CanalOla = InstAD.CanalOla + (uint16_t) (resultado >> 8);//TODO convierte de 24 a 16bits cadConv(); // Mide y acumula
			InstAD.CntOlaMed++;
			FlagsAD.MeterOla = 0; //Baja la señalización del FlagsAD
		}
		FlagsAD.MeterAll = 0;
	}
	FlagsAD.Expired = 0; //Medición reciente (dura 1 segundo)

#ifdef DEBUG
	cycles = KIN1_GetCycleCounter(); /* get cycle counter */
	KIN1_DisableCycleCounter(); /* disable counting if not used any more */
	//float time=1.0*cycles/96000000;
	printf("tiempo ADQ: %d \r\n", cycles);
#endif

}

/* Convierte la ola solamente
 ****************************/
void cadConvOla(void) {
	int32_t ret;
	int32_t resultado;
	static uint32_t freqdiv = 0;
	if ((freqdiv++) > 20) //hace el proceso una vez de cada 20 que entra
			{
		freqdiv = 0;
		// TODO implementar. Ver si esta alimentado, y adquirir ola
		if (StatusIO.Alimentado && Analogico1.Flags.Medir && !BitValid.MalAD) {
			if (FlagsAD.MeterOla) {
				//inicializarADC(); //todo ver si aca o en otro lado no hace falta. Ya lo inicialicé en chProAllSeg()

				lowSetCanal(Canal1);
				//cadSincAD();
				//InstAD.CanalOla = InstAD.CanalOla + cadConv();
				ret = leerCanal(canalplaca[Canal1], &resultado);
				//todo verificar que ret sea >=
				InstAD.CanalOla = InstAD.CanalOla + (uint16_t) (resultado >> 8);//TODO convierte de 24 a 16bits cadConv(); // Mide y acumula
				InstAD.CntOlaMed++;
				FlagsAD.MeterOla = 0;
				printf("o");
			}
		}
	}

}

