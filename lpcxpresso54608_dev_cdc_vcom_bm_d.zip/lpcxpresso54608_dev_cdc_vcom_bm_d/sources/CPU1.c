/*
 * CPU1.c
 *
 *  Created on: 9 ago. 2018
 *      Author: Marcelo.Caamaño
 */

#include "CPU_def.h"

//#include "Variables1.h"

/********* Agenda por defecto, cuando no da el checksum al reinicio *******/
void cpuDefaultAgend(void) {
	//TODO revisar
	uint32_t CheckTmp;
	uint32_t Cnt;
	// Agenda por defecto
	Variable[0].Value = 0;
	Variable[1].Value = 60;
	Variable[2].Value = 120;
	Variable[3].Value = 180;
	Variable[4].Value = 240;
	Variable[5].Value = 300;
	Variable[6].Value = 360;
	Variable[7].Value = 420;
	Variable[8].Value = 480;
	Variable[9].Value = 540;
	Variable[10].Value = 600;
	Variable[11].Value = 660;
	Variable[12].Value = 720;
	Variable[13].Value = 780;
	Variable[14].Value = 840;
	Variable[15].Value = 900;
	Variable[16].Value = 960;
	Variable[17].Value = 1020;
	Variable[18].Value = 1080;
	Variable[19].Value = 1140;
	Variable[20].Value = 1200;
	Variable[21].Value = 1260;
	Variable[22].Value = 1320;
	Variable[23].Value = 1380;
	Variable[24].Value = 0xffff; // fin de agenda
	// Checksum de la pagina
	CheckTmp = 0;
	for (Cnt = 0; Cnt < 25; Cnt++) { // Activo flags de agenda: Toblig(b13), Tcond(b14), Twind(b15)
		Variable[Cnt].Value |= 0xE000;
		CheckTmp += Variable[Cnt].Value;
	}
	Variable[25].Value = CheckTmp;  // Luego del fin de agenda sigue el checksum
	// PAGINA 8 de flash uC, guarda la agenda
	lowWrPageC(8);
}

/********* Valores del COM por defecto, cuando no da el checksum al reinicio ***********/
void cpuDefaultCom(void) {
	//TODO revisar
	uint16_t *Ptr;
	uint32_t CheckTmp;
	uint32_t Cnt;
	// Defino el setting del comm
	Variable[0].Byte.Lo = BR19200;    // PunteroBaudRate
	Variable[0].Byte.Hi = 0;   // 0..100 x 10 mS delay RTS -> Tx  DelayHandShake
	Variable[1].Byte.Lo = 0;      // NO SE USA
	Variable[1].Byte.Hi = 1;      // RTU_ID_Lo
	Variable[2].Byte.Lo = 0;      // RTU_ID_Hi
	Variable[2].Byte.Hi = 0;      // Sin Uso
	Variable[3].Value = 15; // Tiempo de apertura de la ventana de comunicaciones en minutos
	// Checksum de la pagina
	CheckTmp = 0;
	Ptr = &Variable[0].Value;
	for (Cnt = 0; Cnt < 31; Cnt++) {
		CheckTmp = CheckTmp + *Ptr;
		Ptr++;
	}
	Variable[31].Value = CheckTmp;
	// PAGINA 0 de flash uC, guarda la config del puerto comm
	lowWrPageC(0);
}

/********* Valores del COM por defecto, cuando no da el checksum al reinicio ***********/
void cpuVersion(void) {
	//TODO revisar
	uint16_t *Ptr;
	uint32_t CheckTmp;
	uint32_t Cnt;
	// Defino el setting del comm
	Variable[0].Value = (uint16_t) _VHI;
	Variable[1].Value = (uint16_t) _VMED;
	Variable[2].Value = (uint16_t) _VLO;
	// Checksum de la pagina
	CheckTmp = 0;
	Ptr = &Variable[0].Value;
	for (Cnt = 0; Cnt < 31; Cnt++) {
		if (Cnt > 2) {
			*Ptr = 0;
		}
		CheckTmp = CheckTmp + *Ptr;
		Ptr++;
	}
	Variable[31].Value = CheckTmp;
	// PAGINA 34 de flash uC, guarda la version de firmware
	lowWrPageC(34);
}

/*===========================================================================*/
/* 16-06-01:
 * Drivers de CPU
 * --------------
 * Este archivo tiene todos los drivers requeridos por la CPU.
 * Son funciones que ejecutan tareas completas en relación a alguna parte del hardware.
 *
 * Son los siguientes:
 *                    cpuStartUp(): Inicia el Hard
 *                               Arranca el xtal de 32768Hz
 *                               Arranca periféricos
 *                               Verifica el checksum de memoria de configuración
 *                               Check el hard
 *                               Check link con el resto de las CPUs
 *                               Lee del tranceptor la hora actual
 *                               Reporta al host central el resultado del evento ReInicio
 *                               Salva el resultado final del evento en la flash de datos
 */

/*
 * Driver Start Up
 * ---------------
 * Inicia el Timer1 para PWM en ffff, que genera INT cada 65mS, o aprox 1/16 Seg
 * On el low speed xtal-
 * Espera 5 seg
 * Entra en modo doble oscilador.
 * Para el TMR1
 *
 * OUTPUT: Sale con el evento correspondiente salvado en flash y
 *         todas las variables inicializaciadas correctamente.
 *         Si en 3 intentos no sale OK, salva y asume que todo OK.
 */
void cpuStartUp(uint32_t watchAnterior) {
	uint32_t Counter, Times;
	uint32_t Resultado;
	uint16_t CheckTmp;

	for (Times = 2; Times > 0; Times--) {
		// GGB 03/03/09 - Agregado de 1 linea
		//SoftWD = 0;

		Resultado = Ok;
		__enable_interrupt();

		/* IDLE TMR0, genera interrupción cada 16 ms -> 62.5 Int/seg
		 **********************************************************************/
		//__ITMR = 0x43;  //TODO podemos compartir el timer de 8ms (y lo usamos solo en nº pares) (timer 0 del viejo)
		// Prepara flag de interrupción de 1/16 seg en Timer 1
		// T1CK = 10240000/5 = 2048000
		//TODO otro timer, cada 0.0625 seg (timer1 del viejo)
		// Se usa para delay ...
		//__T1LO=0x00;    // Los registros Autoload se cargan alternativamente
		//__T1HI=0x80;    // cada underflow genera una Int
		//__T1RALO=0x00;  // Timer 1 Autoload Register A
		//__T1RAHI=0x80;
		//__T1RBLO=0x00;  // Timer 1 Autoload Register B
		//__T1RBHI=0x80;
		//__CNTRL=0x90;   // PWM, no TxA toggle, Autoreload RA/RB, T1 start
		/* Verifica la consistencia de la pag de config del puerto COM (Pag 0)
		 en caso contrario la graba con los valores por defecto: 19200 bps
		 **********************************************************************/
		lowRdPageC(0);   //TODO ver que direcciones asignar!!!!!!
		CheckTmp = 0;
		Counter = 0;
		for (FlashPtr = &Variable[0].Value; FlashPtr < &Variable[31].Value;
				FlashPtr++) {
			CheckTmp = (uint16_t) *FlashPtr + CheckTmp; // Calcula checksum del buffer leido
			if (*FlashPtr == 0)
				Counter++;
		}
		if ((CheckTmp != Variable[31].Value) || (Counter == 31)) // Error de Checksum o toda la pag en cero
				{
			Resultado = Bad_checksum;
			cpuDefaultCom();
		}

		/* Verifica la consistencia de la Agenda, pag 8 a 17, si no da el checksum,
		 si la agenda esta vacia o si tiene mas de 300 elementos se toma la agenda por Default
		 Se ingresan 32 entradas por pag, 2 bytes c/u, y hasta 300 entradas
		 **********************************************************************/
		// Time1 | Time2 | .... | TimeN | 0xffff | CHECKSUM
		NextAgend.Order = 0;
		NextAgend.Time = 0;
		CheckTmp = 0;
		do {
			// a partir de NextAgend.Order se obtiene NextAgend.Time y se incrementa NextAgend.Order
			// Lee desde la pag 8 de flash en adelante. 10 pag, 32 entradas de agenda por pagina
			execRdNextComm();  // incrementa NextAgend.Order
			CheckTmp = CheckTmp + NextAgend.Time;   // checksum parcial
		} while ((NextAgend.Time != 0xffff) && (NextAgend.Order < AgendLong)); // AgendLong vale 300
		execRdNextComm(); // Lectura del Checksum en NextAgend.Time, incrementa NextAgend.Order
		if ((CheckTmp != NextAgend.Time) || (NextAgend.Order < 3)
				|| (NextAgend.Order >= AgendLong)) {
			Resultado = Bad_checksum;
			cpuDefaultAgend(); // Toma agenda por defecto, graba pagina 8 de Flash
		};

		// Escribir en la flash el resultado de reinicio !!!
		if (Resultado == Ok)
			break;

	}; // end for ...

	/* Mira el generador del reinicio TODO ver esto! hay en CPU y en IO
	 ********************************/
	// PowerOn1==0xAA y PowerOn2==0x55 ==> Reinicio por Watchdog
	// PowerOn1==0xAA y PowerOn2==0x56 ==> Reinicio forzado por Soft, no genera Evento
	// Otros Valores ==> Reinicio por Alimentacion
	if ((PowerOnAA != 0xaa) || ((PowerOn55 != 0x55) && (PowerOn55 != 0x56)))
		Resultado = Resultado | Bad_power_on; // 0x02
	if ((PowerOnAA == 0xaa) && (PowerOn55 == 0x55))
		Resultado = Resultado | Bad_watchdog; // 0x04
	if (0U != watchAnterior)
		Resultado = Resultado | Bad_watchdog;
	PowerOnAA = 0xaa;
	PowerOn55 = 0x55;

	//  if(lowWatchDogInit()!=0)Resultado = Resultado | Bad_watchdog; // 0x04

	//__ICNTRL_bit.t0pnd=0;   // Borra flag de T0 pending
	//__ICNTRL_bit.t0en=1;    // Habilita Interrupcion de Timer0

	//habilita interrupcion de Timer 8ms
	//s_ticker_init();

	// Variables de Temporizado. Delay para permitir que la IO se inicie
	//tics = 0;
	Rtc.CtrlByte = 0; //TODO ver que hace
	ticTimer = 2;
	while (ticTimer)
		WWDT_Refresh(WWDT);   // Delay de 2 segundos

	// RTC Hardware, Leer la hora y fecha actual
	Status.RtcIO = 0;

	rtcInit();  //lee la hora del RTC externo TODO podria cargarla en el interno

	// AGENDA: Posiciona los punteros segun la hora actual
	uniMakeRstAgend();

	// Enciendo COM1 hasta el proximo minuto en el cual decide el control de agenda
	NextAgend.Long = 0;
	Status.Com1On = 1;

	/* TODO enciendo perifericos
	 __PORTDD_bit.RST=1;  // On Flash...
	 __PORTLD_bit.Com2Dis=1;  // Off com 2 power
	 __PORTCD_bit.CTS=0;
	 __PORTCD_bit.RTS=0;
	 __ENUI_bit.brk=1;
	 __PORTLD_bit.Rx=0;
	 __PORTCD_bit.Com1Dis=1; // Off com 1 power, MUX=COM2
	 */
	Status.EVFull = 0;
	Status.UartFull = 0;
	Status.WithData = 0;
	Status.TxMand = 0;
	Status.TxWndw = 0;
	Status.TxEvent = 0;
	Status.Com2On = 0;
	Status.UartOn = 0;
	Status.ReiniIO = 0;

	BufUart.BufState = HeaderAst;
	FlagGral.InhTxEvent = 0;

	memInit();  // Inicializo Banco de Datos
	// Las lineas que siguen pueden generar y grabar eventos !!!

	// Arma el paquete para salvar el evento de reinicio!
	if (Resultado == (Ok + Bad_watchdog)) {
		execMakeReini(ReiniOKxWD);
		Status.EVFull = 1;
	} else if (Resultado == (Ok + Bad_power_on)) {
		execMakeReini(ReiniOKxAlim);
		Status.EVFull = 1;
	} else if ((Resultado & 0xf9) == (Bad_checksum)) {
		execMakeReini(ReiniErrCheck);
		Status.EVFull = 1;
	}
	if (Status.EVFull) {
		execExePack(&PackTemp.Ev.Config);
		Status.EVFull = 0;
	}
	// Evento por Error de RTC
	if (Status.ErrRTC) {
		execMakeReini(ReiniErrRTC);
		execExePack(&PackTemp.Ev.Config);
		Status.ErrRTC = 0;
	}

	//lo saque porque el modem lee esta posicion!
	// cpuVersion(); //escribe la version de firmware

	// Variables de Temporizado. Delay para permitir que la IO se inicie
	//tics = 0;
	Rtc.CtrlByte = 0;

	// Inicializa el puerto uWire para comunicarse con la IO
	cntMalIO = 0;
	//lowOnUWIRE();
	//intraWrParamUWIRE();  // Sinc. de Relojes CPU -> IO  TODO ver que hacer con el reloj
	Time = Rtc.Time;
	Timing.Seconds = Rtc.Seconds;
	chIniEnHora();
	if (!cntMalIO)
		__NOP();   // OUT_1_ON; //intraWrSD(0,1); // Desactiva Orbcomm
	else
		cntMalIO = 1;  // Req. de Sinc. de Relojes CPU -> IO
	WWDT_Refresh(WWDT);

}

void txedInit(uint32_t load) {
	// Cargo punteros desde Flash, Pag 2
	if (load)
		uniLoadTxed();
	// Valido Punteros
	Status.MemExt = 0;
	cfgReg.newData = 0;
	if ((PtrTxTxed.page >= Format[17].Long) || !PtrTxTxed.page) // PtrTxTxed invalido !!!
			{
		memRdCfgFlash(17);
		if (cfgReg.pagePast < Format[17].Long && cfgReg.pagePast) // Primer Dato del dia actual
				{
			PtrTxTxed.page = cfgReg.pagePast;
			PtrTxTxed.offset = cfgReg.offsetPast;
		} else {
			PtrTxTxed.page = 1;
			PtrTxTxed.offset = 0;
		}
		cfgReg.newData = 1;
	}
	if ((PtrEvTxed.page >= Format[18].Long) || !PtrEvTxed.page) // PtrEvTxed invalido !!!
			{
		memRdCfgFlash(18);
		if (cfgReg.pagePast < Format[18].Long && cfgReg.pagePast) // Primer Evento del dia actual
				{
			PtrEvTxed.page = cfgReg.pagePast;
			PtrEvTxed.offset = cfgReg.offsetPast;
		} else {
			PtrEvTxed.page = 1;
			PtrEvTxed.offset = 0;
		}
		cfgReg.newData = 1;
	}
	if (cfgReg.newData)
		uniSaveTxed();
}

void uniSaveTxed(void) {
	uint32_t i;
	for (i = 4; i < 32; i++)
		Variable[i].Value = 0xffff; //borra variable

	Variable[0].Value = (uint16_t) PtrTxTxed.page;
	Variable[1].Value = (uint16_t) PtrTxTxed.offset;
	Variable[2].Value = (uint16_t) PtrEvTxed.page;
	Variable[3].Value = (uint16_t) PtrEvTxed.offset;

	//__disable_interrupt();
	lowWrPageC(2);
	//__enable_interrupt();
	//__page_flash_erase(0x6100);
	//__write_flash_block(0x6100, (unsigned short)&Variable, 8);   // lowWrPage(2);
	//__enable_interrupt();
	//TODO ver! --listo, write reemplazado por lowWrPageC
}

void uniLoadTxed(void) {  //TODO ver! lito! read reemplazado por lowRdPage
//__disable_interrupt();
//__read_flash_block ((unsigned short)&Variable, 0x6100, 8);  // lowRdPage(2);
//__enable_interrupt();
	lowRdPageC(2);

	PtrTxTxed.page = (uint16_t) Variable[0].Value;
	PtrTxTxed.offset = (uint8_t) Variable[1].Value;
	PtrEvTxed.page = (uint16_t) Variable[2].Value;
	PtrEvTxed.offset = (uint8_t) Variable[3].Value;
}

