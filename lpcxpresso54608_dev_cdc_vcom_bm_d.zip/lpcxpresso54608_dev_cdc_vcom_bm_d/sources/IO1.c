/*
 * IO1.c
 *
 *  Created on: 9 ago. 2018
 *      Author: Marcelo.Caamaño
 */
#include "CPU_def.h"
//#include "Variables1.h"

void ioSetVar(uint8_t page) {
	uint32_t wr = 1, cnt;

	Buffer.ChStruct.Tipo = Meteorologico;
	Buffer.ChStruct.CanalFisico = page;
	Buffer.ChStruct.Flags.On = 1;       // Canal Encendido
	Buffer.ChStruct.Flags.AlarmaOn = 1; // Activacion de Alarmas
	Buffer.ChStruct.Flags.Ola_Dif = 0; // Procesamiento de Ola, solo se usa para el canal 1 (Page 0)
									   // En el Pluvi señaliza registro diferencial
	Buffer.ChStruct.Flags.Red_Dif = 0; // Sin Redundancia en los dig, Registro Diferencial en los analogicos
	Buffer.ChStruct.TMed = 2;         // Minutos
	Buffer.ChStruct.TRead = 5;        // Minutos
	Buffer.ChStruct.TCero = 1;        // x Tread
	Buffer.ChStruct.TResetAlarma = 1; // x Tread
	Buffer.ChStruct.TStorage = 3;     // x Tread
	Buffer.ChStruct.TEval = 1;        // x Tstorage
	Buffer.ChStruct.TDiscret = 1;     // x Tstorage

	if ((page <= 0x0d) || (page == 0x15) || (page == 0x16)) {
		Buffer.ChStruct.MaxValid = 0xffff;
		Buffer.ChStruct.MinValid = 0;
		Buffer.ChStruct.AlarmaMax = 0xbfff;  // 3000 mV
		Buffer.ChStruct.AlarmaMin = 0x3fff;  // 1000 mV
		Buffer.ChStruct.AlarmaMaxPico = 0xffff;
		Buffer.ChStruct.AlarmaMinPico = 0;
		Buffer.ChStruct.MaxSubidaValid = 0xffff;
		Buffer.ChStruct.MaxBajadaValid = 0xffff;
		Buffer.ChStruct.AlarmaSubida = 0x8000;
		Buffer.ChStruct.AlarmaBajada = 0x8000;
		Buffer.ChStruct.MaxSubidaTx = 0x8000;
		Buffer.ChStruct.MaxBajadaTx = 0x8000;
		// Parametros de Escalado
		Buffer.ChStruct.Escalado.RangoMax = 4000;
		Buffer.ChStruct.Escalado.RangoMin = 0;
		Buffer.ChStruct.Escalado.Rango = 0xffff;
		Buffer.ChStruct.Escalado.Span = 0xffff;
		Buffer.ChStruct.Escalado.Cero = 0;
		Buffer.ChStruct.Escalado.Bits = 16;
		Buffer.ChStruct.Escalado.Canal = Buffer.ChStruct.CanalFisico + 1;
		Buffer.ChStruct.Escalado.Resolucion = 1;
		Buffer.ChStruct.Escalado.Texto = 19;
		if (page == 0) {
			Buffer.ChStruct.Tipo = Limnimetrico;
			Buffer.ChStruct.Flags.Ola_Dif = 1;
			Buffer.ChStruct.Flags.Red_Dif = 1; // Registro Diferencial
			Buffer.ChStruct.TMed = 1;             // Minutos
			Buffer.ChStruct.TRead = 3;            // Minutos
			Buffer.ChStruct.MaxSubidaTx = 200;
		}
		if (page == 1)
			Buffer.ChStruct.Tipo = VelocidadViento;
		if (page == 2)
			Buffer.ChStruct.Tipo = DireccionViento;

	} else if (page == 0x0e)   // PLUVI
			{
		Buffer.ChStruct.Tipo = Pluviometrico;
		Buffer.ChStruct.TRead = 5; // Estos periodos deben ser todos iguales para el Pluvi
		Buffer.ChStruct.TStorage = 1;
		Buffer.ChStruct.TDiscret = 1;
		Buffer.ChStruct.MaxValid = 4000;
		Buffer.ChStruct.MaxSubidaTx = 4;
		Buffer.ChStruct.Escalado.Canal = 14;
		Buffer.ChStruct.Escalado.CtePluvi = 25;
		Buffer.ChStruct.TCero = 1440 / Buffer.ChStruct.TRead;
		Buffer.ChStruct.Flags.Red_Dif = 1; // Pluvi con Redundancia
		Buffer.ChStruct.Flags.Ola_Dif = 1; // Pluvi Modo Diferencial
	} else if ((page > 0x0e) && (page < 0x15))   // Entradas Digitales
			{
		Buffer.ChStruct.Tipo = SupervDigital;
		Buffer.ChStruct.Flags.On = 1;
		Buffer.ChStruct.Flags.AlarmaOn = 1; // Activacion de Alarmas p/EDs, aca no se usa
		Buffer.ChStruct.Flags.Normal = 1;  // Estado Normal p/EDs, aca no se usa
		Buffer.ChStruct.Flags.Red_Dif = 0; // Redundancia p/EDs, aca no se usa
		Buffer.ChStruct.Flags.Ola_Dif = 0;
		Buffer.ChStruct.Flags.On = 0;
	} else if (page == 0x17) // Salidas Digitales - Retencion de Estados ante RESET
			// byte0.b0: NC,   byte0.b1: SD2,   byte0.b2: SD3
			// byte1 = ~byte0
			// bytes 2 y 3 acumulado de pluvi
			{
		Buffer.Variable[0].Byte.Lo = 0;
		Buffer.Variable[0].Byte.Hi = 0xff;
		for (cnt = 1; cnt < 32; cnt++)
			Buffer.Variable[cnt].Value = 0;
		Buffer.Variable[31].Byte.Hi = 0xff;
	} else
		wr = 0; // No es una pagina de config de Entradas

	if (wr)
		lowWrPage(page);
}

/********************************************************************
 Driver Start Up
 Inicia el Timer0 para int cada 32ms que genera INT cada aprox 1/32 Seg
 ioStartUp(): Inicia el Hard
 Arranca periféricos
 Verifica el checksum de memoria de configuración
 Check el hard
 Reporta a la CPU el resultado del reinicio      */
void ioStartUp(void) {
	uint8_t page, Times;
	uint8_t Resultado;
	uint32_t temp, prim;

	Resultado = 0xaa;
	__enable_interrupt();

	for (Times = 2; Times > 0; Times--) {
		/* PRepara interrupción de 1/125 seg
		 **********************************/
		// CK = 10240000/5 Hz = 2048000 Hz
		// Periodo: 16384 Ctas => 8ms
		//TODO ver timer y funciones del TMR
		//__ITMR=0x42;    // Int del T0 cada 8ms. //TODO hacer
		/* Verifica el checksum de todas las páginas de config
		 y salva en la ram los valores recidentes en flash.
		 16 Analogicos + Pluvi + 6 Digitales + SDs
		 *****************************************************/
		Resultado = Ok;
		for (page = 0; page < 0x18; page++) // 24 paginas total
				{
			temp = 0;
			do {
				lowRdPage(page);   // Lee a Buffer.Variable[0..31]
				Resultado = lowVfyBuf(); // Verifica checksum de la pagina: byte 64
				temp++;
			} while ((Resultado != Ok) && (temp < 3));

			if (Resultado != Ok) {
				ioSetVar(page);
				Resultado = Bad;
			}
		}

		if (Resultado == Ok)
			break;
	} // Si existió algún error, reintenta 3 veces. Si OK, sale. Del Times=3

	//TODO __CNTRL=0x00; // Timer 1 apagado

	// Si el reinicio es por alimentacion -> Puesta a CERO del pluvi
	// Si es por WD mantengo valores
//    if((PowerOnAA!=0xaa) || (PowerOn55!=0x55)) BitValid.Reinicio = 1;
	if ((PowerOnaa != 0xaa) && (PowerOnSS != 0x55))
		BitValid.Reinicio = 1;   // Contador de cangilones en CERO
	else
		BitValid.Reinicio = 0;   // Conserva el contador de cangilones
	CangDeb = 0;

	PowerOnaa = 0xaa;
	PowerOnSS = 0x55;

	//TODO __ICNTRL_bit.t0pnd = 0;  //limpia tmr0 interrupt pending
	//TODO __ICNTRL_bit.t0en = 1;   //tmr0 interrupt enable

	// On com intra link
	//TODO aca encendia el uwire, no hace falta, pero si comunicar con la parte de CPU del programa lowOnUWIRE();
	// Alimentacion conmutada de sensores
	StatusIO.Alimentar = 0;
	StatusIO.Alimentado = 0;
	CntAlim = 0;
	CntInstantaneo = 0;

	StatusIO.Vacio = 1;
	StatusIO.Full1 = 0;
	StatusIO.Full2 = 0;
	StatusIO.Full3 = 0;
	StatusIO.Full4 = 0;
	// Preparao evento de Reinicio
	Resultados4.Ev.Config = Evento;
	Resultados4.Ev.Channel = Event;
	Resultados4.Ev.Bite.CodeHi = 0;
	if (Resultado == Ok)
		Resultados4.Ev.Bite.CodeLo = ReiniIOOK;
	else
		Resultados4.Ev.Bite.CodeLo = ReiniIOErrChk;
	Resultados4.Ev.Value1 = 0;
	Resultados4.Ev.Value2 = 0;
	StatusIO.Full4 = 1;
	StatusIO.Vacio = 0;
	// FLAGS !!
	Analogico1.Flags.Apagar = 1;
	Analogico2.Flags.Apagar = 1;
	Analogico3.Flags.Apagar = 1;
	Analogico4.Flags.Apagar = 1;
	Analogico5.Flags.Apagar = 1;
	Analogico6.Flags.Apagar = 1;
	Analogico7.Flags.Apagar = 1;
	Analogico8.Flags.Apagar = 1;
	Analogico9.Flags.Apagar = 1;
	Analogico10.Flags.Apagar = 1;
	Analogico11.Flags.Apagar = 1;
	Analogico12.Flags.Apagar = 1;
	Analogico13.Flags.Apagar = 1;
	Analogico14.Flags.Apagar = 1;
	Analogico15.Flags.Apagar = 1;
	Analogico16.Flags.Apagar = 1;
	FlagsViento.VeleFull = 0;

	// Setea Estados de las S.D. 2 y 3
	lowRdPage(0x17);

	//TODO ver si OK
	if (Buffer.Variable[0].Byte.Lo & 0x02)
		OUT_2_ON;  // __PORTED_bit.Ctl_02 = 1;
	else
		OUT_2_OFF;
	if (Buffer.Variable[0].Byte.Lo & 0x04)
		OUT_3_ON;  // __PORTED_bit.Ctl_03 = 1;
	else
		OUT_3_OFF;

	temp = Buffer.Variable[1].Value; // Backup de InstAD.Cangilon
	// Setea cant cangilones, asociado a la pag 0x17
	prim = __get_PRIMASK();
	__disable_interrupt();
	if (BitValid.Reinicio) {
		InstAD.Cangilones = 0;
		Buffer.ChStruct.Temporario.Flags.NoVal = 0;
		BitValid.Reinicio = 0;
	} else {
		if ((InstAD.Cangilones == 0) && (temp < 4000))
			InstAD.Cangilones = temp;
	}
	if (!prim) {
		__enable_interrupt();
	}

	//apaga todos los transistores de las salidas
	OUT_1_OFF;
	OUT_2_OFF;
	OUT_3_OFF;
	OUT_4_OFF;
	OUT_5_OFF;
	OUT_6_OFF;
	OUT_7_OFF;
	OUT_8_OFF;

}
