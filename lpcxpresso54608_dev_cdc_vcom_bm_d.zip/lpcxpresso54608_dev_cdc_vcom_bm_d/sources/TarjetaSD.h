#include "fatfs/source/fsl_sdspi_disk/fsl_sdspi_disk.h"
#include "sdmmc/sdspi/fsl_sdspi.h"

#define SPI_SD_Card SPI7
#define SPI_SD_Card_CLK_SRC kCLOCK_Flexcomm7
#define SPI_SD_Card_CLK_FREQ CLOCK_GetFlexCommClkFreq(7)
#define SPI_SSEL_SD_Card 0
#define SPI_SPOL_SD_Card kSPI_SpolActiveAllLow

static FATFS g_fileSystem;
static FIL file;
char filename[13] = "00000000.txt"; // Maximo: 8 + 4 = 12 caracteres, más nulo '\0'

extern sdspi_card_t g_sd;

extern void sdspi_disk_set_card(sdspi_card_t *card);

void getFileName(void) {
	rtc_datetime_t datetime;
	RTC_GetDatetime(RTC, &datetime);
	//PRINTF("Fecha y hora actual: %04d-%02d-%02d %02d:%02d:%02d\r\n",
	//datetime.year, datetime.month, datetime.day, datetime.hour,
	//datetime.minute, datetime.second);
	sprintf(filename, "%02d%02d%02d%02d.txt", datetime.day, datetime.hour,
			datetime.minute, datetime.second);
}

DWORD get_fattime(void) {
	rtc_datetime_t datetime;
	RTC_GetDatetime(RTC, &datetime);

	return ((DWORD) (datetime.year - 1980) << 25)
			| ((DWORD) datetime.month << 21) | ((DWORD) datetime.day << 16)
			| ((DWORD) datetime.hour << 11) | ((DWORD) datetime.minute << 5)
			| ((DWORD) (datetime.second / 2));
}

void SPI_TarjetaSD(void) {
	CLOCK_AttachClk(kFRO12M_to_FLEXCOMM7);
	PRINTF("*************************************************\r\n");

	FRESULT res;
	sdspi_disk_set_card(&g_sd);

	PRINTF("Montando sistema de archivos...\r\n");
	res = f_mount(&g_fileSystem, "0:", 1);
	if (res != FR_OK) {
		PRINTF("Error montando FatFs: %d\r\n", res);
	} else {
		PRINTF("FatFs montado correctamente.\r\n");

		getFileName();
		const char *text =
				"Datalogger TECMES TS2631: LPC54618 + SPI + FatFs\r\n"
				"Prueba de Debug!\r\n"
				"Manejo automático del CS!\r\n";
		UINT bytesWritten;

		PRINTF("Abriendo archivo para escritura...\r\n");
		res = f_open(&file, filename, FA_WRITE | FA_CREATE_ALWAYS);
		if (res != FR_OK) {
			PRINTF("Error abriendo archivo '%s': %d\r\n", filename, res);
		} else {
			PRINTF("Escribiendo en archivo...\r\n");
			res = f_write(&file, text, strlen(text), &bytesWritten);
			if (res == FR_OK && bytesWritten == strlen(text)) {
				PRINTF("Archivo escrito correctamente. Bytes escritos: %d\r\n",
						bytesWritten);
			} else {
				PRINTF("Error escribiendo archivo: %d (Bytes escritos: %d)\r\n",
						res, bytesWritten);
			}

			f_close(&file);
		}

		char readBuffer[1000];
		UINT bytesRead;
		PRINTF("Abriendo archivo para lectura...\r\n");
		res = f_open(&file, filename, FA_READ);
		if (res != FR_OK) {
			PRINTF("Error abriendo archivo '%s' para lectura: %d\r\n", filename,
					res);
		} else {
			PRINTF("Leyendo archivo...\r\n");
			res = f_read(&file, readBuffer, sizeof(readBuffer) - 1, &bytesRead);
			if (res == FR_OK) {
				readBuffer[bytesRead] = '\0';
				PRINTF("Archivo leido correctamente. Contenido:\r\n%s\r\n",
						readBuffer);
			} else {
				PRINTF("Error leyendo archivo: %d\r\n", res);
			}
			f_close(&file);
		}

		PRINTF("Desmontando sistema de archivos...\r\n");
		f_mount(NULL, "0:", 1);
		PRINTF("Sistema de archivos desmontado.\r\n");
	}
	PRINTF("*************************************************\r\n");
}
