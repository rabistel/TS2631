/*****************************************************
 * En este file están las definiciones de toda la RTU.
 *
 *****************************************************/

#ifndef CPU_DEF_H_
#define CPU_DEF_H_

#define DEBUG  ///////////////////////MAC

#define I2C_WAIT_TIMEOUT 10000U /* timeout del RTC, para que no quede colgado. 0: sin timeout */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <cr_section_macros.h> //para NOINIT
#include "fsl_gpio.h"
#include "fsl_usart.h"
#include "fsl_wwdt.h"
#include "fsl_dma.h"
#include "fsl_usart_dma.h"
#include "fsl_rtc.h"

#include "usb_device_config.h"
#include "usb.h"
#include "usb_device.h"

#include "usb_device_class.h"
#include "usb_device_cdc_acm.h"
#include "usb_device_ch9.h"

#include "usb_device_descriptor.h"
#include "virtual_com.h"
#define Calentando  (2u)        // Tiempo en décimas de segundo que calienta los sensores

#define _VHI	0U       //Version HI
#define _VMED	1U		 //Version MED  --TODO recordar incrementar
#define _VLO	0U 		 //Version LO

/********************************************************
 * Definición de constantes y variables de uso compartido
 ********************************************************/
/* Codificación de eventos
 *************************/
#define ReiniOKxAlim   (0x01)      // OK, inicio CPU
#define ReiniOKxWD     (0x02)      // OK, inicio CPU
#define ReiniErrRTC    (0x03)      // NO Imp
#define ReiniErrCheck  (0x04)      // OK, inicio CPU
#define ErrCAD0V       (0x05)      // NO Imp
#define Pluvi0         (0x06)      // OK, en IO -> calcProcPluvi0();
#define FallaIO        (0x08)      // OK, execErrorIO() en intraWrParamUWIRE()
#define ErrOrbCom      (0x09)      // OK, execErrOrbcomm() en execAgendProc()
#define ErrCAD4V       (0x0d)      // NO Imp
#define ReinixCmd      (0x0e)      // OK, comando "_Restart" del puerto COM
#define ReiniIOOK      (0x12)      // OK, inicio IO
#define ReiniIOErrChk  (0x13)      // OK, inicio IO
#define CabDigCort     (0x14)      // OK, en IO -> calcProcDgValid() en chCalSupervDigital()
#define AlMax          (0x15)      // OK, en IO
#define AlMin          (0x16)      // OK, en IO
#define AlAsc          (0x17)      // OK, en IO
#define AlDes          (0x18)      // OK, en IO
#define AlCambioDig    (0x1b)      // OK, en IO
#define AlMaxLimni     (0x1d)      // OK, en IO
#define AlMinLimni     (0x1e)      // OK, en IO
#define AlAscLimni     (0x1f)      // OK, en IO
#define AlDesLimni     (0x20)      // OK, en IO
#define TxAscLimni     (0x21)      // OK, en IO
#define TxDesLimni     (0x22)      // OK, en IO
#define TxPluvi        (0x23)      // OK, en IO
#define AlPkMax        (0x24)      // OK, en IO
#define AlPkMin        (0x25)      // OK, en IO
#define Invalido       (0x26)      // OK, en IO -> Dato Invalido
#define ErrCAD         (0x27)      // OK, en el inicio de la IO
#define ParamSnsrPC    (0x28)      // OK, uniMakeWrPack() -> evento x comando en puerto COM
// Parametrizar en Soft "Admin TS2621"
#define ParamAgendPC   (0x29)      // OK, uniMakeWrPack() / uniMakeRstAgend()
// Agenda->Aceptar en Soft "Admin TS2621"
// Comandos->Avanzadas->ReinicioAgenda en Soft "Admin TS2621"
#define ParamAgendCL   (0x2a)      // OK, uniMakeWrPack()
#define ParamSnsrCL    (0x2b)      // OK, uniMakeWrPack()
#define ReinixCfg      (0x2c)      // OK, uniMakeWrPack(), Puesta en Marcha en Soft "Admin TS2621"
#define CambioRTC      (0x2d)      // OK, en CPU -> uniMakeWrCoreStt()
#define LowBAT         (0x2e)      // OK, en CPU -> execProcMinuto()

/* Estados y evaluaciones de resultados*/
#define Ok           (0x01)
#define Not          (0x02)
#define Error        (0x03)
#define Inicial      (0x04)
#define Bad          (0x08)
#define Bad_xtal_low (0x10)
#define Bad_checksum (0x18)
#define Bad_IO       (0x20)
#define Bad_watchdog (0x04)
#define Bad_power_on (0x02)

#define FlagDate  (0x4000)    // Set el bit Date del paquete de info.
#define FlagPast  (0x2000)    // Set el bit de ayer.

#define EXP0        (0x01)    // Bit que habilita la EXP1
#define EXP1        (0x02)    // IDem 2
#define EXP2        (0x04)    // Idem 3
#define EXP3        (0x08)    // IDem 4
#define uWireHeader (0x81)    // Header del link del microwire
#define uWireRxHeader (0x82)    // Header del link del microwire de rx en las EXP
#define uWireEnd    (0x7e)    // Finalización del link.
#define Empty       (0x04)    // Vacío. Nada para mandar.

/*Pilas, ver como ampliar*/
//typedef enum {
enum {
	Limni,
	Analog01,
	Analog02,
	Analog03,
	Analog04,
	Analog05,
	Analog06,
	Analog07,
	Analog08,
	Analog09,
	Analog10,
	Analog11,
	Analog12,
	Analog13,
	Analog14,
	Analog15,
	Pluvi,
	Trans,
	Event,
	Vacio
};
// Pilas;
typedef uint8_t Pilas;

/* Para el AD */
/* Enumerado para hacer referencia a cada canal físico */
//MAC llegar a 16 canales AD, 32 Digit, y 20 SDI12
//Modificado por GGB en Ver 2.0
//typedef enum{
enum {
	Canal1,   // 0
	Canal2,
	Canal3,
	Canal4,
	Canal5,
	Canal6,
	Canal7,
	Canal8,
	Canal9,
	Canal10,
	Canal11,
	Canal12,
	Canal13,
	Canal14,
	Canal15,
	Canal16,
	CanalOla,
	CanalPluvi,
	Digit1,
	Digit2,
	Digit3,
	Digit4,
	Digit5,
	Digit6,
	Digit7  // 24
};
// __canal;
typedef uint8_t __canal;

extern __canal Llego;

extern uint32_t OlaActiva;
extern uint16_t Time;

enum {
	Sin, Vele, Ane, VeleAne
};
//__Viento;
typedef uint8_t __Viento;
extern __Viento Viento;

/*Datos de Almacenamiento*/
typedef union {
	struct {
		uint8_t Config;                // Bi
		uint8_t CanalFisico;
		uint16_t Value;       // Valor del canal
		uint16_t Max;         // Valor máximo cuando exista
		uint16_t Min;         // Valor mínimo cuando exista
	} __attribute__ ((packed)) Var;

	struct {
		uint8_t Config;  //
		Pilas Channel;
		union {
			uint16_t Code;         // Código del Evento
			struct {
				uint8_t CodeLo;
				uint8_t CodeHi;
			//uint8_t    unused0;
			//uint8_t    unused1;
			} __attribute__ ((packed)) Bite;
		};
		uint16_t Value1;       // Valor del Evento
		uint16_t Value2;       // Valor del Evento
	} __attribute__ ((packed)) Ev; //

	struct {
		uint8_t nousar0 :1;           //   (LSB)
		uint8_t nousar1 :1;
		uint8_t nousar2 :1;
		uint8_t Inval :1; // =1 ==> es un dato no validado por la IO. En fecha forma parte del valor OJO!!!
		uint8_t Long :1;              // =1 ==> es un paquete largo
		uint8_t TxToo :1;              // =1 ==> apilar en transmisión también
		uint8_t DateFlag :1;         // =1 ==> es una fecha. =0, no es una fecha
		uint8_t Evnt :1;               // =1 ==> es un evento    (MSB)
	} __attribute__ ((packed)) Bit;
} __pack;

extern __pack Pack;
extern __pack PackTemp;
extern __pack PackTempCS; //MAC2019 para escribir el core state sin romper lo demas
extern __pack Resultados1;
extern __pack Resultados2;
extern __pack Resultados3;
extern __pack Resultados4;
extern __pack *Lugar; // Lugar dentro de los resultados para guardar el pack de datos

typedef struct {
	uint8_t MemAusente :1;
	uint8_t BateriaOK :1;
} __attribute__ ((packed)) PORTAP; //solo por compatibilidad
extern PORTAP __PORTAP_bit;

#define DatoValido     (0x00)
#define DatoInvalido   (0x08)
#define DatoLargo      (0x10)
#define DatoTxToo      (0x20)
#define Evento         (0x80)
#define EventoLArgo    (0x90)

/* Buffer de lectura escritura de la flash interna
 *************************************************/
typedef union {
	struct {
		uint8_t Lo;
		uint8_t Hi;
	//uint8_t unused0;
	//uint8_t unused1;
	} __attribute__ ((packed)) Byte;
	//uint32_t Value;
	uint16_t Value;
} __variable;

extern __variable Variable[32];
extern uint16_t *FlashPtr;

#define EraseTime1 (  60u) //  1:00 de la mañana borrará los tracks.
#define EraseTime2 ( 300u) //  5:00 de la mañana borrará los tracks.
#define EraseTime3 ( 540u) //  9:00 de la mañana borrará los tracks.
#define EraseTime4 ( 780u) // 13:00 de la mañana borrará los tracks.
#define EraseTime5 (1020u) // 17:00 de la mañana borrará los tracks.
#define EraseTime6 (1260u) // 21:00 de la mañana borrará los tracks.

#define EraseLong  (5u)     // Durante cuantos minutos mira si borra o no.

#define Time2Out (5u)   // Cantidad de segundos antes de auto desconectar el com2

/* UART */
#define BR300   0u
#define BR1200  1u
#define BR2400  2u
#define BR4800  3u
#define BR9600  4u
#define BR19200 5u

/* Definición del valor de cada comando de los frames de la UART */
#define _RdCoreStt 0x20
#define _RdPndStt  0x21
#define _RdInst    0x22
#define _RdChDay   0x23
#define _RdEvDay   0x24
#define _RdEvPnd   0x25
#define _RdTxDay   0x26
#define _RdTxPnd   0x27
#define _RdPage    0x28
#define _WrPage    0x47
#define _WrCoreStt 0x48
#define _WrPack    0x49
#define _Restart   0x4b
#define _Reset     0x69
#define _RstAgend  0x4c
#define _RdFlash   0x29
// Funciones incorporadas en la ver 2.0
#define _WrSD         0x30
#define _RdChDayCar   0xA3
#define _RdEvDayCar   0xA4
#define _RdTxDayCar   0xA6
#define _ResetCar     0xE9
#define _RdFlashCar   0xA9

/* Variables de uso general */

typedef struct {
	uint8_t BatOK :1;    // Estado de la Alimentacion Externa
	uint8_t ErrRTC :1;    // Set cuando hay Error del Reloj
	uint8_t EVFull :1;    // Set cuando Eventos full
	uint8_t UartFull :1;    // Set cuando rx por uart un frame ok
	uint8_t WithData :1; // Set cuando el frame sale con uno de data de 64 bytes
	uint8_t TxMand :1; // Set por la agenda cuando es una ventana tipo TxMand: transmision obligatoria
	uint8_t TxHora :1; // Set una vez al dia incicando al Orbcomm la necesidad de Puesta en Hora
	uint8_t TxWndw :1;    // Set por la agenda cuando es una ventana tipo TxWndw
	uint8_t TxEvent :1; // Set cuando se genera el evento "ParamSnsrPC" indicando su inmediata transmision
	uint8_t HayCond :1; // Set cuando hay al menos 1 evento condicional: Al Asc o Desc de Limni / Al Pluvi
	uint8_t Com2On :1;    // Set cuando está encendido el Com2
	uint8_t Com1On :1;    // Set cuando activo el Com1
	uint8_t UartOn :1;    // Set cuando la UART y el hard ha sido encendido
	uint8_t MemExt :1;    // Set cuando se accede a mem Externa (Cartucho)
	uint8_t RtcIO :1;    // Set para Sincronizar relojes CPU -> IO
	uint8_t ReiniIO :1;    // Indicacion de Reinicio de la IO
} __attribute__((packed)) __flags_bits;

//TODO uni los status de IO con los de CPU- ver que no  haya problemas
typedef struct {
	uint32_t Alimentar :1; // Set cuando debe encenderse la alimentacion de los sensores
	uint32_t Alimentado :1;  // Set cuando el oneshoot encendió la alimentación
	uint32_t Instantaneo :1; // Set cuando se alimenta por una solicitud de medicion instantanea
	uint32_t Vacio :1;        // Set cuando el buffer de resultados esta vacio
	uint32_t Full1 :1;        // Set cuando esta full el resultados 1
	uint32_t Full2 :1;        // Set cuando esta full el resultados 2
	uint32_t Full3 :1;        // Set cuando esta full el resultados 3
	uint32_t Full4 :1;        // Set cuando esta full el resultados 4
//   uint32_t  Alimentar1:  1;  // Set cuando debe encenderse la 2º alimentacion de los sensores
} __attribute__((packed)) __Status;
extern __Status StatusIO;
/*
 typedef struct {
 uint32_t BatOK   :1;    // Estado de la Alimentacion Externa
 uint32_t ErrRTC  :1;    // Set cuando hay Error del Reloj
 uint32_t EVFull  :1;    // Set cuando Eventos full
 uint32_t UartFull:1;    // Set cuando rx por uart un frame ok
 uint32_t WithData:1;    // Set cuando el frame sale con uno de data de 64 bytes
 uint32_t TxMand  :1;    // Set por la agenda cuando es una ventana tipo TxMand: transmision obligatoria
 uint32_t TxHora  :1;    // Set una vez al dia incicando al Orbcomm la necesidad de Puesta en Hora
 uint32_t TxWndw  :1;    // Set por la agenda cuando es una ventana tipo TxWndw
 uint32_t TxEvent :1;    // Set cuando se genera el evento "ParamSnsrPC" indicando su inmediata transmision
 uint32_t HayCond :1;    // Set cuando hay al menos 1 evento condicional: Al Asc o Desc de Limni / Al Pluvi
 uint32_t Com2On  :1;    // Set cuando está encendido el Com2
 uint32_t Com1On  :1;    // Set cuando activo el Com1
 uint32_t UartOn  :1;    // Set cuando la UART y el hard ha sido encendido
 uint32_t MemExt  :1;    // Set cuando se accede a mem Externa (Cartucho)
 uint32_t RtcIO   :1;    // Set para Sincronizar relojes CPU -> IO
 uint32_t ReiniIO :1;    // Indicacion de Reinicio de la IO
 } __Status;*/
extern __flags_bits Status;

//ver direcciones en el micro nuevo
/* Bancos de CONFIG
 ******************/
/* RAM buffer de las páginas de configuración de FLASH
 * Las páginas son de 32 unsigned int. Están ubicadas en multiplos de
 *  0x40 a partir de la dir 0x4000.
 * El último dato es el checksum.
 * Cuando se escriben las páginas, la cantidad máxima de datos es de 32.
 * EL buffer para escribir las páginas es de 16 bytes por lo que se realiza un loop para wr los 64.
 *************************************************************************************************/
#define ConfigIni     (0x6000)        // Inicio de la flash de configuración
#define ConfigLow     (0x00)          // Low del inicio
#define ConfigHigh    (0x60)          // High del inicio
//#define ComSet        (ConfigIni)     // Settings del com1
//#define FormatFlash   (0x100)          // Format
//#define __DatePtr     (0x200)          // Inicio del buffer temporario de fechas
#define DatePtr       (4u)             // Página
//#define AgendIni      (0x400)         // Inicio de la agenda
#define Pila2Fisico   (7u)             // Pagina de conversion de canal fisico a canal logico (pila)

//Paginas en flash interna donde se guardan los backup de los punteros
#define PtrEndSavePage (2u)
#define PtrPastSavePage (1u)
#define PtrSavePage (0u)
#define RestorePtr (236u)
#define PointerBkpIni (0x7000)  //incicio en flash interna para guardar bkp punteros y fecha

/* Variables de uso general de la página 00 */
/* Variable para manejar el comm serie */
typedef struct {
	uint8_t PunteroBaudRate;  //indice baud rate
	uint8_t DelayHandShake;
	uint8_t SinUso; //se elimino ComControl;
	uint8_t RtuID_lo;
	uint8_t RtuID_hi;
} __attribute__ ((packed)) __comparam;

/* Del formato de las pilas en la flash*/
typedef struct {
	uint16_t Start;
	uint16_t Long;
} __attribute__ ((packed)) __structformat; //MAC TODO ver tipos!
#define PILAS 19
extern const __structformat Format[PILAS];

/* Variables del RTC.
 *******************/
typedef struct {
	uint8_t Pps :1;     // Set 1 x Seg
	uint8_t Ppm :1;     // Set 1 x min
	uint8_t Ppd :1;     // Set 1 x día
	uint8_t PpsCopy :1;     // Es una copia del Pps pero hecha en el main
	uint8_t PpmCopy :1;     // Idem del minutero

} __attribute__ ((packed)) type_timing;

typedef struct {
	uint8_t Seconds;
	uint16_t Time;
	uint16_t Date;
	union {
		uint8_t CtrlByte;
		type_timing Ctrl;
	};
} __attribute__ ((packed)) __rtc_type;
extern __rtc_type Rtc;

/* Variables de temporizado de la IO
 ***********************************/
typedef struct {
	uint8_t OlaTag;        // Cuenta hasta 25 para 1/5 de segundo.
	uint8_t Tag; // Cuenta hasta 5 veces OlaTag y da 1 segundo. Es un tag de exactamente 1/5 de seg.
	uint8_t Seconds;      // Cuenta hasta 60 y da 1 minuto.
	type_timing Bits;   // Bits para indicar tiempos, etc.
} __attribute__ ((packed)) __Timing;

extern __Timing Timing;   //volatile

/* Variables en RAM para procesar la agenda
 ******************************************/
typedef struct { ///-----------------MAC  ver esta estructura, Time era de 16Bits
	union {
		uint16_t Time;
		struct {
			uint8_t bit0 :1;
			uint8_t bit1 :1;
			uint8_t bit2 :1;
			uint8_t bit3 :1;
			uint8_t bit4 :1;
			uint8_t bit5 :1;
			uint8_t bit6 :1;
			uint8_t bit7 :1;
			uint8_t bit8 :1;
			uint8_t bit9 :1;
			uint8_t bita :1;
			uint8_t bitb :1;
			uint8_t bitc :1;
			uint8_t Mand :1;
			uint8_t Cond :1;
			uint8_t Wndw :1;
		} __attribute__ ((packed)) Ctrl;
	};
	uint16_t Order;
	uint16_t Long;
} __attribute__ ((packed)) __agend_struct;

extern __agend_struct NextAgend;

#define AgendLong (300u)

/* Punteros finales de escritura
 *******************************
 * Los punteros finales, son 3 bytes que indican en que dirección se escribirá
 *  el próximo dato en el chipflash.
 *****************************************************************************/
/* typedef struct{                                                //----------------MAC ver tipo de datos
 uint8_t TrackActual;
 uint32_t TrackOffset;
 } __ptrend;*/
typedef struct {
	uint16_t page;
	uint8_t offset;
} __attribute__ ((packed)) __ptrEnd;
extern __ptrEnd PtrTxTxed;
extern __ptrEnd PtrEvTxed;

enum {
	HeaderAst,
	HeaderAA,
	ID_RTU_lo,
	ID_RTU_hi,
	Command,
	Data00,
	Data01,
	Data02,
	Data03,
	Data04,
	Data05,
	Data06,
	CheckSum,
	Datas
};
typedef uint8_t _Bufstate;

typedef struct {        // Estructura de la uart
	uint8_t Ast;
	uint8_t HdrAA;
	uint8_t RTU_lo;
	uint8_t RTU_hi;
	uint8_t Commands;
	union {
		struct { // Estructura del buffer de Rx
			union {
				struct {
					uint8_t Code;
					uint8_t Data01;
					uint8_t Data02;
					uint8_t Data03;
					uint8_t Data04;
					uint8_t Data05;
					uint8_t Data06;
				} __attribute__ ((packed)) Restrt;

				struct {
					uint8_t Data00;
					uint8_t Data01;
					uint8_t Data02;
					uint8_t Data03;
					uint8_t Data04;
					uint8_t Data05;
					uint8_t Data06;
				} __attribute__ ((packed)) Reset;

				struct {
					uint8_t Data00;
					uint8_t Data01;
					uint8_t Data02;
					uint8_t Data03;
					uint8_t Data04;
					uint8_t Data05;
					uint8_t Data06;
				} __attribute__ ((packed)) Saving;

				struct {
					uint8_t Seconds;
					uint8_t Data01;
					uint8_t Data02;
					uint8_t Data03;
					uint8_t Data04;
					uint8_t Data05;
					uint8_t Data06;
				} __attribute__ ((packed)) RdCoreStt;

				struct {
					uint16_t TotEvPage;
					uint8_t OffEvEnd;
					uint16_t TotTxPage;
					uint8_t OffTxEnd;
					uint8_t Data06;
				} __attribute__ ((packed)) RdPndStt;

				struct {
					uint8_t Data00;
					uint8_t Data01;
					uint8_t Data02;
					uint8_t Data03;
					uint8_t Data04;
					uint8_t Data05;
					uint8_t Data06;
				} __attribute__ ((packed)) RdInst;

				struct {
					uint8_t CanalFisico;
					uint8_t PageLo;
					uint8_t PageHi;
					uint8_t DtLo;
					uint8_t DtHi;
					uint8_t Data05;
					uint8_t Data06;
				} __attribute__ ((packed)) RdChDay;

				struct {
					uint8_t Data00;
					uint8_t PageLo;
					uint8_t PageHi;
					uint8_t DtLo;
					uint8_t DtHi;
					uint8_t Data05;
					uint8_t Data06;
				} __attribute__ ((packed)) RdEvDay;

				struct {
					uint8_t Data00;
					uint16_t Page;
					uint8_t Data03;
					uint8_t Data04;
					uint8_t Data05;
					uint8_t Data06;
				} __attribute__ ((packed)) RdEvPnd;

				struct {
					uint8_t Data00;
					uint16_t Page;
					uint16_t Date;
					uint8_t Data05;
					uint8_t Data06;
				} __attribute__ ((packed)) RdTxDay;

				struct {
					uint8_t Data00;
					uint16_t Page;
					uint8_t Data03;
					uint8_t Data04;
					uint8_t Data05;
					uint8_t Data06;
				} __attribute__ ((packed)) RdTxPnd;

				struct {
					uint8_t Data00;
					uint8_t Page;
					uint8_t Data02;
					uint8_t Data03;
					uint8_t Data04;
					uint8_t Data05;
					uint8_t Data06;
				} __attribute__ ((packed)) RdPage;

				struct {
					uint8_t Data00;
					uint8_t Page;
					uint8_t Data02;
					uint8_t Data03;
					uint8_t Data04;
					uint8_t Data05;
					uint8_t Data06;
				} __attribute__ ((packed)) WrPage;

				struct {
					uint8_t Seconds;
					uint16_t Time;
					uint16_t Date;
					struct {
						uint8_t UpDateTx :1; // Set para actualizar lo transmitido de datos
						uint8_t UpDateEv :1; // Set para actualizar lo transmitido de datos
						uint8_t TxMand :1; // Set para indicar que termino una ventana obligatoria
						uint8_t TxWndw :1; // Set para indicar que termino una ventana
						uint8_t TxEvent :1; // Set para indicar que termino una ventana por eventos
						uint8_t TxHora :1; // Set para indicar que termino una tx por evento
						uint8_t TxCond :1; // Set para indicar que termino el tx condicional
						uint8_t ErrFlash :1; // Set cuando reset el flag de error en flash de datos
						uint8_t WrHora :1; // Set cuando debe escribirse la hora
					} __attribute__ ((packed)) StatusCmd;
				} __attribute__ ((packed)) WrCoreStt;

				struct {
					uint8_t Packs;
					uint8_t Data01;
					uint8_t Data02;
					uint8_t Data03;
					uint8_t Data04;
					uint8_t Data05;
					uint8_t Data06;
				} __attribute__ ((packed)) WrPack;

				struct {
					uint8_t Motivo;
					uint8_t Data01;
					uint8_t Data02;
					uint8_t Data03;
					uint8_t Data04;
					uint8_t Data05;
					uint8_t Data06;
				} __attribute__ ((packed)) RstAgend;

				struct {
					uint8_t Data00;
					uint8_t Track;
					uint16_t Page;
					uint8_t Data03;
					uint8_t Data04;
					uint8_t Data05;
				} __attribute__ ((packed)) RdFlash;

				struct {
					uint8_t sd;
					uint8_t Data01;
					uint8_t value;
					uint8_t Data03;
					uint8_t Data04;
					uint8_t Data05;
					uint8_t Data06;
				} __attribute__ ((packed)) WrSD;

			};
		} __attribute__ ((packed)) Rx; // Fin definición de la Rx

		struct { // Definición de la Tx
			union {
				struct {
					uint8_t Code;
					uint8_t Data01;
					uint8_t Data02;
					uint8_t Data03;
					uint8_t Data04;
					uint8_t Data05;
					uint8_t Data06;
				} __attribute__ ((packed)) Restrt;

				struct {
					uint8_t Data00;
					uint8_t Data01;
					uint8_t Data02;
					uint8_t Data03;
					uint8_t Data04;
					uint8_t Data05;
					uint8_t Data06;
				} __attribute__ ((packed)) Reset;

				struct {
					uint8_t Seconds;
					uint16_t Time;
					uint16_t Date;
					__flags_bits State;
				} __attribute__ ((packed)) RdCoreStt;

				struct {
					uint16_t TotEvPage;
					uint8_t OffEvEnd;
					uint16_t TotTxPage;
					uint8_t OffTxEnd;
					uint8_t Data06;
				} __attribute__ ((packed)) RdPndStt;

				struct {
					uint8_t Data00;
					uint8_t Data01;
					uint8_t Data02;
					uint8_t Data03;
					uint8_t Data04;
					uint8_t Data05;
					uint8_t Data06;
				} __attribute__ ((packed)) RdInst;

				struct {
					uint8_t Channel;
					uint8_t PageLo;
					uint8_t PageHi;
					uint8_t TotLo;
					uint8_t TotHi;
					uint8_t OffIni;
					uint8_t OffEnd;
				} __attribute__ ((packed)) RdChDay;

				struct {
					uint8_t Data00;
					uint8_t PageLo;
					uint8_t PageHi;
					uint8_t TotLo;
					uint8_t TotHi;
					uint8_t OffIni;
					uint8_t OffEnd;
				} __attribute__ ((packed)) RdEvDay;

				struct {
					uint8_t Data00;
					uint16_t Page;
					uint16_t Total;
					uint8_t OffIni;
					uint8_t OffEnd;
				} __attribute__ ((packed)) RdEvPnd;

				struct {
					uint8_t Data00;
					uint16_t Page;
					uint16_t Total;
					uint8_t OffIni;
					uint8_t OffEnd;
				} __attribute__ ((packed)) RdTxDay;

				struct {
					uint8_t Data00;
					uint16_t Page;
					uint16_t Total;
					uint8_t OffIni;
					uint8_t OffEnd;
				} __attribute__ ((packed)) RdTxPnd;

				struct {
					uint8_t Data00;
					uint8_t PageLo;
					uint8_t PageHi;
					uint8_t Data03;
					uint8_t Data04;
					uint8_t Data05;
					uint8_t Data06;
				} __attribute__ ((packed)) RdPage;

				struct {
					uint8_t Data00;
					uint8_t PageLo;
					uint8_t PageHi;
					uint8_t Data03;
					uint8_t Data04;
					uint8_t Data05;
					uint8_t Data06;
				} __attribute__ ((packed)) WrPage;

				struct {
					uint8_t Seconds;
					uint8_t TmrLo;
					uint8_t TmrHi;
					uint8_t DtLo;
					uint8_t DtHi;
					uint8_t SttLo;
					uint8_t SttHi;
				} __attribute__ ((packed)) WrCoreStt;
			};
		} __attribute__ ((packed)) Tx; // Fin definicón de la Tx.
	};
	uint8_t CheckSum;
	uint8_t TimeOut;
	uint8_t TimeOutRx;
	_Bufstate BufState;
	uint8_t *PtrRx; //-----------------TODO----------------------------------MAC ver tipo

} __attribute__ ((packed)) __buf_cmd_uart;
extern __buf_cmd_uart BufUart;

extern uint16_t Page;

/* Estructura de los 64 bytes de datos para la UART*/
typedef struct {        // Estructura de datos de la uart
	uint8_t BufData[64];
	uint8_t CheckSum;
} __attribute__ ((packed)) __data_com;
extern __data_com DataCom;

/* Mapa del CONFIG en FLASH
 ************************/
/*Página 0. Son char.
 00: Puntero a la tabla de BAUD y PSR. 0:300, 1:1200, 2:2400, 3:4800, 4:9600, 5:19200. Default:9600
 01: Delay inicial del handshake en milisegundos. De 0 a 65. 0:sin RTS. Default: 0
 02: Veces del contador de mseg. De 1 a 10.
 03: ID_lo
 04: ID_hi
 06: Tiempo de la ventana de comunicaciones, en minutos.
 */

/* A partir de la 0 en la página 1, comienza el format de la flash.
 * Se almacena aquí, el track de inicio, la cant de tracks correspondientes a cada entrada
 *  y la cantidad de bytes del paquete de info.
 * Todas las entradas y funciones se enumeran en forma consecutiva.*/

/*
 0x10: FormatLimni
 0x12: FormatAnalog01
 0x14: FormatAnalog02
 0x16: FormatAnalog03
 0x18: FormatAnalog04
 0x1a: FormatAnalog05
 0x1c: FormatAnalog06
 0x1e: FormatAnalog07
 0x20: FormatPluvi
 0x22: FormatTrans
 0x24: FormatEvent
 */

/* A partir de la 0 en la página 2 están los temporarios de fecha.
 * Tienen el formato del puntero final, y almacenan la dirección para
 *  cada pila de la fecha anterior.
 * Cuando se almacena la última fecha, se graba también la dir a la fecha anterior.
 *************************************************************************************
 00: PtrAyer Limni
 03: PtrAyer Analog01
 06: PtrAyer Analog02
 09: PtrAyer Analog03
 12: PtrAyer Analog04
 15: PtrAyer Analog05
 18: PtrAyer Analog06
 21: PtrAyer Analog07
 24: PtrAyer Pluvi
 27: PtrAyer Trans
 30: PtrAyer Event

 */

/*Página 4. Son unsigned int.
 00: La primer entrada de la agenda.
 .
 .
 .
 .
 .
 31: La última entrada de la agenda de esta página



 *************************************************************************************/

typedef struct {
	uint8_t MeterAll :1;      // Medir todos los canales
	uint8_t MeterOla :1;      // Medir el canal correspondiente a la ola
	uint8_t Expired :1; // Set cuando la medición tiene mas de 1 segundo de vida
} __attribute__ ((packed)) __FlagsAD;

extern __FlagsAD FlagsAD;

typedef struct {             //eran short, los pase a 32
	uint16_t Canal1;
	uint16_t Canal2;
	uint16_t Canal3;
	uint16_t Canal4;
	uint16_t Canal5;
	uint16_t Canal6;
	uint16_t Canal7;
	uint16_t Canal8;
	uint16_t Canal9;
	uint16_t Canal10;
	uint16_t Canal11;
	uint16_t Canal12;
	uint16_t Canal13;
	uint16_t Canal14;
	uint16_t Canal15;
	uint16_t Canal16;
	uint32_t CanalOla; ///<<<<<<<<<<-------------------------MAC ver
	uint16_t CntOlaMed;
	uint16_t Cangilones;
	uint16_t *Ptr;
//char           *PtrByte;  ///<<<<<<<-------------------------MAC ver en que se usa
} __attribute__ ((packed, aligned(sizeof(uint32_t)))) __InstAD; //TODO ver!!! son uint16_t

typedef struct {             //eran short, los pase a 32
	uint32_t Canal1;
	uint32_t Canal2;
	uint32_t Canal3;
	uint32_t Canal4;
	uint32_t Canal5;
	uint32_t Canal6;
	uint32_t Canal7;
	uint32_t Canal8;
	uint32_t Canal9;
	uint32_t Canal10;
	uint32_t Canal11;
	uint32_t Canal12;
	uint32_t Canal13;
	uint32_t Canal14;
	uint32_t Canal15;
	uint32_t Canal16;
	uint32_t CanalOla; ///<<<<<<<<<<-------------------------MAC ver
	uint16_t CntOlaMed;
	uint16_t Cangilones;
	uint32_t *Ptr;
//char           *PtrByte;  ///<<<<<<<-------------------------MAC ver en que se usa
} __attribute__ ((packed, aligned(sizeof(uint32_t)))) __InstADprom; //TODO ver!!! son uint16_t

extern __InstAD InstAD;
extern uint16_t *PtrInstAD;
/* Estructura de los canales
 ***************************
 * Se define un único tipo de estructura
 * que contempla las variables de todos los tipos de canales.
 * De esta manera se desperdician bytes, pero se simplifica el manejo
 *  ya que es igual para todos los tipos.
 ********************************************************************/
enum {
	Limnimetrico,
	Meteorologico,
	VelocidadViento,
	DireccionViento,
	SupervAnalog,
	Pluviometrico,
	HiSpeed,
	SupervDigital,
	SDI12,
	RS485
};
//__Tipo
typedef uint8_t __Tipo;

extern __Tipo Tipo[Digit7];  // 24 datos
extern __Tipo *TipoPtr;

typedef struct {
	uint8_t On :1;         // Set cuando canal on.
	uint8_t AlarmaOn :1;	  // Set cuando debe evaluarse alarma.
	uint8_t Normal :1;     // Estado normal del canal digital.
	uint8_t Red_Dif :1;    // p/EDs: Redundancia,  p/EAs: Registro Diferencial
	uint8_t Ola_Dif :1;    // Set cuando funciona con filtro de ola.
	uint8_t Medir :1; // Set cuando el tiempo está entre TMed y TRead ==> debe medirse.
	uint8_t Apagar :1; // Set cuando este canal dice que debe apagarse la alim. Cuando la Y de todos, se apaga.
	uint8_t NoVal :1;      // Set cuando la lectura es novalida
} __attribute__ ((packed)) __Flags;

typedef struct {
	uint8_t TMed;
	uint8_t CntTResetAlarma;
	uint16_t TRead;
	uint16_t TEval; //Multiplo de Tstorage
	uint16_t TStorage; //Igual a Tread
	uint16_t TDiscret;  //Multiplo de Tstorage

	uint32_t SumaMed; //valor acumulado durante Tread/Tmed, se pone a 0 cada Tread
	uint16_t CntMed; // Contador de valores acumulados en SumaMed, se pone a cero cada Tread
	uint16_t MedAnt;   // Valor Medio calculado en el ultimo Tstorage
	uint16_t MedEvalAnt; // Valor Medio calculado en el ultimo Teval
	uint16_t MedTxAnt; // Valor Medio calculado en el ultimo Tdiscret
	uint16_t StorageAnt; // Valor anterior para reg en modo diferencial
} __attribute__ ((packed)) __Limnime;

typedef struct {
	uint8_t TMed;
	uint8_t CntTResetAlarma;
	uint16_t TRead;
	uint16_t TEval; //Multiplo de Tstorage
	uint16_t TStorage; //Igual a Tread
	uint16_t TDiscret;  //Multiplo de Tstorage
	uint32_t SumaMed;
	uint16_t MedMax;   // Maximo calculado en c/Tread durante  Tstorage
	uint16_t MedMin;   // Minimo calculado en c/Tread durante  Tstorage
	uint16_t CntMed; // Contador de valores acumulados en SumaMed, se pone a cero cada Tread
	uint16_t MedAnt;   // Valor Medio calculado en el ultimo Tstorage
	uint32_t SumaStorage; // SumaStorage + Valor Anterior p/reg diferencial
	uint16_t MedMed;   // Valor Medio en Tstorage
} __attribute__ ((packed)) __Meteoro;

typedef struct {
	uint8_t TMed;
	uint8_t CntTResetAlarma;
	uint16_t TRead;
	uint16_t TEval; //Multiplo de Tstorage
	uint16_t TStorage; //Igual a Tread
	uint16_t TDiscret;  //Multiplo de Tstorage
	uint32_t SumaMed;
	uint16_t MedMax;   // Maximo calculado en c/Tread durante  Tstorage
	uint16_t MedMin;   // Minimo calculado en c/Tread durante  Tstorage
	uint16_t CntMed; // Contador de valores acumulados en SumaMed, se pone a cero cada Tread
	uint16_t MedAnt;   // Valor Medio calculado en el ultimo Tstorage
	uint32_t SumaStorage; // SumaStorage + Valor Anterior p/reg diferencial
	uint16_t MedMed;   // Valor Medio en Tstorage
} __attribute__ ((packed)) __Veloci;

typedef struct {
	uint8_t TMed;
	uint16_t TRead;
	uint16_t TStorage;
	uint16_t TDiscret;
	uint32_t SumaStorage;
	uint16_t MedMed;
	uint16_t CntVueltas2;
	uint16_t CntVueltas;
	uint16_t MedAnt;
	uint16_t CntMed;
	union {
		uint32_t SumaDir;
		struct {
			uint16_t DirLo, DirHi;
		} __attribute__ ((packed)) Suma;
	};
} __attribute__ ((packed)) __Direcci;

typedef struct {
	uint8_t TMed;
	uint8_t CntTResetAlarma;
	uint16_t TRead;
	uint16_t TEval;
	uint16_t SumaMed;
	uint16_t CntMed;         // Contador de mediciones tomadas en la sumatoria
} __attribute__ ((packed)) __SupervA;

typedef struct {
	__Flags Flags;
	uint8_t CntTResetAlarma;
	uint16_t TRead;       // Es para respetar el formato de los contadores
} __attribute__ ((packed)) __SupervD;

typedef struct {
	uint16_t TRead;      // Periodo Evaluacion
	uint16_t TStorage;   // Periodo Storage: multiplo Tread
	uint16_t TDiscret;   // Periodo Tz: multiplo Tread
	uint16_t TCero;      // Periodo de Pta a CERO: mult Tdiscret
	uint16_t VuelcosAnt; // Evento x Variacion resp ultima transmision (modo Peri)
	uint16_t StorageAnt; // Ultimo Registro p Modo Diferencial
	uint8_t CntTResetAlarma; // Para evitar eventos repetitivos por dato no valido
//uint16_t ValorAct;
//uint16_t CntTRead;
//uint16_t CntTStorage;
//uint16_t CntTDiscret;
//uint16_t CntTCero;
//uint16_t CntCeros;
//uint16_t ValorCero;
//uint16_t VuelcosAnt;
} __attribute__ ((packed)) __Pluviome;

/* typedef struct{
 uint32_t CntTEval;
 uint32_t CntTStorage;
 uint32_t CntTDiscret;
 uint32_t CntTCero;
 uint32_t MedAnt;
 }__HiSpd;
 */

typedef struct {
	uint8_t SDI12_Add; //posicion en rtta
	uint8_t CntTResetAlarma;
	uint16_t TRead;
	uint16_t TEval;      //Periodo evaluacion alarmas
	uint16_t TStorage;   // Periodo Storage: multiplo Tread
	uint16_t TDiscret;   // Periodo Transmision: multiplo Tread

	//uint32_t SumaMed;
	uint16_t SumaMed;
	uint8_t SDI12comandoMed1;
	uint8_t SDI12comandoMed2;
	uint8_t SDI12comandoDat1;
	uint8_t SDI12comandoDatPos;
	uint16_t CntMed;
	uint16_t MedAnt;
	uint16_t SumaStorage;
	uint8_t SDI12Decimales;
	//uint8_t MedMed;
	uint8_t quintobith;
	uint16_t quintobitv;
	uint16_t MedMed;
} __attribute__ ((packed)) __SDI12;

extern __SupervD Digital1;
extern __SupervD Digital2;
extern __SupervD Digital3;
extern __SupervD Digital4;
extern __SupervD Digital5;
extern __SupervD Digital6;
extern __SupervD *DigPtr;

typedef struct {
	__Flags Flags;
	union {
		__Limnime TLimnimetrico;
		__Meteoro TMeteorologico;
		__Veloci TVelocidad;
		__Direcci TDireccion;
		__SupervA TSuperv;
		__Pluviome TPluviometrico;
		__SupervD TSupervDigital;
		__SDI12 TSDI12;
	};
} __attribute__ ((packed)) __Analogico;

extern __Analogico Analogico1;
extern __Analogico Analogico2;
extern __Analogico Analogico3;
extern __Analogico Analogico4;
extern __Analogico Analogico5;
extern __Analogico Analogico6;
extern __Analogico Analogico7;
extern __Analogico Analogico8;
extern __Analogico Analogico9;
extern __Analogico Analogico10;
extern __Analogico Analogico11;
extern __Analogico Analogico12;
extern __Analogico Analogico13;
extern __Analogico Analogico14;
extern __Analogico Analogico15;
extern __Analogico Analogico16;

extern __Analogico Pluviometro;
extern __Analogico *ChPtr;    // Los procesamientos se hacen con este

typedef struct {
	int16_t Rango;   // cuentas
	int16_t RangoMin;  // UI
	int16_t RangoMax;  // UI
	uint16_t Span;
	uint16_t Cero;
	uint8_t Bits;
	uint8_t Canal;
	uint8_t Resolucion;
	uint16_t CtePluvi;
	uint8_t SinUso_1;
	uint8_t SinUso_2;
	uint8_t Texto;
} __attribute__ ((packed)) __Escalado;                      // 31 bytes

/* Buffer donde se realizan todas las operaciones de los canales
 ***************************************************************/

typedef struct {
	__Tipo Tipo;
	uint8_t CanalFisico; // Se saco la pila y se referencia a un canal fisico en vez de logico.No se usa.
	__Flags Flags;
	union {
		uint8_t TMed;
		uint8_t TRedundance;
		uint8_t SDI12_Add;
	};
	uint16_t TRead;
	uint16_t TEval;
	union {
		uint16_t TStorage;
		uint8_t SDI12comandoMed1;
		uint8_t SDI12comandoMed2;
	} __attribute__ ((packed));
	uint16_t TDiscret;
	union {
		uint16_t TCero;
		uint8_t SDI12comandoDat1;
		uint8_t SDI12comandoDatPos;
	} __attribute__ ((packed));
	uint8_t TResetAlarma;
	uint16_t MaxValid;
	uint16_t MinValid;
	uint16_t MaxSubidaValid;
	uint16_t MaxBajadaValid;
	uint16_t MaxSubidaTx;
	uint16_t MaxBajadaTx;
	uint16_t AlarmaMax;
	uint16_t AlarmaMin;
	uint16_t AlarmaSubida;
	uint16_t AlarmaBajada;
	uint16_t AlarmaMaxPico;
	uint16_t AlarmaMinPico;
	union {
		__Escalado Escalado;
		__Analogico Temporario;
	};
} __attribute__ ((packed)) __ChStruct;

typedef union {
	__ChStruct ChStruct;
	__variable Variable[32];
} __Buffer;

extern __Buffer Buffer;

extern uint16_t ValorAct;
extern uint16_t Diferencia;

// Buffer donde cada bit indica si HAY que calcular un resultado
typedef struct {
	union {
		uint32_t Full; //-----------------------MAC-------modificar para 16 analogicas, 32 digitales, 20 SDI12 ---- usar sufijo ULL si uso alguna constante Full=21ULL;
		struct {
			union {
				uint8_t Fulls1;
				struct {
					uint8_t Ana1 :1;     // Set cuando hay que calcular
					uint8_t Ana2 :1;     // Set cuando hay que calcular
					uint8_t Ana3 :1;     // Set cuando hay que calcular
					uint8_t Ana4 :1;     // Set cuando hay que calcular
					uint8_t Ana5 :1;     // Set cuando hay que calcular
					uint8_t Ana6 :1;     // Set cuando hay que calcular
					uint8_t Ana7 :1;     // Set cuando hay que calcular
					uint8_t Ana8 :1;     // Set cuando hay que calcular
				} __attribute__ ((packed)) Bits1;
			};
			union {
				uint8_t Fulls2;
				struct {
					uint8_t Ana9 :1;     // Set cuando hay que calcular
					uint8_t Anaa :1;     // Set cuando hay que calcular
					uint8_t Anab :1;     // Set cuando hay que calcular
					uint8_t Anac :1;     // Set cuando hay que calcular
					uint8_t Anad :1;     // Set cuando hay que calcular
					uint8_t Anae :1;     // Set cuando hay que calcular
					uint8_t Pluv :1;     // Set cuando hay que calcular
					uint8_t Dig1 :1;     // Set para digital 1
				} __attribute__ ((packed)) Bits2;
			};
			union {
				uint8_t Fulls3;
				struct {
					uint8_t Dig2 :1;     // Set cuando hay que calcular
					uint8_t Dig3 :1;     // Set cuando hay que calcular
					uint8_t Dig4 :1;     // Set cuando hay que calcular
					uint8_t Dig5 :1;     // Set cuando hay que calcular
					uint8_t Dig6 :1;     // Set cuando hay que calcular
					uint8_t Anaf :1;
					uint8_t Anag :1;
					uint8_t SinUso :1;
				} __attribute__ ((packed)) Bits3;
			//Queda espacio para otro BYTE, 8 variables mas
			};
		} __attribute__ ((packed)) Bytes;
	};
} __attribute__ ((packed)) __Hay;

extern __Hay Hay;
extern __Hay Invalida;

// Bits para enviar una sola vez los eventos de erores
/* typedef struct{
 uint8_t  Tmp:        1;      // Bit de uso temporario
 uint8_t  ReduErrP:   1;      // Set cuando aparecio un error de redundancia en el pluviometro
 uint8_t  ReduErr1:   1;      // Set cuando aparecio un error de redundancia en el canal 1 (IN1 y 2)
 uint8_t  ReduErr2:   1;      // Set cuando aparecio un error de redundancia en el canal 2 (IN5 y 6)
 uint8_t  ReduErr3:   1;      // Set cuando aparecio un error de redundancia en el canal 3 (IN7 y 8)
 uint8_t  Sync:       1;      // Copia anterior de la entrada PPD.
 uint8_t  Reinicio:   1;      // Set cuando llama al inicio de canales en el reinicio y clear en la media noche
 uint8_t  MalAD:      1;      // Set cuando el AD no responde en el reinicio
 }__BitValid;
 */
typedef struct {
	uint8_t Tmp :1;      // Bit de uso temporario
	uint8_t ReduErrP :1;      // Sin Uso
	uint8_t ReduErr1 :1;      // Sin Uso
	uint8_t ReduErr2 :1;      // Sin Uso
	uint8_t ReduErr3 :1;      // Sin Uso
	uint8_t EventoAD :1;      // Sin Uso
	uint8_t Reinicio :1; // Define si es reinicio por Alim -> Pta a cero de pluvi
	uint8_t MalAD :1;      // Set en la rutina de Calibracion del AD
} __attribute__ ((packed)) __BitValid;

extern __BitValid BitValid;

typedef struct {
	uint8_t FechaDist :1;
	uint8_t InhTxEvent :1; // Set cuando se produjo error de robcom para no encender masl al orbcom por txevent
} __attribute__ ((packed)) __flaggral;
extern __flaggral FlagGral;

typedef struct { //------------------MAC ver porque quieren mas de un anemometro o veleta
	uint8_t VeleFull :1;            // Set cuando la veleta obtuvo un resultado.
	uint8_t AneMax :1;            // Set cuando hubo un máximo en el anemómetro.
	uint8_t AneMin :1;            // Set cuando hubo un mínimo en el anemómetro.
} __attribute__ ((packed)) __FlagsViento;            // Flags varios del viento.
extern __FlagsViento FlagsViento; // Bits flags para el viento.

/* Algunas definiciones del viento */
/*
 typedef struct{
 uint32_t Resultado;
 uint32_t Resto;
 } __ResDiv;
 */

extern __NOINIT_DEF uint32_t PowerOnAA, PowerOn55, PowerOnaa, PowerOnSS; // Para detectar el power on
extern uint32_t cpuInicio, cntMalIO, cntMalBAT, cntMalRTC, cntMalOrbcomm;
extern volatile uint32_t tics, ticSegundo, ticTimer;

typedef union {
	uint32_t SumaDir;
	struct {
		uint16_t DirLo, DirHi;
	} __attribute__ ((packed)) Suma;
} __SD;

extern __SD SD;

typedef union {
	uint16_t VeleCero;
	struct {
		uint8_t Lo;
		uint8_t Hi;
	//uint8_t a;
	//uint8_t b;
	} __attribute__ ((packed)) VeleCeroByte;
} __VCB;

typedef union {
	uint16_t VeleSpan;
	struct {
		uint8_t Lo;
		uint8_t Hi;
	//uint8_t a;
	//uint8_t b;
	} __attribute__ ((packed)) VeleSpanByte;
} __VSB;

extern __VCB VCB;
extern __VSB VSB;

typedef struct {
	uint16_t pageIni;		// Los primeros 7 bytes se guardan en la
	uint16_t pageFin;		// pag de config, 0, de cada pila
	uint16_t pagePast;
	uint8_t offsetPast;
	uint8_t offsetFin;   // byte 256 de c/page, posicion del proximo registro
	uint8_t offsetTime; // byte 257 de c/page, posicion del ultimo reg Time cargado -> 0xFF: no hay
	int8_t newData;		// flag presente solamente en RAM
} __attribute__ ((packed)) _CfgReg;
extern _CfgReg cfgReg, tmpCfg;

extern uint16_t CntMed;
extern uint16_t CntVueltas;
extern uint16_t CntVueltas2;
extern uint16_t LastDirInter; // Ultimo promedio vectorial del unico canal vectorial posible.
extern uint16_t StDireccion;
extern uint16_t MedAnt;
/* Variables dedicadas a la veleta y el anemómetro
 *************************************************/
extern uint8_t Direccion; // Canal encontrado y seteado como direccion de viento (veleta)
extern uint8_t Velocidad; // Canal encontrado y seteado como velocidad de veinto (Anemometro)

extern uint16_t LastDireccion; // Ultimo promedio vectorial del unico canal vectorial posible.
extern uint16_t MaxDireccion; // Direccion registrada en el TRead de maxima vel. Lo set el velocidad del viento
extern uint16_t MinDireccion;    // Idem para la minima velocidad.

extern uint32_t SoftWD;

extern uint32_t CntAlim;  // Cuenta para el oneshoot de alimentacion de sensores
extern uint8_t CangDeb;
extern uint32_t CntInstantaneo; //Cuenta segundos para el time out de la medicion instantanea

//extern uint32_t Seconds;             // Idem para el segundero
//extern uint32_t PtrResultados;     // Cantidad de byte ocupados en el buffer de resultados

extern uint8_t *PtrUART;
extern const __structformat Format[PILAS];
extern __comparam Com;

extern volatile uint32_t delay; //para el timer de 1ms

extern volatile uint32_t s_sendSize;
extern USB_DMA_NONINIT_DATA_ALIGN(USB_DATA_ALIGN_SIZE) uint8_t s_currSendBuf[512];

/* Pines de IO*/
/* TODO: insert other definitions and declarations here. */
#define LED_G_ON GPIO_SetPinsOutput(GPIO, 0, 1)
#define LED_R_ON GPIO_SetPinsOutput(GPIO, 1, (1<<1))
#define LED_B_ON GPIO_SetPinsOutput(GPIO, 1, (1<<18))
#define LED_G_TOGGLE GPIO_TogglePinsOutput(GPIO, 0, 1)
#define LED_G_OFF GPIO_ClearPinsOutput(GPIO, 0, 1)
#define LED_R_OFF GPIO_ClearPinsOutput(GPIO, 1, (1<<1))
#define LED_B_OFF GPIO_ClearPinsOutput(GPIO, 1, (1<<18))
#define LED_R_TOGGLE GPIO_TogglePinsOutput(GPIO, 1, (1<<1))
#define HAB_3V3ONOFF_OFF GPIO_SetPinsOutput(GPIO, 4, (1<<6))
#define HAB_3V3ONOFF_ON GPIO_ClearPinsOutput(GPIO, 4, (1<<6))

#define HAB_12V_VSW1_ON		GPIO_SetPinsOutput	(GPIO, 4, (1<<26))
#define HAB_12V_VSW1_OFF 	GPIO_ClearPinsOutput(GPIO, 4, (1<<26))
#define HAB_12V_VSW2_ON 	GPIO_SetPinsOutput	(GPIO, 5, (1<<10))
#define HAB_12V_VSW2_OFF  	GPIO_ClearPinsOutput(GPIO, 5, (1<<10))

#define HAB_5V_OpAmp_ON		GPIO_SetPinsOutput  (GPIO, 4, (1<<1))
#define HAB_5V_OpAmp_OFF	GPIO_ClearPinsOutput(GPIO, 4, (1<<1))
#define CS_SDI12_txDIS		GPIO_SetPinsOutput  (GPIO, 4, (1<<13))
#define CS_SDI12_txENA		GPIO_ClearPinsOutput(GPIO, 4, (1<<13))

//SHUTDOWN_RS485 // RS485_RE (PIO4[08]) receiver enable: 0en 1dis
//CS_RS485 // RS485_DE (PIO4[12]) driver enable: 0dis 1en
#define RS485_RE_en		GPIO_ClearPinsOutput(GPIO, 4, (1<<8))
#define RS485_RE_dis	GPIO_SetPinsOutput  (GPIO, 4, (1<<8))
#define RS485_DE_en		GPIO_SetPinsOutput  (GPIO, 4, (1<<12))
#define RS485_DE_dis	GPIO_ClearPinsOutput(GPIO, 4, (1<<12))
//HAB_3V3ONOFF habilitar alimentacion (PIO1[22])
#define HAB_3V3ON		GPIO_SetPinsOutput  (GPIO, 1, (1<<22))
#define HAB_3V3OFF		GPIO_ClearPinsOutput  (GPIO, 1, (1<<22))																 
#define UART0_RTS_1 GPIO_SetPinsOutput(GPIO, 4, (1<<5))
#define UART0_RTS_0 GPIO_ClearPinsOutput(GPIO, 4, (1<<5))

#define IN_1_OFF GPIO_ClearPinsOutput(GPIO, 2, (1<<2))

#define OUT_1_ON GPIO_SetPinsOutput(GPIO, 2, (1<<17))
#define OUT_1_OFF GPIO_ClearPinsOutput(GPIO, 2, (1<<17))
#define OUT_2_ON GPIO_SetPinsOutput(GPIO, 2, (1<<26))
#define OUT_2_OFF GPIO_ClearPinsOutput(GPIO, 2, (1<<26))
#define OUT_3_ON GPIO_SetPinsOutput(GPIO, 3, (1<<2))
#define OUT_3_OFF GPIO_ClearPinsOutput(GPIO, 3, (1<<2))
#define OUT_4_ON GPIO_SetPinsOutput(GPIO, 3, (1<<4))
#define OUT_4_OFF GPIO_ClearPinsOutput(GPIO, 3, (1<<4))
#define OUT_5_ON GPIO_SetPinsOutput(GPIO, 3, (1<<12))
#define OUT_5_OFF GPIO_ClearPinsOutput(GPIO, 3, (1<<12))
#define OUT_6_ON GPIO_SetPinsOutput(GPIO, 3, (1<<14))
#define OUT_6_OFF GPIO_ClearPinsOutput(GPIO, 3, (1<<14))
#define OUT_7_ON GPIO_SetPinsOutput(GPIO, 3, (1<<17))
#define OUT_7_OFF GPIO_ClearPinsOutput(GPIO, 3, (1<<17))
#define OUT_8_ON GPIO_SetPinsOutput(GPIO, 3, (1<<19))
#define OUT_8_OFF GPIO_ClearPinsOutput(GPIO, 3, (1<<19))

#define CS_AIN_14_Set GPIO_SetPinsOutput(GPIO, 3, (1<<30))
#define CS_AIN_14_Clr GPIO_ClearPinsOutput(GPIO, 3, (1<<30))

#define CS_AIN_13_Set GPIO_SetPinsOutput(GPIO, 3, (1<<27))
#define CS_AIN_13_Clr GPIO_ClearPinsOutput(GPIO, 3, (1<<27))

#define CANGILON_N GPIO_ReadPinInput(GPIO,5,5) ///va el nº
#define CANGILON   GPIO_ReadPinInput(GPIO,0,1)

#define UART0_CTS GPIO_ReadPinInput(GPIO,4,(1<<5))

/*config UART*/
#define USART_RTU USART0
#define USART_RTU_CLK_SRC kCLOCK_Flexcomm0
#define USART_RTU_CLK_FREQ CLOCK_GetFreq(kCLOCK_Flexcomm0)
#define USART_RTU_IRQHandler FLEXCOMM0_IRQHandler
#define USART_RTU_IRQn FLEXCOMM0_IRQn
/*DMA para USART*/
//#define USART_RX_DMA_CHANNEL 0
//#define USART_TX_DMA_CHANNEL 1
//#define EXAMPLE_UART_DMA_BASEADDR DMA0

/*config UART SDI12*/
#define USART_SDI USART3
#define USART_SDI_CLK_SRC kCLOCK_Flexcomm3
#define USART_SDI_CLK_FREQ CLOCK_GetFreq(kCLOCK_Flexcomm3)
#define USART_SDI_IRQHandler FLEXCOMM3_IRQHandler
#define USART_SDI_IRQn FLEXCOMM0_IRQn

/*config UART RS_485*/
#define USART_485 USART6
#define USART_485_CLK_SRC kCLOCK_Flexcomm6
#define USART_485_CLK_FREQ CLOCK_GetFreq(kCLOCK_Flexcomm6)
#define USART_485_IRQHandler FLEXCOMM6_IRQHandler
//#define USART_485_IRQn FLEXCOMM0_IRQn
/* FUNCIONES COMPARTIDAS ENTRE MODULOS */
extern void lowRdPage(uint32_t PageNum);
extern void lowRdPageC(uint32_t PageNum); //Para las funciones de CPU
extern void lowWrPage(uint32_t PageNum);
extern void lowWrPageC(uint32_t PageNum); //Para las funciones del CPU
extern uint8_t lowVfyBuf(void);
extern void lowOnUWIRE(void);
extern void lowRtcUpDate(void);
extern void lowLink1Byte(uint8_t TxData);
extern void lowExchangeUWIRE(void);
extern void lowEEPInternaInit(void); //Inicializa la EEProm
extern void lowTimer(uint32_t miliseg);
extern void lowCom2Proc(void);
extern void lowOnOffCom(void);
extern void lowUartError(void);
extern void lowUCReset(void);
extern void lowUartIni(void);

extern void uniMakeWrSD(void);

extern void lowSetCanal(__canal);
extern void cadConvAll(void);
extern void cadCalAD(void);
extern uint32_t cadConv(__canal Canales);
extern void cadConvOla(void);

extern void slvAnswerUWIRE(uint8_t ExpNum);
extern void ReceiveUWIRE(void);

extern void OnSpi(void);
extern char Spi(char);

extern void chIniAnalogicos(void);
extern void chProCanal(void);
extern void chProAllSeg(void);
extern void chProAllMin(void);
extern void chCalAll(void);
extern void chSyncAll(void);
extern void chIniEnHora(void);

extern void vtoFindViento(void);

extern void execExePack(uint8_t*);
extern void execRdNextComm(void);
extern void execProcMinuto(void);
extern void execProcDia(void);
extern void execAgendProc(void);
extern void execEventProc(void);
extern void execMakeReini(uint8_t Motivo);

extern void s_ticker_init(void);

extern void uniMakeRstAgend(void);
extern void uniLoadTxed(void);
extern void uniSaveTxed(void);
extern void intraRdAny(void);
extern void uniRxExe(void);

extern void rtcInit(void);
extern void rtcSet(__rtc_type rtc);
extern void rtcRead(__rtc_type *rtc, uint8_t actFecha);

extern void memInit(void);
extern void memRdFlash(uint8_t *ptrDest, uint16_t page, uint8_t byteIni,
		uint8_t bytes);
extern void memRdCfgFlash(uint8_t pila);
extern void memWrReg(uint32_t pila, uint8_t *datos, uint8_t bytes);
extern void memWrRegTime(uint8_t pila);
extern void memBorrarPila(uint8_t pila);
extern uint8_t memCheckPila(uint8_t pila);
extern uint8_t memIncPageFin(uint8_t pila);

extern void cpuStartUp(uint32_t watchAnterior);
extern void cpuVersion(void);
extern void txedInit(uint32_t load);

extern void ioStartUp(void);
extern void RtcUpDate(void);

extern void s_ticker_init_RTC(void);
extern void IniAlimentacion(uint8_t onoff);
///------------------------------------ de CPU1_def

extern void calcMakeStorageVele(void);
extern void calcMakeDiscretLimni(void);
extern void calcMakeDiscretVele(void);
extern void calcMakeDiscretSDI12(void);

extern void __enable_interrupt(void);
extern void __disable_interrupt(void);

extern void batADC_ClockPower_Configuration(void);
extern bool batADC_ADQ_OK(void);
extern uint32_t batADC_ADQ(void);

extern void intProcUSB(uint8_t);
extern void intProcUART(uint8_t);
extern void BOARD_BootClockRUN(void);
extern uint32_t lowWatchDogInit(void);
extern void COMTask(void);

#ifdef DEBUG
//para debug
/* DWT (Data Watchpoint and Trace) registers, only exists on ARM Cortex with a DWT unit */
#define KIN1_DWT_CONTROL             (*((volatile uint32_t*)0xE0001000))
/*!< DWT Control register */
#define KIN1_DWT_CYCCNTENA_BIT       (1UL<<0)
/*!< CYCCNTENA bit in DWT_CONTROL register */
#define KIN1_DWT_CYCCNT              (*((volatile uint32_t*)0xE0001004))
/*!< DWT Cycle Counter register */
#define KIN1_DEMCR                   (*((volatile uint32_t*)0xE000EDFC))
/*!< DEMCR: Debug Exception and Monitor Control Register */
#define KIN1_TRCENA_BIT              (1UL<<24)
/*!< Trace enable bit in DEMCR register */
#define KIN1_InitCycleCounter() \
	  KIN1_DEMCR |= KIN1_TRCENA_BIT
/*!< TRCENA: Enable trace and debug block DEMCR (Debug Exception and Monitor Control Register */

#define KIN1_ResetCycleCounter() \
	  KIN1_DWT_CYCCNT = 0
/*!< Reset cycle counter */

#define KIN1_EnableCycleCounter() \
	  KIN1_DWT_CONTROL |= KIN1_DWT_CYCCNTENA_BIT
/*!< Enable cycle counter */

#define KIN1_DisableCycleCounter() \
	  KIN1_DWT_CONTROL &= ~KIN1_DWT_CYCCNTENA_BIT
/*!< Disable cycle counter */

#define KIN1_GetCycleCounter() \
	  KIN1_DWT_CYCCNT
/*!< Read cycle counter register */
#endif

extern usart_handle_t g_uartHandle;
//usart_dma_handle_t g_uartDmaHandle;
//dma_handle_t g_uartTxDmaHandle;
//dma_handle_t g_uartRxDmaHandle;
extern uint8_t g_rx_ring_buffer[256];
//extern uint8_t c1_txbuffer[64];
//extern usart_dma_handle_t g_uartDmaHandle;
//extern dma_handle_t g_uartTxDmaHandle;
//extern dma_handle_t g_uartRxDmaHandle;
//extern uint8_t g_txBuffer[128];
extern uint8_t g_rxBuffer[128];
extern volatile bool rxBufferEmpty;
extern volatile bool txBufferFull;
extern volatile bool txOnGoing;
extern volatile bool rxOnGoing;
extern usart_transfer_t sendXfer;
extern usart_transfer_t receiveXfer;
extern uint32_t contadorUART;

extern wwdt_config_t configWWDT;

extern rtc_datetime_t dateG;

extern void SDI_lowUartIni(void);
extern void SDI_Task(void);
extern void SDI_12procesar(uint8_t *recv, uint8_t cant);
extern void SDI12_motor(void);
extern uint32_t TMR_SDI; //temporiza la medicion SDI12
extern void SDI_12sendCommand(uint8_t address, uint8_t command,
		uint8_t command1); //TODO borrar de aca, era para probar en el main

extern void RS485_lowUartIni(void);
extern void RS485_Task(uint8_t inst);
extern void RS485_procesar(uint8_t *recv, uint8_t cant, uint8_t inst);
extern void RS485_motor(void);
extern void RS485_instantaneos(void);
extern uint32_t TMR_485; //temporiza la medicion RS485

#endif
