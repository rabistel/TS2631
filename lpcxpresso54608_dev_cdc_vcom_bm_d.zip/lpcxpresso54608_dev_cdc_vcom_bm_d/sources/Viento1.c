/* Módulo con todas las operaciones de resultados del Viento
 ***********************************************************/
/* Las mediciones y acumulaciones se realizan en el ChProc.
 * En el TRead se encuentran los cálculos.
 * Aquí se encuentran los resultados para el Storage tanto de Vel-eta
 *  como Ane-mómetro.
 *******************************************************************
 *
 *  Created on: 9 ago. 2018
 *      Author: Marcelo.Caamaño
 */
#include "CPU_def.h"
//#include "variables1.h"
/*
 extern  uint32_t *PtrInstAD;
 extern  uint32_t CntAlim;
 extern  uint8_t Page;
 extern  uint32_t CntInstantaneo;

 extern uint32_t Direccion;       // 0..13 -> Canal encontrado y seteado como direccion de viento (veleta)
 extern uint32_t Velocidad;       // 0..13 -> Canal encontrado y seteado como velocidad de veinto (Anemometro)
 extern enum {Sin,Vele,Ane,VeleAne} Viento; // Sensores de viento conectados !!!

 extern  uint32_t LastDireccion;   // Ultimo promedio vectorial del unico canal vectorial posible.
 extern  uint32_t MaxDireccion;    // Direccion registrada en el TRead de maxima vel. Lo set el velocidad del viento
 extern  uint32_t MinDireccion;    // Idem para la minima velocidad.

 extern void calcMakeDiscretVele(void);
 extern void calcMakeStorageVele(void);

 extern union{
 uint32_t VeleCero;
 struct{
 uint8_t Lo;
 uint8_t Hi;
 uint8_t a;
 uint8_t b;
 } VeleCeroByte;
 }VCB;

 extern union{
 uint32_t VeleSpan;
 struct{
 uint8_t Lo;
 uint8_t Hi;
 uint8_t a;
 uint8_t b;
 } VeleSpanByte;
 }VSB;


 extern  union{uint64_t SumaDir;
 struct{uint8_t DirLo, DirHi,a,b;} Suma;
 }SD;
 */

/* Busca el canal con anemometro y veleta para procesar segun corresponda
 Busca en los canales 1 a 14, paginas 0..13 (+128)
 ************************************************************************/
void vtoFindViento(void) {

	Direccion = 0xff;
	Velocidad = 0xff;

	for (Page = 0; Page < 14 && ((Direccion == 0xff) || (Velocidad == 0xff));
			Page++) {
		lowRdPage(Page);
		if (Buffer.ChStruct.Tipo == DireccionViento) {
			Direccion = Page;
			VSB.VeleSpanByte.Lo = Buffer.Variable[22].Byte.Hi;
			VSB.VeleSpanByte.Hi = Buffer.Variable[23].Byte.Lo;
			VCB.VeleCeroByte.Lo = Buffer.Variable[23].Byte.Hi;
			VCB.VeleCeroByte.Hi = Buffer.Variable[24].Byte.Lo;
			VSB.VeleSpan = VSB.VeleSpan >> 1;
		}
		;
		if (Buffer.ChStruct.Tipo == VelocidadViento)
			Velocidad = Page;
	}
	;

	Viento = Sin;
	if ((Direccion != 0xff) && (Velocidad != 0xff))
		Viento = VeleAne;
	else if ((Direccion != 0xff) && (Velocidad == 0xff))
		Viento = Vele;
	else if (Velocidad != 0xff)
		Viento = Ane;
}

/* Proceso Storage  and Discrete del viento
 ******************************************/
void vtoVientoProc(void) {
	//TODO ver si los tipos de datos no son exagerados!
	struct {
		uint8_t Temp :1; // Bit temporario para almacenar el signo en las opraciones intermedias
	} __attribute__ ((packed)) Signo;

	union {
		uint32_t Tempo;
		struct {
			uint16_t Lo, Hi;
		} __attribute__ ((packed)) Short;
	} SH;

	static __Analogico *AnaPtr[15] = { &Analogico1, &Analogico2, &Analogico3,
			&Analogico4, &Analogico5, &Analogico6, &Analogico7, &Analogico8,
			&Analogico9, &Analogico10, &Analogico11, &Analogico12, &Analogico13,
			&Analogico14 }; // Puntero a canal; static mejora la performance MAC2021

	FlagsViento.VeleFull = 0;
	// proceso del TStorage.
	// *********************
	if ((Time % AnaPtr[Direccion]->TDireccion.TStorage) == 0) {
		lowRdPage(Direccion);

		// Calcula el promedio del promedio vectorial
		// ==========================================
		// Calcula el resultado de todos los TRead del promedio vectorial
		// **************************************************************
		Signo.Temp = 0;
		if (CntVueltas2 >= 0x8000)
			Signo.Temp = 1;
		SH.Short.Hi = (CntVueltas2 & 0x7fff);
		SH.Short.Lo = 0;
		if (!Signo.Temp) {
			SD.SumaDir += SH.Tempo;
		} else {
			SD.SumaDir -= SH.Tempo;
			Signo.Temp = 0;
			if (SD.SumaDir > 0x80000000)  //TODO ver TIPOS!!!
					{
				SD.SumaDir &= 0x7fffffff;
				Signo.Temp = 1;
			}
		}
		SD.SumaDir = SD.SumaDir / CntMed;
		SD.SumaDir &= 0xffff;
		if (Signo.Temp)
			SD.SumaDir = 0x10000 - SD.SumaDir;  //TODO tipois
		SD.Suma.DirHi = 0;
		SH.Tempo = SD.SumaDir * VSB.VeleSpan / 32768 + VCB.VeleCero;
		StDireccion = (uint16_t) SH.Tempo;

		// ***** Reinicia todas las variables *****
		SD.SumaDir = 0;
		CntMed = 0;
		CntVueltas = 0;
		CntVueltas2 = 0;

		calcMakeStorageVele();

		// ************ Procesa TDiscret  *********************
		if ((Time % AnaPtr[Direccion]->TDireccion.TDiscret) == 0)
			calcMakeDiscretVele();

		// Modifica la estructura __Analogico de Direccion de Viento
		AnaPtr[Direccion]->TDireccion.TMed = Buffer.ChStruct.TMed;
		AnaPtr[Direccion]->TDireccion.TRead = Buffer.ChStruct.TRead;
		AnaPtr[Direccion]->TDireccion.TStorage = Buffer.ChStruct.TStorage
				* Buffer.ChStruct.TRead;

		// ACA ESTABA MAL, debia ir "AnaPtr[Direccion]->TDireccion.TStorage" en vez de "Buffer.ChStruct.TStorage"
		AnaPtr[Direccion]->TDireccion.TDiscret = Buffer.ChStruct.TDiscret
				* AnaPtr[Direccion]->TDireccion.TStorage;
	}
}
