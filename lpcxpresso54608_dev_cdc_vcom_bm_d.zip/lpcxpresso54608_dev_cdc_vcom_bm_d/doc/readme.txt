For detail information, please refer to the example's readme.pdf.
<MCUXpresso_SDK_Install>/boards/<board>/usb_examples/usb_device_cdc_vcom/<rtos>/readme.pdf.
For lite version, the files path is:
<MCUXpresso_SDK_Install>/boards/<board>/usb_examples/usb_device_cdc_vcom_lite/<rtos>/readme.pdf.
Note
The <rtos> is bm or freertos.
The <board> is one specific board name, such as twrk65f180m,lpcxpresso54608.