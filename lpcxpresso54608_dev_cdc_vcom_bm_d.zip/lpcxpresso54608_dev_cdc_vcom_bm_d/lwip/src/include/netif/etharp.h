/* ARP has been moved to core/ipv4, provide this #include for compatibility only */
#include "lwip/src/include/lwip/etharp.h"
#include "lwip/src/include/netif/ethernet.h"
