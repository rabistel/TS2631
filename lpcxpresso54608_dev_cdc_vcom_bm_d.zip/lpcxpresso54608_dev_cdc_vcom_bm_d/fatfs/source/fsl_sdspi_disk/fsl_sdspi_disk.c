#include "fatfs/source/fsl_sdspi_disk/fsl_sdspi_disk.h"
#include "sdmmc/sdspi/fsl_sdspi.h"
#include "fsl_spi.h"

#ifndef _LBA_T_DEFINED
typedef uint32_t LBA_t;
#define _LBA_T_DEFINED
#endif

/*******************************************************************************
 * Modificar aquí
 * Interfaz FlexComm utilizada
 ******************************************************************************/
#ifndef BOARD_SDSPI_SPI_BASE
#define BOARD_SDSPI_SPI_BASE (SPI_Type *)FLEXCOMM5
#endif

#define EXAMPLE_SPI_MASTER SPI7
#define EXAMPLE_SPI_MASTER_CLK_SRC kCLOCK_FlexComm7
#define EXAMPLE_SPI_MASTER_CLK_FREQ CLOCK_GetFlexCommClkFreq(7)

/*******************************************************************************
 * Variables
 ******************************************************************************/
sdspi_card_t g_sd;
sdspi_host_t g_host;

/*******************************************************************************
 * Code - SD disk interface
 ******************************************************************************/

DRESULT sdspi_disk_write(BYTE pdrv, const BYTE *buff, LBA_t sector, UINT count) {
	if (pdrv != SDSPIDISK) {
		return RES_PARERR;
	}

	if (kStatus_Success
			!= SDSPI_WriteBlocks(&g_sd, (uint8_t*) buff, sector, count)) {
		return RES_ERROR;
	}
	return RES_OK;
}

DRESULT sdspi_disk_read(BYTE pdrv, BYTE *buff, LBA_t sector, UINT count) {
	if (pdrv != SDSPIDISK) {
		return RES_PARERR;
	}

	if (kStatus_Success != SDSPI_ReadBlocks(&g_sd, buff, sector, count)) {
		return RES_ERROR;
	}
	return RES_OK;
}

DRESULT sdspi_disk_ioctl(BYTE pdrv, BYTE cmd, void *buff) {
	DRESULT result = RES_OK;

	if (pdrv != SDSPIDISK) {
		return RES_PARERR;
	}

	switch (cmd) {
	case GET_SECTOR_COUNT:
		if (buff) {
			*(uint32_t*) buff = g_sd.blockCount;
		} else {
			result = RES_PARERR;
		}
		break;
	case GET_SECTOR_SIZE:
		if (buff) {
			*(WORD*) buff = g_sd.blockSize;
		} else {
			result = RES_PARERR;
		}
		break;
	case GET_BLOCK_SIZE:
		if (buff) {
			*(uint32_t*) buff = g_sd.csd.eraseSectorSize;

		} else {
			result = RES_PARERR;

		}
		break;
	case CTRL_SYNC:
		result = RES_OK;
		break;
	default:
		result = RES_PARERR;
		break;
	}
	return result;
}

DSTATUS sdspi_disk_status(BYTE pdrv) {
	if (pdrv != SDSPIDISK) {
		return STA_NOINIT;
	}
	return 0;
}

DSTATUS sdspi_disk_initialize(BYTE pdrv) {
	if (pdrv == SDSPIDISK) {
		sdspi_host_init();

		if (kStatus_Success != SDSPI_Init(&g_sd)) {
			return STA_NOINIT;
		}
		return RES_OK;
	}
	return STA_NOINIT;
}

/*******************************************************************************
 * FLEXCOMM SPI
 ******************************************************************************/

void spi_init(void) {
	uint32_t sourceClock;
	spi_master_config_t masterConfig;

	SPI_MasterGetDefaultConfig(&masterConfig);

	sourceClock = EXAMPLE_SPI_MASTER_CLK_FREQ;
	masterConfig.baudRate_Bps = 400000U; // 100 ~ 400 kHz en inicialización
	masterConfig.direction = kSPI_MsbFirst;
	masterConfig.sselNum = kSPI_Ssel0;
	masterConfig.sselPol = kSPI_SpolActiveAllLow;

	SPI_MasterInit(EXAMPLE_SPI_MASTER, &masterConfig, sourceClock);
}

status_t spi_set_frequency(uint32_t frequency) {
	uint32_t sourceClock;
	sourceClock = EXAMPLE_SPI_MASTER_CLK_FREQ;

	if (SPI_MasterSetBaud(EXAMPLE_SPI_MASTER, frequency, sourceClock)
			== kStatus_Success) {
		return kStatus_Success;
	}
	return kStatus_Fail;
}

void spi_csActivePolarity(sdspi_cs_active_polarity_t polarity) {
}

status_t spi_exchange(uint8_t *in, uint8_t *out, uint32_t size) {
	spi_transfer_t masterTransfer;

	masterTransfer.txData = in;
	masterTransfer.rxData = out;
	masterTransfer.dataSize = size;
	masterTransfer.configFlags = kSPI_FrameDelay;

	status_t status = SPI_MasterTransferBlocking(EXAMPLE_SPI_MASTER,
			&masterTransfer);
	if (status == kStatus_Success) {
	} else {
	}
	return status;
}

void sdspi_host_init(void) {
	g_host.busBaudRate = 12000000U; // Velocidad de operación de la tarjeta SD
	g_host.setFrequency = (status_t (*)(uint32_t)) spi_set_frequency;
	g_host.exchange = (status_t (*)(uint8_t*, uint8_t*, uint32_t)) spi_exchange;
	g_host.init = (void (*)(void)) spi_init;
	g_sd.host = &g_host;
}

void sdspi_disk_set_card(sdspi_card_t *card) {
}
