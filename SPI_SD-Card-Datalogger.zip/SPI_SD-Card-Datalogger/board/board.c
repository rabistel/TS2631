#include "board.h"
#include "fsl_debug_console.h"

/* Clock rate on the CLKIN pin */
const uint32_t ExtClockIn = BOARD_EXTCLKINRATE;

/* Initialize debug console. */
status_t BOARD_InitDebugConsole(void) {
#if ((SDK_DEBUGCONSOLE == DEBUGCONSOLE_REDIRECT_TO_SDK) || defined(SDK_DEBUGCONSOLE_UART))
	status_t result;
	/* attach 12 MHz clock to FLEXCOMM0 (debug console) */
	CLOCK_AttachClk(BOARD_DEBUG_UART_CLK_ATTACH);
	RESET_PeripheralReset(BOARD_DEBUG_UART_RST);
	result = DbgConsole_Init(BOARD_DEBUG_UART_INSTANCE, BOARD_DEBUG_UART_BAUDRATE, BOARD_DEBUG_UART_TYPE,
			BOARD_DEBUG_UART_CLK_FREQ);
	assert(kStatus_Success == result);
	return result;
#else
	return kStatus_Success;
#endif
}
