#include "fsl_common.h"
#include "fsl_iocon.h"
#include "pin_mux.h"

/*FUNCTION**********************************************************************
 * 
 * Function Name : BOARD_InitBootPins
 * Description   : Calls initialization functions.
 * 
 *END**************************************************************************/
void BOARD_InitBootPins(void) {
	BOARD_InitPins();
}

#define IOCON_PIO_DIGITAL_EN        0x0100u   /*!< Enables digital function */
#define IOCON_PIO_FUNC1               0x01u   /*!< Selects pin function 1 */
#define IOCON_PIO_FUNC2               0x02u   /*!< Selects pin function 2 */
#define IOCON_PIO_INPFILT_OFF       0x0200u   /*!< Input filter disabled */
#define IOCON_PIO_INV_DI              0x00u   /*!< Input function is not inverted */
#define IOCON_PIO_MODE_INACT          0x00u   /*!< No addition pin function */
#define IOCON_PIO_OPENDRAIN_DI        0x00u   /*!< Open drain is disabled */
#define IOCON_PIO_SLEW_FAST         0x0400u   /*!< Fast mode, slew rate control is disabled */
#define IOCON_PIO_SLEW_STANDARD       0x00u   /*!< Standard mode, output slew rate control is enabled */

#define IOCON_PIO_MODE_PULLUP 0x20u   /*!<@brief Selects pull-up function */
#define IOCON_PIO_FUNC0 (0x00u)
#define IOCON_PIO_FUNC3 (0x03u)
#define IOCON_PIO_FUNC4 (0x04u)
#define IOCON_PIO_FUNC5 (0x05u)

void BOARD_InitPins(void) { /* Function assigned for the Core #0 (ARM Cortex-M4) */
	CLOCK_EnableClock(kCLOCK_Iocon); /* Enables the clock for the IOCON block. 0 = Disable; 1 = Enable.: 0x01u */

	//************************************************************************************************
	/* Para usar desde la placa de desarrollo ---> Datalogger Arduino */

	const uint32_t port3_pin20_config = (/* Pin is configured as FC9_SCK */
			IOCON_PIO_FUNC1 |
			/* Selects pull-up function */
			IOCON_PIO_MODE_PULLUP |
			/* Input function is not inverted */
			IOCON_PIO_INV_DI |
			/* Enables digital function */
			IOCON_PIO_DIGITAL_EN |
			/* Input filter disabled */
			IOCON_PIO_INPFILT_OFF |
			/* Standard mode, output slew rate control is enabled */
			IOCON_PIO_SLEW_STANDARD |
			/* Open drain is disabled */
			IOCON_PIO_OPENDRAIN_DI);
	/* PORT3 PIN20 (coords: N2) is configured as FC9_SCK */
	IOCON_PinMuxSet(IOCON, 3U, 20U, port3_pin20_config);

	const uint32_t port3_pin21_config = (/* Pin is configured as FC9_RXD_SDA_MOSI */
			IOCON_PIO_FUNC1 |
			/* Selects pull-up function */
			IOCON_PIO_MODE_PULLUP |
			/* Input function is not inverted */
			IOCON_PIO_INV_DI |
			/* Enables digital function */
			IOCON_PIO_DIGITAL_EN |
			/* Input filter disabled */
			IOCON_PIO_INPFILT_OFF |
			/* Open drain is disabled */
			IOCON_PIO_OPENDRAIN_DI);
	/* PORT3 PIN21 (coords: P5) is configured as FC9_RXD_SDA_MOSI */
	IOCON_PinMuxSet(IOCON, 3U, 21U, port3_pin21_config);

	const uint32_t port3_pin22_config = (/* Pin is configured as FC9_TXD_SCL_MISO */
			IOCON_PIO_FUNC1 |
			/* Selects pull-up function */
			IOCON_PIO_MODE_PULLUP |
			/* Input function is not inverted */
			IOCON_PIO_INV_DI |
			/* Enables digital function */
			IOCON_PIO_DIGITAL_EN |
			/* Input filter disabled */
			IOCON_PIO_INPFILT_OFF |
			/* Open drain is disabled */
			IOCON_PIO_OPENDRAIN_DI);
	/* PORT3 PIN22 (coords: N5) is configured as FC9_TXD_SCL_MISO */
	IOCON_PinMuxSet(IOCON, 3U, 22U, port3_pin22_config);

	const uint32_t port3_pin30_config = (/* Pin is configured as FC9_CTS_SDA_SSEL0 */
			IOCON_PIO_FUNC1 |
			/* Selects pull-up function */
			IOCON_PIO_MODE_PULLUP |
			/* Input function is not inverted */
			IOCON_PIO_INV_DI |
			/* Enables digital function */
			IOCON_PIO_DIGITAL_EN |
			/* Input filter disabled */
			IOCON_PIO_INPFILT_OFF |
			/* Standard mode, output slew rate control is enabled */
			IOCON_PIO_SLEW_STANDARD |
			/* Open drain is disabled */
			IOCON_PIO_OPENDRAIN_DI);
	/* PORT3 PIN30 (coords: K13) is configured as FC9_CTS_SDA_SSEL0 */
	/* PORT3 PIN30 (coords: K13) is configured as GPIO for manual CS */
	IOCON_PinMuxSet(IOCON, 3U, 30U, port3_pin30_config);

	//************************************************************************************************
	/* Para usar los pines del LCD */
	const uint32_t port2_pin11_config = ( /*Pin is configured as FC5_SCK*/
			IOCON_PIO_FUNC5 |
			/*Selects pull-up function*/
			IOCON_PIO_MODE_PULLUP |
			/*Input function is not inverted*/
			IOCON_PIO_INV_DI |
			/*Enables digital function*/
			IOCON_PIO_DIGITAL_EN |
			/*Input filter disabled*/
			IOCON_PIO_INPFILT_OFF |
			/*Standard mode, output slew rate control is enabled*/
			IOCON_PIO_SLEW_STANDARD |
			/*Open drain is disabled*/
			IOCON_PIO_OPENDRAIN_DI);
	/*PORT2 PIN11 (pin 43) is configured as FC5_SCK*/
	IOCON_PinMuxSet(IOCON, 2U, 11U, port2_pin11_config);

	const uint32_t port2_pin12_config = ( /*Pin is configured as FC5_RXD_SDA_MOSI*/
			IOCON_PIO_FUNC5 |
			/*Selects pull-up function*/
			IOCON_PIO_MODE_PULLUP |
			/*Input function is not inverted*/
			IOCON_PIO_INV_DI |
			/*Enables digital function*/
			IOCON_PIO_DIGITAL_EN |
			/*Input filter disabled*/
			IOCON_PIO_INPFILT_OFF |
			/*Open drain is disabled*/
			IOCON_PIO_OPENDRAIN_DI);
	/*PORT2 PIN12 (pin 45) is configured as FC5_RXD_SDA_MOSI*/
	IOCON_PinMuxSet(IOCON, 2U, 12U, port2_pin12_config);

	const uint32_t port2_pin13_config = ( /*Pin is configured as FC5_TXD_SCL_MISO*/
			IOCON_PIO_FUNC5 |
			/*Selects pull-up function*/
			IOCON_PIO_MODE_PULLUP |
			/*Input function is not inverted*/
			IOCON_PIO_INV_DI |
			/*Enables digital function*/
			IOCON_PIO_DIGITAL_EN |
			/*Input filter disabled*/
			IOCON_PIO_INPFILT_OFF |
			/*Open drain is disabled*/
			IOCON_PIO_OPENDRAIN_DI);
	/*PORT2 PIN13 (pin 70) is configured as FC5_TXD_SCL_MISO*/
	IOCON_PinMuxSet(IOCON, 2U, 13U, port2_pin13_config);

	const uint32_t port2_pin14_config = ( /*Pin is configured as GPIO*/
			IOCON_PIO_FUNC5 |
			/*Selects pull-up function*/
			IOCON_PIO_MODE_PULLUP |
			/*Input function is not inverted*/
			IOCON_PIO_INV_DI |
			/*Enables digital function*/
			IOCON_PIO_DIGITAL_EN |
			/*Input filter disabled*/
			IOCON_PIO_INPFILT_OFF |
			/*Standard mode, output slew rate control is enabled*/
			IOCON_PIO_SLEW_STANDARD |
			/*Open drain is disabled*/
			IOCON_PIO_OPENDRAIN_DI);
	/*PORT2 PIN14 (pin 77) is configured as GPIO for manual CS*/
	IOCON_PinMuxSet(IOCON, 2U, 14U, port2_pin14_config);

	//************************************************************************************************
	/* Para usar desde Interfaz P2 ---> JTAG */
	const uint32_t port0_pin2_config = (/* Pin is configured as FC3_TXD_SCL_MISO */
			IOCON_PIO_FUNC1 |
			/* Selects pull-up function */
			IOCON_PIO_MODE_PULLUP |
			/* Input function is not inverted */
			IOCON_PIO_INV_DI |
			/* Enables digital function */
			IOCON_PIO_DIGITAL_EN |
			/* Input filter disabled */
			IOCON_PIO_INPFILT_OFF |
			/* Standard mode, output slew rate control is enabled */
			IOCON_PIO_SLEW_STANDARD |
			/* Open drain is disabled */
			IOCON_PIO_OPENDRAIN_DI);
	/* PORT0 PIN2 (pin 174) is configured as FC3_TXD_SCL_MISO */
	IOCON_PinMuxSet(IOCON, 0U, 2U, port0_pin2_config);

	const uint32_t port0_pin3_config = (/* Pin is configured as FC3_RXD_SDA_MOSI */
			IOCON_PIO_FUNC1 |
			/* Selects pull-up function */
			IOCON_PIO_MODE_PULLUP |
			/* Input function is not inverted */
			IOCON_PIO_INV_DI |
			/* Enables digital function */
			IOCON_PIO_DIGITAL_EN |
			/* Input filter disabled */
			IOCON_PIO_INPFILT_OFF |
			/* Open drain is disabled */
			IOCON_PIO_OPENDRAIN_DI);
	/* PORT0 PIN3 (pin 178) is configured as FC3_RXD_SDA_MOSI */
	IOCON_PinMuxSet(IOCON, 0U, 3U, port0_pin3_config);

	const uint32_t port0_pin4_config = (/* Pin is configured as GPIO */
			IOCON_PIO_FUNC0 |
			/* Selects pull-up function */
			IOCON_PIO_MODE_PULLUP |
			/* Input function is not inverted */
			IOCON_PIO_INV_DI |
			/* Enables digital function */
			IOCON_PIO_DIGITAL_EN |
			/* Input filter disabled */
			IOCON_PIO_INPFILT_OFF |
			/* Open drain is disabled */
			IOCON_PIO_OPENDRAIN_DI);
	/* PORT0 PIN4 (pin 185) is configured as GPIO for manual CS */
	IOCON_PinMuxSet(IOCON, 0U, 4U, port0_pin4_config);

	const uint32_t port0_pin6_config = (/* Pin is configured as FC3_SCK */
			IOCON_PIO_FUNC1 |
			/* Selects pull-up function */
			IOCON_PIO_MODE_PULLUP |
			/* Input function is not inverted */
			IOCON_PIO_INV_DI |
			/* Enables digital function */
			IOCON_PIO_DIGITAL_EN |
			/* Input filter disabled */
			IOCON_PIO_INPFILT_OFF |
			/* Standard mode, output slew rate control is enabled */
			IOCON_PIO_SLEW_STANDARD |
			/* Open drain is disabled */
			IOCON_PIO_OPENDRAIN_DI);
	/* PORT0 PIN6 (pin 191) is configured as FC3_SCK*/
	IOCON_PinMuxSet(IOCON, 0U, 6U, port0_pin6_config);
}
/*******************************************************************************
 * EOF
 ******************************************************************************/
