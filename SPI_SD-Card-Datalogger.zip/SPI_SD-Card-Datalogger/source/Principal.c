#include "fsl_debug_console.h"
#include "fatfs/source/fsl_sdspi_disk/fsl_sdspi_disk.h"
#include "sdmmc/sdspi/fsl_sdspi.h"
#include "pin_mux.h"


/*******************************************************************************
 * 								Comunicación SPI
 * Modificar en fatfs/source/fsl_sdspi_disk/fsl_sdspi_disk.c :
 * - Interfaz FlexComm utilizada
 *
 * En este archivo modificar la función BOARD_InitSDSPI :
 * - Interfaz FlexComm utilizada
 *
 * Manejar el CS manual solo si usan los pines del JTAG
 ******************************************************************************/
/*
// Kit de Desarrollo -> Datalogger Arduino
#define EXAMPLE_SPI_MASTER SPI9
#define EXAMPLE_SPI_MASTER_CLK_SRC kCLOCK_Flexcomm9
#define EXAMPLE_SPI_MASTER_CLK_FREQ CLOCK_GetFlexCommClkFreq(9)
#define EXAMPLE_SPI_SSEL 0
#define EXAMPLE_SPI_SPOL kSPI_SpolActiveAllLow

#define CS_LOW()  GPIO->CLR[3] = (1 << 30) //Para SPI9 --> CS Manual, no es necesario
#define CS_HIGH() GPIO->SET[3] = (1 << 30)
*/

// Pines del LCD
#define EXAMPLE_SPI_MASTER SPI5
#define EXAMPLE_SPI_MASTER_CLK_SRC kCLOCK_Flexcomm5
#define EXAMPLE_SPI_MASTER_CLK_FREQ CLOCK_GetFlexCommClkFreq(5)
#define EXAMPLE_SPI_SSEL 0
#define EXAMPLE_SPI_SPOL kSPI_SpolActiveAllLow

//#define CS_LOW()  GPIO->CLR[2] = (1 << 14) //Para SPI5 --> CS Manual, no es necesario
//#define CS_HIGH() GPIO->SET[2] = (1 << 14)

/*
// Pines del JTAG
#define EXAMPLE_SPI_MASTER SPI3
#define EXAMPLE_SPI_MASTER_CLK_SRC kCLOCK_Flexcomm3
#define EXAMPLE_SPI_MASTER_CLK_FREQ CLOCK_GetFlexCommClkFreq(3)
#define EXAMPLE_SPI_SSEL 0
#define EXAMPLE_SPI_SPOL kSPI_SpolActiveAllLow

#define CS_LOW()  GPIO->CLR[0] = (1 << 4) //Para SPI3 --> CS Manual, no es necesario
#define CS_HIGH() GPIO->SET[0] = (1 << 4)
 */

/*******************************************************************************
 * 							Buffers, Variables
 ******************************************************************************/
static FATFS g_fileSystem;
static FIL file;

extern sdspi_card_t g_sd;

extern void sdspi_disk_set_card(sdspi_card_t *card);

/*******************************************************************************
 * 							Funciones auxiliares
 ******************************************************************************/
static void BOARD_InitSDSPI(void)
{
    CLOCK_AttachClk(kFRO12M_to_FLEXCOMM5);
    BOARD_InitPins();
    BOARD_BootClockPLL180M();
    BOARD_InitDebugConsole();
    PRINTF("\r\nInicializando SPI para SD card...\r\n");
}

/*******************************************************************************
 * 							MAIN
 ******************************************************************************/
int main(void)
{
	FRESULT res;
	BOARD_InitSDSPI();
	sdspi_disk_set_card(&g_sd);

	//PRINTF("Montando sistema de archivos...\r\n");
	res = f_mount(&g_fileSystem, "0:", 1);
	if (res != FR_OK) {
	    PRINTF("Error montando FatFs: %d\r\n", res);
	} else {
	    PRINTF("FatFs montado correctamente.\r\n");

	    const char *filename = "Prueba22.txt"; // 8 + 4 = 12
	    //PRINTF("Longitud de filename: %d\r\n", strlen(filename));
	    const char *text = "Datalogger TECMES TS2631: LPC54618 + SPI + FatFs\r\n"
	    				   "Prueba de Debug!\r\n"
	    		           "Manejo automático del CS en Flexcomm9 y Flexcomm5!\r\n";
	    UINT bytesWritten;

	    PRINTF("Abriendo archivo para escritura...\r\n");
	    res = f_open(&file, filename, FA_WRITE | FA_CREATE_ALWAYS);
	    if (res != FR_OK) {
	        PRINTF("Error abriendo archivo '%s': %d\r\n", filename, res);
	    } else {
	        PRINTF("Escribiendo en archivo...\r\n");
	        res = f_write(&file, text, strlen(text), &bytesWritten);
	        if (res == FR_OK && bytesWritten == strlen(text)) {
	            PRINTF("Archivo escrito correctamente. Bytes escritos: %d\r\n", bytesWritten);
	        } else {
	            PRINTF("Error escribiendo archivo: %d (Bytes escritos: %d)\r\n", res, bytesWritten);
	        }
	        f_close(&file);
	    }

	    char readBuffer[1000];
	    UINT bytesRead;
	    PRINTF("Abriendo archivo para lectura...\r\n");
	    res = f_open(&file, filename, FA_READ);
	    if (res != FR_OK) {
	        PRINTF("Error abriendo archivo '%s' para lectura: %d\r\n", filename, res);
	    } else {
	        PRINTF("Leyendo archivo...\r\n");
	        res = f_read(&file, readBuffer, sizeof(readBuffer) - 1, &bytesRead);
	        if (res == FR_OK) {
	            readBuffer[bytesRead] = '\0';
	            PRINTF("Archivo leido correctamente. Contenido:\r\n%s\r\n", readBuffer);
	        } else {
	            PRINTF("Error leyendo archivo: %d\r\n", res);
	        }
	        f_close(&file);
	    }

	    PRINTF("Desmontando sistema de archivos...\r\n");
	    f_mount(NULL, "0:", 1);
	    PRINTF("Sistema de archivos desmontado.\r\n");
	}

	while (1) {
	}
}
