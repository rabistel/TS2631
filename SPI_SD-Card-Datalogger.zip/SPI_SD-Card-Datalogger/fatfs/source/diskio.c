/*-----------------------------------------------------------------------*/
/*            diskio.c/h MODIFICADOS COMPLETAMENTE                       */
/*-----------------------------------------------------------------------*/

#include "ff.h"
#include "diskio.h"

// Definición de LBA_t si no está ya definida en ff.h o diskio.h
#ifndef _LBA_T_DEFINED
typedef uint32_t LBA_t;
#define _LBA_T_DEFINED
#endif

/* Include specific disk driver header */
#if FF_DISK_DRIVER == 0
#include "fatfs/source/fsl_sdspi_disk/fsl_sdspi_disk.h"
#define SDSPIDISK 0 // Define the drive number for SDSPI
#else
#endif

DSTATUS disk_status(BYTE pdrv) {
	DSTATUS stat;

	switch (pdrv) {
	case SDSPIDISK:
		stat = sdspi_disk_status(pdrv);
		break;

	default:
		stat = STA_NOINIT;
	}
	return stat;
}

DSTATUS disk_initialize(BYTE pdrv) {
	DSTATUS stat;

	switch (pdrv) {
	case SDSPIDISK:
		stat = sdspi_disk_initialize(pdrv);
		break;

	default:
		stat = STA_NOINIT;
	}
	return stat;
}

DRESULT disk_read(BYTE pdrv, BYTE *buff, LBA_t sector, UINT count) {
	DRESULT res;

	switch (pdrv) {
	case SDSPIDISK:
		res = sdspi_disk_read(pdrv, buff, sector, count);
		break;

	default:
		res = RES_PARERR;
	}
	return res;
}

DRESULT disk_write(BYTE pdrv, const BYTE *buff, LBA_t sector, UINT count) {
	DRESULT res;

	switch (pdrv) {
	case SDSPIDISK:
		res = sdspi_disk_write(pdrv, buff, sector, count);
		break;

	default:
		res = RES_PARERR;
	}
	return res;
}

DRESULT disk_ioctl(BYTE pdrv, BYTE cmd, void *buff) {
	DRESULT res;

	switch (pdrv) {
	case SDSPIDISK:
		res = sdspi_disk_ioctl(pdrv, cmd, buff);
		break;

	default:
		res = RES_PARERR;
	}
	return res;
}
